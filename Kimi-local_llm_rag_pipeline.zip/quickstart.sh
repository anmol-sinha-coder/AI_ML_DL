#!/bin/bash
# =============================================================================
# quickstart.sh — One-command pipeline runner
# =============================================================================
# Usage: bash quickstart.sh [step]
#   step: all | setup | data | train | export | rag | spark | test
# =============================================================================

set -e

STEP=${1:-all}
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_DIR"

echo "========================================"
echo "Local LLM RAG Pipeline — Quick Start"
echo "Step: $STEP"
echo "========================================"

case $STEP in
    setup|all)
        echo ""
        echo "[1/7] Setting up environment..."
        bash scripts/01_setup_env.sh
        ;;&

    data|all)
        echo ""
        echo "[2/7] Preparing training data..."
        conda activate local_llm_rag 2>/dev/null || true
        python src/02_prepare_data.py
        ;;&

    train|all)
        echo ""
        echo "[3/7] Fine-tuning with QLoRA (this will take 2-4 hours)..."
        echo "GPU: $(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null || echo 'Not detected')"
        conda activate local_llm_rag 2>/dev/null || true
        python src/03_finetune_qlora.py
        ;;&

    export|all)
        echo ""
        echo "[4/7] Exporting to GGUF..."
        conda activate local_llm_rag 2>/dev/null || true
        python src/04_merge_export_gguf.py
        ;;&

    rag|all)
        echo ""
        echo "[5/7] Testing RAG pipeline..."
        conda activate local_llm_rag 2>/dev/null || true
        # Start ollama in background if not running
        if ! curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
            echo "Starting Ollama server..."
            ollama serve &
            OLLAMA_PID=$!
            sleep 5
        fi
        python src/05_rag_pipeline.py
        ;;&

    spark|all)
        echo ""
        echo "[6/7] Testing Spark UDF..."
        conda activate local_llm_rag 2>/dev/null || true
        python src/06_spark_udf.py --mode gguf
        ;;&

    test|all)
        echo ""
        echo "[7/7] Testing offline CPU inference..."
        conda activate local_llm_rag 2>/dev/null || true
        python src/07_test_offline_cpu.py
        ;;&
esac

echo ""
echo "========================================"
echo "Pipeline Complete!"
echo "========================================"
echo ""
echo "Your portable model: models/gguf/model-q4_k_m.gguf"
echo "To use on another system, copy ONLY this file + 07_test_offline_cpu.py"
echo ""
