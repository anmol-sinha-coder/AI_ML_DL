#!/usr/bin/env python3
"""
=============================================================================
04_merge_export_gguf.py — Merge LoRA Adapters & Export to GGUF Format
=============================================================================
This script:
  1. Loads the base model + fine-tuned LoRA adapter
  2. Merges adapter weights into base model (creates full model)
  3. Exports merged model to GGUF format for Ollama/llama.cpp
  4. Creates Ollama Modelfile

OUTPUT:
  - models/merged/          : Merged HF model (can be deleted after GGUF export)
  - models/gguf/            : Single .gguf file (portable, CPU/GPU compatible)
  - models/Modelfile        : Ollama recipe

OFFLINE CAPABLE: Yes (after initial llama.cpp setup)
=============================================================================
"""

import os
import subprocess
import sys
from pathlib import Path

# Paths
BASE_MODEL = "Qwen/Qwen2.5-Coder-3B-Instruct"
ADAPTER_PATH = "./models/qwen2.5-coder-3b-qlora/final_adapter"
MERGED_PATH = "./models/merged/qwen2.5-coder-3b-merged"
GGUF_OUTPUT_DIR = "./models/gguf"
OLLAMA_MODEL_NAME = "pipeline-config-generator"

# Quantization level for GGUF export
# Q4_K_M = good balance of quality/size for 3B models (~1.8GB file)
# Q5_K_M = better quality (~2.2GB)
# Q8_0 = best quality, larger (~3.2GB)
GGUF_QUANT = "Q4_K_M"


def merge_adapter():
    """Merge LoRA adapter into base model to create standalone model."""
    print("=== Step 1: Merging LoRA Adapter into Base Model ===")

    from peft import PeftModel
    from transformers import AutoModelForCausalLM, AutoTokenizer
    import torch

    # Load base model in FP16 (merging needs higher precision)
    print(f"Loading base model: {BASE_MODEL}")
    model = AutoModelForCausalLM.from_pretrained(
        BASE_MODEL,
        torch_dtype=torch.float16,
        device_map="auto",
        trust_remote_code=True,
    )
    tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL, trust_remote_code=True)

    # Load and merge adapter
    print(f"Loading adapter from: {ADAPTER_PATH}")
    model = PeftModel.from_pretrained(model, ADAPTER_PATH)

    print("Merging adapter weights...")
    model = model.merge_and_unload()  # This fuses adapter into base weights

    # Save merged model
    Path(MERGED_PATH).mkdir(parents=True, exist_ok=True)
    model.save_pretrained(MERGED_PATH)
    tokenizer.save_pretrained(MERGED_PATH)

    print(f"Merged model saved to: {MERGED_PATH}")
    print(f"Size: {sum(f.stat().st_size for f in Path(MERGED_PATH).rglob('*')) / 1e9:.2f} GB")


def export_to_gguf():
    """Convert merged HF model to GGUF format using llama.cpp."""
    print("\n=== Step 2: Exporting to GGUF Format ===")

    # Check if llama.cpp is available
    llama_cpp_path = Path.home() / "llama.cpp"
    if not llama_cpp_path.exists():
        print("llama.cpp not found. Cloning...")
        subprocess.run([
            "git", "clone", "https://github.com/ggerganov/llama.cpp", str(llama_cpp_path)
        ], check=True)
        # Build llama.cpp (Linux/WSL)
        subprocess.run(
            ["cmake", "-B", "build", "-DCMAKE_BUILD_TYPE=Release"],
            cwd=llama_cpp_path, check=True
        )
        subprocess.run(
            ["cmake", "--build", "build", "--config", "Release", "-j"],
            cwd=llama_cpp_path, check=True
        )

    convert_script = llama_cpp_path / "convert_hf_to_gguf.py"
    if not convert_script.exists():
        print(f"ERROR: convert_hf_to_gguf.py not found at {convert_script}")
        print("Please ensure llama.cpp is properly cloned and up to date.")
        sys.exit(1)

    # Install requirements for conversion
    req_file = llama_cpp_path / "requirements.txt"
    if req_file.exists():
        subprocess.run([sys.executable, "-m", "pip", "install", "-r", str(req_file)], check=True)

    # Convert to FP16 GGUF first (highest fidelity intermediate)
    fp16_gguf = Path(GGUF_OUTPUT_DIR) / "model-f16.gguf"
    Path(GGUF_OUTPUT_DIR).mkdir(parents=True, exist_ok=True)

    print("Converting HF model to FP16 GGUF...")
    subprocess.run([
        sys.executable, str(convert_script),
        str(MERGED_PATH),
        "--outfile", str(fp16_gguf),
        "--outtype", "f16",
    ], check=True)

    # Quantize to target level
    quant_gguf = Path(GGUF_OUTPUT_DIR) / f"model-{GGUF_QUANT.lower()}.gguf"
    quantize_bin = llama_cpp_path / "build" / "bin" / "llama-quantize"

    if not quantize_bin.exists():
        # Try alternative path
        quantize_bin = llama_cpp_path / "llama-quantize"

    if quantize_bin.exists():
        print(f"Quantizing to {GGUF_QUANT}...")
        subprocess.run([
            str(quantize_bin),
            str(fp16_gguf),
            str(quant_gguf),
            GGUF_QUANT,
        ], check=True)

        # Remove FP16 intermediate to save space
        fp16_gguf.unlink()
        print(f"Quantized GGUF saved: {quant_gguf}")
        print(f"File size: {quant_gguf.stat().st_size / 1e6:.1f} MB")
    else:
        print(f"WARNING: llama-quantize not found. Using FP16 GGUF.")
        quant_gguf = fp16_gguf

    return quant_gguf


def create_modelfile(gguf_path: Path):
    """Create Ollama Modelfile for the exported GGUF."""
    print("\n=== Step 3: Creating Ollama Modelfile ===")

    modelfile_content = f"""# Ollama Modelfile for Pipeline Config Generator
# Generated automatically from QLoRA fine-tuned Qwen2.5-Coder-3B

FROM {gguf_path.absolute()}

# Model parameters optimized for structured JSON output
PARAMETER temperature 0.1
PARAMETER top_p 0.5
PARAMETER top_k 20
PARAMETER num_ctx 4096
PARAMETER num_predict 2048
PARAMETER repeat_penalty 1.1
PARAMETER stop "<|im_end|>"
PARAMETER stop "</s>"

# System prompt for JSON config generation
SYSTEM """
You are an expert data pipeline engineer specializing in Apache Spark, SQL, and ETL workflows.
Your task is to generate precise, valid JSON configuration files for data pipeline jobs.

RULES:
1. Output ONLY valid JSON. No markdown code blocks, no explanations, no preamble.
2. All field names must match the expected schema exactly.
3. Include complete Spark job configs with source, transformations, and sink definitions.
4. For SQL pipelines, include the full query and merge logic.
5. Use standard Spark SQL functions and valid JSON syntax.
6. If a transformation is complex, break it into explicit steps.
"""

# Qwen2.5 chat template (automatically embedded in GGUF, but explicit here for safety)
TEMPLATE """{{{{- if .System }}}<|im_start|>system
{{{{ .System }}}}<|im_end|>
{{{{ end }}}}{{{{ if .Prompt }}}<|im_start|>user
{{{{ .Prompt }}}}<|im_end|>
{{{{ end }}}}<|im_start|>assistant
{{{{ .Response }}}}<|im_end|>"""
"""

    modelfile_path = Path(GGUF_OUTPUT_DIR) / "Modelfile"
    with open(modelfile_path, "w") as f:
        f.write(modelfile_content)

    print(f"Modelfile created: {modelfile_path}")

    # Register with Ollama
    print("\nRegistering model with Ollama...")
    result = subprocess.run(
        ["ollama", "create", OLLAMA_MODEL_NAME, "-f", str(modelfile_path)],
        capture_output=True, text=True
    )
    if result.returncode == 0:
        print(f"Model registered: ollama run {OLLAMA_MODEL_NAME}")
    else:
        print(f"Ollama registration output: {result.stdout}")
        print(f"Ollama registration error: {result.stderr}")
        print("\nYou can manually register later with:")
        print(f"  ollama create {OLLAMA_MODEL_NAME} -f {modelfile_path}")


def main():
    print("=== GGUF Export Pipeline ===")
    print(f"Base Model: {BASE_MODEL}")
    print(f"Adapter: {ADAPTER_PATH}")
    print(f"Target Quantization: {GGUF_QUANT}")
    print("")

    # Step 1: Merge
    merge_adapter()

    # Step 2: Export to GGUF
    gguf_path = export_to_gguf()

    # Step 3: Create Modelfile
    create_modelfile(gguf_path)

    print("\n=== Export Complete ===")
    print(f"GGUF Model: {gguf_path}")
    print(f"To test: ollama run {OLLAMA_MODEL_NAME}")
    print("\nThis GGUF file can now be copied to ANY system (CPU-only or GPU) and run with:")
    print("  - Ollama (recommended)")
    print("  - llama.cpp")
    print("  - LM Studio")
    print("  - llama-cpp-python (Python bindings)")


if __name__ == "__main__":
    main()
