#!/usr/bin/env python3
"""
=============================================================================
02_prepare_data.py — Training Dataset Preparation for JSON Config Generation
=============================================================================
This script converts your input files (mapping docs, schema files, prompts)
into a supervised fine-tuning (SFT) dataset for QLoRA training.

INPUTS (place in ./data/):
  - source_events.json       : Source event definitions
  - mapping_docs.xlsx        : Column mapping documents (Excel)
  - schema_info.csv          : Table structural information (CSV)
  - prompt_template.md       : Prompt instructions (Markdown)

OUTPUT:
  - data/training_dataset.jsonl  : Instruction-response pairs for SFT
=============================================================================
"""

import json
import pandas as pd
import os
from pathlib import Path
from typing import List, Dict

DATA_DIR = Path(__file__).parent.parent / "data"
OUTPUT_FILE = DATA_DIR / "training_dataset.jsonl"


def load_source_events(path: Path) -> str:
    """Load and flatten source event JSON into structured text."""
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    # Flatten to text representation
    lines = ["=== SOURCE EVENTS ==="]
    for event in data if isinstance(data, list) else [data]:
        lines.append(f"Event: {event.get('name', 'Unknown')}")
        lines.append(f"Type: {event.get('type', 'N/A')}")
        lines.append(f"Schema: {json.dumps(event.get('schema', {}), indent=2)}")
        lines.append("---")
    return "\n".join(lines)


def load_mapping_docs(path: Path) -> str:
    """Load Excel mapping documents into structured text."""
    dfs = pd.read_excel(path, sheet_name=None)
    lines = ["=== COLUMN MAPPINGS ==="]
    for sheet_name, df in dfs.items():
        lines.append(f"Sheet: {sheet_name}")
        lines.append(df.to_string(index=False))
        lines.append("---")
    return "\n".join(lines)


def load_schema_info(path: Path) -> str:
    """Load CSV/Parquet schema information."""
    if path.suffix == ".parquet":
        df = pd.read_parquet(path)
    else:
        df = pd.read_csv(path)
    lines = ["=== TABLE SCHEMA ==="]
    lines.append(df.to_string(index=False))
    return "\n".join(lines)


def load_prompt_template(path: Path) -> str:
    """Load markdown prompt template."""
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def create_training_example(
    context: str,
    instruction: str,
    output_json: Dict,
    system_prompt: str = "You are an expert data pipeline engineer. Generate precise JSON configuration files for Spark/SQL pipelines based on the provided mappings and schemas. Output ONLY valid JSON."
) -> Dict:
    """Create a single training example in chat format."""
    # Using Qwen chat template format
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": f"{instruction}\n\nContext:\n{context}"},
        {"role": "assistant", "content": json.dumps(output_json, indent=2)}
    ]
    return {"messages": messages}


def generate_synthetic_training_data() -> List[Dict]:
    """
    Generate synthetic training examples for JSON config generation.
    In production, replace this with your actual labeled data.
    """
    examples = []

    # Example 1: Simple Spark job config
    context_1 = """=== SOURCE EVENTS ===
Event: user_signup
Type: kafka_topic
Schema: {"user_id": "string", "timestamp": "long", "email": "string", "country": "string"}
---
=== COLUMN MAPPINGS ===
Sheet: users
Source Column | Target Column | Transformation
user_id       | user_id       | direct
email         | email_address | direct
country       | country_code  | UPPER(country)
timestamp     | created_at    | FROM_UNIXTIME(timestamp/1000)
---
=== TABLE SCHEMA ===
Table: dim_users
Columns: user_id STRING, email_address STRING, country_code STRING, created_at TIMESTAMP
"""
    instruction_1 = "Generate a Spark streaming job JSON config that reads from Kafka 'user_signup' topic and writes to 'dim_users' table with the given mappings."
    output_1 = {
        "job_name": "kafka_to_dim_users",
        "execution_engine": "spark",
        "mode": "streaming",
        "source": {
            "type": "kafka",
            "topic": "user_signup",
            "format": "json",
            "options": {"kafka.bootstrap.servers": "localhost:9092"}
        },
        "transformations": [
            {"column": "user_id", "expression": "col('user_id')", "target": "user_id"},
            {"column": "email", "expression": "col('email')", "target": "email_address"},
            {"column": "country", "expression": "upper(col('country'))", "target": "country_code"},
            {"column": "timestamp", "expression": "from_unixtime(col('timestamp')/1000)", "target": "created_at"}
        ],
        "sink": {
            "type": "jdbc",
            "table": "dim_users",
            "mode": "append"
        }
    }
    examples.append(create_training_example(context_1, instruction_1, output_1))

    # Example 2: SQL pipeline config
    context_2 = """=== SOURCE EVENTS ===
Event: order_placed
Type: database_change_log
Schema: {"order_id": "string", "amount": "decimal", "currency": "string", "status": "string"}
---
=== COLUMN MAPPINGS ===
Sheet: orders
Source Column | Target Column | Transformation
order_id      | order_id      | direct
amount        | total_amount  | CAST(amount AS DECIMAL(18,2))
currency      | currency      | direct
status        | order_status  | CASE WHEN status='1' THEN 'CONFIRMED' ELSE 'PENDING' END
---
=== TABLE SCHEMA ===
Table: fct_orders
Columns: order_id STRING, total_amount DECIMAL(18,2), currency STRING, order_status STRING, etl_timestamp TIMESTAMP
"""
    instruction_2 = "Generate a SQL-based ETL pipeline JSON config for batch processing orders into fct_orders."
    output_2 = {
        "job_name": "batch_orders_etl",
        "execution_engine": "sql",
        "mode": "batch",
        "source_query": "SELECT order_id, amount, currency, status FROM staging.orders",
        "transformations": [
            {"target_column": "total_amount", "sql_expression": "CAST(amount AS DECIMAL(18,2))"},
            {"target_column": "order_status", "sql_expression": "CASE WHEN status='1' THEN 'CONFIRMED' ELSE 'PENDING' END"},
            {"target_column": "etl_timestamp", "sql_expression": "CURRENT_TIMESTAMP()"}
        ],
        "target_table": "fct_orders",
        "write_mode": "merge",
        "merge_keys": ["order_id"]
    }
    examples.append(create_training_example(context_2, instruction_2, output_2))

    # Example 3: Complex pipeline with multiple sources
    context_3 = """=== SOURCE EVENTS ===
Event: product_view
Type: clickstream
Event: product_purchase
Type: transaction
---
=== COLUMN MAPPINGS ===
Sheet: product_analytics
view_product_id | product_id | direct
view_timestamp  | view_time  | from_unixtime
purchase_pid    | product_id | direct
purchase_amount | revenue    | direct
---
=== TABLE SCHEMA ===
Table: product_metrics
Columns: product_id STRING, view_count BIGINT, revenue DECIMAL(18,2), conversion_rate DOUBLE
"""
    instruction_3 = "Generate a Spark SQL job that joins clickstream and transaction data to compute product_metrics."
    output_3 = {
        "job_name": "product_analytics_agg",
        "execution_engine": "spark_sql",
        "mode": "batch",
        "sources": [
            {"alias": "views", "query": "SELECT product_id as view_product_id, timestamp as view_timestamp FROM clickstream.product_view"},
            {"alias": "purchases", "query": "SELECT product_id as purchase_pid, amount as purchase_amount FROM transactions.product_purchase"}
        ],
        "sql": """
            WITH view_agg AS (
                SELECT product_id, COUNT(*) as view_count 
                FROM views 
                GROUP BY product_id
            ),
            purchase_agg AS (
                SELECT purchase_pid as product_id, SUM(purchase_amount) as revenue, COUNT(*) as purchases
                FROM purchases 
                GROUP BY purchase_pid
            )
            SELECT 
                v.product_id,
                v.view_count,
                COALESCE(p.revenue, 0) as revenue,
                COALESCE(p.purchases, 0) * 1.0 / v.view_count as conversion_rate
            FROM view_agg v
            LEFT JOIN purchase_agg p ON v.product_id = p.product_id
        """,
        "target_table": "product_metrics",
        "write_mode": "overwrite"
    }
    examples.append(create_training_example(context_3, instruction_3, output_3))

    return examples


def main():
    print("=== Preparing Training Dataset ===")

    # In production, load your actual files:
    # context_parts = []
    # if (DATA_DIR / "source_events.json").exists():
    #     context_parts.append(load_source_events(DATA_DIR / "source_events.json"))
    # if (DATA_DIR / "mapping_docs.xlsx").exists():
    #     context_parts.append(load_mapping_docs(DATA_DIR / "mapping_docs.xlsx"))
    # ... etc

    # For demo, generate synthetic examples
    examples = generate_synthetic_training_data()

    # Write to JSONL
    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        for ex in examples:
            f.write(json.dumps(ex, ensure_ascii=False) + "\n")

    print(f"Created {len(examples)} training examples at: {OUTPUT_FILE}")
    print(f"File size: {OUTPUT_FILE.stat().st_size / 1024:.1f} KB")
    print("\nNext: Run 03_finetune_qlora.py to start fine-tuning on your RTX 3050")


if __name__ == "__main__":
    main()
