#!/usr/bin/env python3
"""
=============================================================================
05_rag_pipeline.py — Offline RAG Pipeline for JSON Config Generation
=============================================================================
Complete RAG flow:
  1. Load input files (JSON, Excel, CSV, Markdown)
  2. Chunk and embed documents using local sentence-transformers
  3. Store in FAISS vector DB (file-based, no external DB needed)
  4. Retrieve relevant context for each query
  5. Generate JSON config via Ollama (local LLM)

OFFLINE CAPABLE: 100% (after initial model downloads)
=============================================================================
"""

import json
import pandas as pd
from pathlib import Path
from typing import List, Dict, Optional

# LangChain imports
from langchain_community.document_loaders import (
    JSONLoader,
    UnstructuredMarkdownLoader,
    CSVLoader,
)
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_ollama import OllamaLLM
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate

# =============================================================================
# CONFIGURATION
# =============================================================================
DATA_DIR = Path("./data")
VECTOR_STORE_PATH = "./models/vectorstore"
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"  # 80MB, runs on CPU
OLLAMA_MODEL = "pipeline-config-generator"  # Your fine-tuned model
OLLAMA_BASE_URL = "http://localhost:11434"  # Default Ollama API

# =============================================================================
# 1. Document Loaders
# =============================================================================
def load_json_documents(path: Path) -> List[Dict]:
    """Load JSON event definitions."""
    if not path.exists():
        return []
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    # Convert to text documents
    docs = []
    for item in data if isinstance(data, list) else [data]:
        text = json.dumps(item, indent=2)
        docs.append({"page_content": text, "metadata": {"source": str(path), "type": "json"}})
    return docs


def load_excel_documents(path: Path) -> List[Dict]:
    """Load Excel mapping documents."""
    if not path.exists():
        return []
    docs = []
    xls = pd.ExcelFile(path)
    for sheet in xls.sheet_names:
        df = pd.read_excel(path, sheet_name=sheet)
        text = f"Sheet: {sheet}\n{df.to_string(index=False)}"
        docs.append({"page_content": text, "metadata": {"source": str(path), "sheet": sheet, "type": "excel"}})
    return docs


def load_csv_documents(path: Path) -> List[Dict]:
    """Load CSV/Parquet schema information."""
    if not path.exists():
        return []
    if path.suffix == ".parquet":
        df = pd.read_parquet(path)
    else:
        df = pd.read_csv(path)
    text = f"Table Schema:\n{df.to_string(index=False)}"
    return [{"page_content": text, "metadata": {"source": str(path), "type": "csv"}}]


def load_markdown_documents(path: Path) -> List[Dict]:
    """Load markdown prompt templates."""
    if not path.exists():
        return []
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()
    return [{"page_content": text, "metadata": {"source": str(path), "type": "markdown"}}]


# =============================================================================
# 2. Vector Store (Knowledge Base)
# =============================================================================
def build_vector_store(force_rebuild: bool = False):
    """Build or load FAISS vector store from input documents."""

    # Check if vector store exists
    if not force_rebuild and Path(VECTOR_STORE_PATH).exists():
        print("Loading existing vector store...")
        embeddings = HuggingFaceEmbeddings(
            model_name=EMBEDDING_MODEL,
            model_kwargs={"device": "cpu"},  # Embeddings on CPU, LLM on GPU/CPU
            encode_kwargs={"normalize_embeddings": True}
        )
        return FAISS.load_local(VECTOR_STORE_PATH, embeddings, allow_dangerous_deserialization=True)

    print("Building vector store from input documents...")

    # Load all documents
    all_docs = []
    all_docs.extend(load_json_documents(DATA_DIR / "source_events.json"))
    all_docs.extend(load_excel_documents(DATA_DIR / "mapping_docs.xlsx"))
    all_docs.extend(load_csv_documents(DATA_DIR / "schema_info.csv"))
    all_docs.extend(load_csv_documents(DATA_DIR / "schema_info.parquet"))
    all_docs.extend(load_markdown_documents(DATA_DIR / "prompt_template.md"))

    if not all_docs:
        print("WARNING: No input documents found in ./data/")
        print("Using synthetic examples for demonstration.")
        all_docs = get_synthetic_documents()

    # Convert to LangChain Document objects
    from langchain.schema import Document
    documents = [Document(page_content=d["page_content"], metadata=d["metadata"]) for d in all_docs]

    # Split into chunks
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=512,
        chunk_overlap=50,
        separators=["\n\n", "\n", " ", ""]
    )
    chunks = text_splitter.split_documents(documents)
    print(f"Created {len(chunks)} chunks from {len(documents)} documents")

    # Create embeddings (local, no API calls)
    embeddings = HuggingFaceEmbeddings(
        model_name=EMBEDDING_MODEL,
        model_kwargs={"device": "cpu"},
        encode_kwargs={"normalize_embeddings": True}
    )

    # Build and save FAISS index
    vectorstore = FAISS.from_documents(chunks, embeddings)
    vectorstore.save_local(VECTOR_STORE_PATH)
    print(f"Vector store saved to: {VECTOR_STORE_PATH}")

    return vectorstore


def get_synthetic_documents() -> List[Dict]:
    """Synthetic documents for demo when real files are missing."""
    return [
        {
            "page_content": """Event: user_signup, Type: kafka_topic
Schema: user_id STRING, timestamp LONG, email STRING, country STRING
Source: Kafka topic 'user_signup', JSON format""",
            "metadata": {"source": "synthetic", "type": "json"}
        },
        {
            "page_content": """Mapping: users table
user_id -> user_id (direct)
email -> email_address (direct)
country -> country_code (UPPER transformation)
timestamp -> created_at (FROM_UNIXTIME)""",
            "metadata": {"source": "synthetic", "type": "excel"}
        },
        {
            "page_content": """Table: dim_users
Columns: user_id STRING PK, email_address STRING, country_code STRING(2), created_at TIMESTAMP
Partition: created_at (daily)""",
            "metadata": {"source": "synthetic", "type": "csv"}
        },
    ]


# =============================================================================
# 3. Custom Prompt Template for JSON Output
# =============================================================================
JSON_GENERATION_TEMPLATE = """You are an expert data pipeline engineer. Based on the provided context, generate a precise JSON configuration file.

CONTEXT:
{context}

USER REQUIREMENT:
{question}

INSTRUCTIONS:
1. Output ONLY valid JSON. Do NOT wrap in markdown code blocks.
2. Include all necessary fields: job_name, execution_engine, source, transformations, sink.
3. Use standard Spark SQL functions for transformations.
4. Ensure the JSON is syntactically correct and properly nested.

JSON OUTPUT:"""

json_prompt = PromptTemplate(
    template=JSON_GENERATION_TEMPLATE,
    input_variables=["context", "question"]
)


# =============================================================================
# 4. RAG Pipeline
# =============================================================================
def create_rag_pipeline():
    """Create the complete RAG pipeline."""

    # Build/load vector store
    vectorstore = build_vector_store()

    # Create retriever (top-5 most relevant chunks)
    retriever = vectorstore.as_retriever(
        search_type="similarity",
        search_kwargs={"k": 5}
    )

    # Initialize local LLM via Ollama
    llm = OllamaLLM(
        model=OLLAMA_MODEL,
        base_url=OLLAMA_BASE_URL,
        temperature=0.1,       # Low temp for deterministic JSON
        num_ctx=4096,          # Context window
        num_predict=2048,      # Max output tokens
    )

    # Create QA chain
    qa_chain = RetrievalQA.from_chain_type(
        llm=llm,
        chain_type="stuff",    # Simple concatenation of retrieved docs
        retriever=retriever,
        return_source_documents=True,
        chain_type_kwargs={"prompt": json_prompt}
    )

    return qa_chain


# =============================================================================
# 5. Generate Config
# =============================================================================
def generate_pipeline_config(requirement: str) -> Dict:
    """Generate a JSON pipeline config from a natural language requirement."""

    qa_chain = create_rag_pipeline()

    print(f"\nQuery: {requirement}")
    print("Retrieving relevant context and generating config...")

    result = qa_chain.invoke({"query": requirement})

    response_text = result["result"]
    source_docs = result.get("source_documents", [])

    # Try to parse JSON from response
    try:
        # Clean up potential markdown wrappers
        cleaned = response_text.strip()
        if cleaned.startswith("```json"):
            cleaned = cleaned[7:]
        if cleaned.startswith("```"):
            cleaned = cleaned[3:]
        if cleaned.endswith("```"):
            cleaned = cleaned[:-3]
        cleaned = cleaned.strip()

        config = json.loads(cleaned)
        print("\nGenerated Config (validated JSON):")
        print(json.dumps(config, indent=2))
        return config

    except json.JSONDecodeError as e:
        print(f"WARNING: Generated output is not valid JSON: {e}")
        print("Raw output:")
        print(response_text)
        return {"raw_output": response_text, "error": str(e)}


# =============================================================================
# MAIN
# =============================================================================
def main():
    print("=== Offline RAG Pipeline for Pipeline Config Generation ===")
    print(f"Embedding Model: {EMBEDDING_MODEL}")
    print(f"LLM: {OLLAMA_MODEL} (via Ollama)")
    print(f"Vector DB: FAISS (local file-based)")
    print("")

    # Example queries
    test_queries = [
        "Generate a Spark streaming job config that reads user_signup Kafka topic and writes to dim_users table with all column mappings.",
        "Create a SQL ETL pipeline for batch processing orders with the given transformations.",
    ]

    for query in test_queries:
        config = generate_pipeline_config(query)
        print("\n" + "="*60 + "\n")


if __name__ == "__main__":
    main()
