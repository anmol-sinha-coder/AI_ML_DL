#!/usr/bin/env python3
"""
=============================================================================
06_spark_udf.py — Spark UDF for Distributed JSON Config Generation
=============================================================================
This module provides PySpark UDFs that call the local LLM to generate
pipeline configs for each row in a DataFrame.

TWO MODES:
  1. Ollama API Mode: Calls local Ollama HTTP API (requires Ollama running)
  2. llama-cpp-python Mode: Direct GGUF loading (no Ollama needed, portable)

The generated JSON configs are returned as struct columns.

OFFLINE CAPABLE: Yes (Mode 2 is fully self-contained)
=============================================================================
"""

import json
import logging
from typing import Optional
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.functions import udf, col, struct, to_json
from pyspark.sql.types import (
    StructType, StructField, StringType, MapType, ArrayType
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# =============================================================================
# CONFIGURATION
# =============================================================================
OLLAMA_URL = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "pipeline-config-generator"
GGUF_PATH = "./models/gguf/model-q4_k_m.gguf"  # For Mode 2 (direct)

# =============================================================================
# MODE 1: Ollama API Client (requires Ollama server running)
# =============================================================================
class OllamaClient:
    """Lightweight Ollama API client for Spark UDFs."""

    def __init__(self, base_url: str = "http://localhost:11434", model: str = OLLAMA_MODEL):
        self.base_url = base_url
        self.model = model
        self._session = None

    def _get_session(self):
        import requests
        if self._session is None:
            self._session = requests.Session()
        return self._session

    def generate(self, prompt: str, system: Optional[str] = None, temperature: float = 0.1) -> str:
        """Generate text via Ollama API."""
        import requests

        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": temperature,
                "top_p": 0.5,
                "num_ctx": 4096,
                "num_predict": 2048,
            }
        }
        if system:
            payload["system"] = system

        try:
            resp = self._get_session().post(
                f"{self.base_url}/api/generate",
                json=payload,
                timeout=120
            )
            resp.raise_for_status()
            return resp.json().get("response", "")
        except Exception as e:
            logger.error(f"Ollama API error: {e}")
            return json.dumps({"error": str(e)})


# =============================================================================
# MODE 2: Direct GGUF Loading (llama-cpp-python, no Ollama needed)
# =============================================================================
class DirectGGUFModel:
    """
    Direct GGUF model loader using llama-cpp-python.
    This is FULLY SELF-CONTAINED and works without Ollama.
    Best for: CPU-only systems, portable deployment, Spark executors.
    """

    _instance = None
    _model = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self, model_path: str = GGUF_PATH, n_ctx: int = 4096):
        if self._model is not None:
            return

        from llama_cpp import Llama

        logger.info(f"Loading GGUF model: {model_path}")
        # n_threads = CPU cores for inference
        # n_gpu_layers = 0 for CPU-only, or auto-detect for GPU
        import os
        n_threads = os.cpu_count() or 4

        self._model = Llama(
            model_path=model_path,
            n_ctx=n_ctx,
            n_threads=n_threads,
            n_gpu_layers=0,  # CPU inference (set to 999 for GPU auto-offload)
            verbose=False,
        )
        logger.info(f"Model loaded. Using {n_threads} CPU threads.")

    def generate(self, prompt: str, system: Optional[str] = None, temperature: float = 0.1) -> str:
        """Generate text directly from GGUF model."""
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        try:
            output = self._model.create_chat_completion(
                messages=messages,
                temperature=temperature,
                top_p=0.5,
                max_tokens=2048,
            )
            return output["choices"][0]["message"]["content"]
        except Exception as e:
            logger.error(f"GGUF inference error: {e}")
            return json.dumps({"error": str(e)})


# =============================================================================
# SYSTEM PROMPT (shared across both modes)
# =============================================================================
SYSTEM_PROMPT = """You are an expert data pipeline engineer. Generate precise JSON configuration files for Spark/SQL pipelines. Output ONLY valid JSON with no markdown formatting."""


# =============================================================================
# PROMPT BUILDER
# =============================================================================
def build_prompt(row_dict: dict) -> str:
    """Build prompt from DataFrame row containing pipeline requirements."""

    parts = ["Generate a pipeline configuration JSON based on the following requirements:"]

    if "job_name" in row_dict:
        parts.append(f"\nJob Name: {row_dict['job_name']}")
    if "source_type" in row_dict:
        parts.append(f"Source Type: {row_dict['source_type']}")
    if "source_details" in row_dict:
        parts.append(f"Source Details: {row_dict['source_details']}")
    if "target_table" in row_dict:
        parts.append(f"Target Table: {row_dict['target_table']}")
    if "mappings" in row_dict:
        parts.append(f"Column Mappings: {json.dumps(row_dict['mappings'])}")
    if "transformations" in row_dict:
        parts.append(f"Transformations: {json.dumps(row_dict['transformations'])}")
    if "additional_context" in row_dict:
        parts.append(f"Additional Context: {row_dict['additional_context']}")

    parts.append("\nGenerate the complete pipeline JSON config:")
    return "\n".join(parts)


# =============================================================================
# UDF DEFINITIONS
# =============================================================================
def make_ollama_udf(ollama_url: str = OLLAMA_URL, model: str = OLLAMA_MODEL):
    """Create a Spark UDF that calls Ollama API."""
    client = OllamaClient(base_url=ollama_url, model=model)

    def generate_config_udf(job_name: str, source_type: str, source_details: str,
                          target_table: str, mappings: str, transformations: str) -> str:
        """UDF: Generate JSON config via Ollama API."""
        row = {
            "job_name": job_name,
            "source_type": source_type,
            "source_details": source_details,
            "target_table": target_table,
            "mappings": json.loads(mappings) if mappings else {},
            "transformations": json.loads(transformations) if transformations else {},
        }
        prompt = build_prompt(row)
        response = client.generate(prompt, system=SYSTEM_PROMPT)

        # Validate JSON
        try:
            parsed = json.loads(response)
            return json.dumps(parsed)
        except:
            return json.dumps({"raw_output": response, "parsed": False})

    return udf(generate_config_udf, StringType())


def make_gguf_udf(gguf_path: str = GGUF_PATH):
    """Create a Spark UDF that loads GGUF directly (no Ollama needed)."""
    model = DirectGGUFModel(model_path=gguf_path)

    def generate_config_gguf(job_name: str, source_type: str, source_details: str,
                             target_table: str, mappings: str, transformations: str) -> str:
        """UDF: Generate JSON config via direct GGUF inference."""
        row = {
            "job_name": job_name,
            "source_type": source_type,
            "source_details": source_details,
            "target_table": target_table,
            "mappings": json.loads(mappings) if mappings else {},
            "transformations": json.loads(transformations) if transformations else {},
        }
        prompt = build_prompt(row)
        response = model.generate(prompt, system=SYSTEM_PROMPT)

        try:
            parsed = json.loads(response)
            return json.dumps(parsed)
        except:
            return json.dumps({"raw_output": response, "parsed": False})

    return udf(generate_config_gguf, StringType())


# =============================================================================
# SPARK PIPELINE
# =============================================================================
def run_spark_pipeline(mode: str = "gguf"):
    """
    Run the complete Spark pipeline.

    Args:
        mode: "ollama" (requires Ollama server) or "gguf" (self-contained)
    """

    # Initialize Spark
    spark = SparkSession.builder         .appName("PipelineConfigGenerator")         .config("spark.sql.adaptive.enabled", "true")         .config("spark.executor.memory", "4g")         .config("spark.driver.memory", "4g")         .getOrCreate()

    # Sample input DataFrame (in production, load from your data source)
    input_data = [
        {
            "job_name": "kafka_to_dim_users",
            "source_type": "kafka",
            "source_details": "topic: user_signup, format: json, brokers: localhost:9092",
            "target_table": "dim_users",
            "mappings": json.dumps({
                "user_id": "user_id",
                "email": "email_address",
                "country": "country_code",
                "timestamp": "created_at"
            }),
            "transformations": json.dumps({
                "country_code": "UPPER(country)",
                "created_at": "FROM_UNIXTIME(timestamp/1000)"
            }),
        },
        {
            "job_name": "batch_orders_etl",
            "source_type": "jdbc",
            "source_details": "table: staging.orders, driver: postgres",
            "target_table": "fct_orders",
            "mappings": json.dumps({
                "order_id": "order_id",
                "amount": "total_amount",
                "currency": "currency",
                "status": "order_status"
            }),
            "transformations": json.dumps({
                "total_amount": "CAST(amount AS DECIMAL(18,2))",
                "order_status": "CASE WHEN status='1' THEN 'CONFIRMED' ELSE 'PENDING' END"
            }),
        },
    ]

    df = spark.createDataFrame(input_data)
    print("Input DataFrame:")
    df.show(truncate=False)

    # Register UDF
    if mode == "ollama":
        print("\nUsing Ollama API mode (ensure Ollama is running)...")
        gen_udf = make_ollama_udf()
    else:
        print("\nUsing Direct GGUF mode (self-contained, CPU inference)...")
        gen_udf = make_gguf_udf()

    # Apply UDF to generate configs
    result_df = df.withColumn(
        "pipeline_config_json",
        gen_udf(
            col("job_name"),
            col("source_type"),
            col("source_details"),
            col("target_table"),
            col("mappings"),
            col("transformations"),
        )
    )

    # Parse JSON string to struct column (for proper Spark SQL handling)
    # Note: In production, define a proper schema. Here we keep as JSON string for flexibility.
    result_df = result_df.withColumn("config_struct", col("pipeline_config_json"))

    print("\nOutput DataFrame with Generated Configs:")
    result_df.select("job_name", "target_table", "pipeline_config_json").show(truncate=False)

    # Save results
    output_path = "./data/output_pipeline_configs"
    result_df.write.mode("overwrite").json(output_path)
    print(f"\nResults saved to: {output_path}")

    spark.stop()


# =============================================================================
# MAIN
# =============================================================================
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["ollama", "gguf"], default="gguf",
                        help="Inference mode: ollama (API) or gguf (direct)")
    args = parser.parse_args()

    run_spark_pipeline(mode=args.mode)
