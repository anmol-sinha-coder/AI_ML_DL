#!/usr/bin/env python3
"""
=============================================================================
07_test_offline_cpu.py — Portable CPU-Only Inference Test
=============================================================================
This script tests the exported GGUF model on a CPU-only system WITHOUT:
  - Ollama installation
  - PyTorch/CUDA
  - HuggingFace transformers
  - Internet connection

REQUIREMENTS (minimal):
  - Python 3.8+
  - llama-cpp-python (pip install llama-cpp-python --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cpu)
  - The .gguf model file

This is your "serialized model" that can be copied to any low-end system.
=============================================================================
"""

import json
import sys
from pathlib import Path
from typing import Optional

# =============================================================================
# CONFIGURATION
# =============================================================================
GGUF_MODEL_PATH = "./models/gguf/model-q4_k_m.gguf"  # Adjust path as needed
N_THREADS = 4       # Adjust based on CPU cores
N_CTX = 4096        # Context window

# =============================================================================
# MODEL LOADER (Singleton pattern for efficiency)
# =============================================================================
class OfflinePipelineModel:
    """
    Self-contained offline model for pipeline config generation.
    Loads once, reuses for multiple inferences.
    """

    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self, model_path: str = GGUF_MODEL_PATH):
        if hasattr(self, '_initialized') and self._initialized:
            return

        try:
            from llama_cpp import Llama
        except ImportError:
            print("ERROR: llama-cpp-python not installed.")
            print("Install with: pip install llama-cpp-python")
            sys.exit(1)

        if not Path(model_path).exists():
            print(f"ERROR: Model file not found: {model_path}")
            print("Please ensure the GGUF file is copied to this system.")
            sys.exit(1)

        print(f"Loading model: {model_path}")
        print(f"This may take 10-30 seconds on first load...")

        self.model = Llama(
            model_path=model_path,
            n_ctx=N_CTX,
            n_threads=N_THREADS,
            n_gpu_layers=0,      # Force CPU-only
            verbose=False,
        )

        self._initialized = True
        print(f"Model loaded successfully!")
        print(f"Using {N_THREADS} CPU threads, {N_CTX} context length")

    def generate_config(
        self,
        requirement: str,
        system_prompt: Optional[str] = None,
        temperature: float = 0.1,
        max_tokens: int = 2048
    ) -> dict:
        """
        Generate a pipeline config JSON from a natural language requirement.

        Args:
            requirement: Natural language description of the pipeline
            system_prompt: Optional system prompt override
            temperature: Sampling temperature (lower = more deterministic)
            max_tokens: Maximum output tokens

        Returns:
            dict: Parsed JSON config or error dict
        """

        default_system = """You are an expert data pipeline engineer specializing in Apache Spark and SQL ETL.
Generate precise, valid JSON configuration files for data pipeline jobs.
Output ONLY valid JSON. No markdown code blocks, no explanations."""

        messages = [
            {"role": "system", "content": system_prompt or default_system},
            {"role": "user", "content": requirement}
        ]

        print(f"\nGenerating config for: {requirement[:80]}...")

        output = self.model.create_chat_completion(
            messages=messages,
            temperature=temperature,
            top_p=0.5,
            max_tokens=max_tokens,
        )

        response_text = output["choices"][0]["message"]["content"]

        # Parse JSON
        try:
            cleaned = response_text.strip()
            # Remove markdown wrappers if present
            for prefix in ["```json", "```JSON", "```"]:
                if cleaned.startswith(prefix):
                    cleaned = cleaned[len(prefix):].strip()
            if cleaned.endswith("```"):
                cleaned = cleaned[:-3].strip()

            config = json.loads(cleaned)
            return {
                "success": True,
                "config": config,
                "raw_tokens": output["usage"]["total_tokens"],
            }
        except json.JSONDecodeError as e:
            return {
                "success": False,
                "error": f"JSON parse error: {e}",
                "raw_output": response_text,
            }


# =============================================================================
# TEST CASES
# =============================================================================
def run_tests():
    """Run comprehensive tests on the offline model."""

    print("=" * 60)
    print("OFFLINE CPU-ONLY MODEL TEST")
    print("=" * 60)
    print(f"Model: {GGUF_MODEL_PATH}")
    print(f"Platform: CPU-only (no GPU required)")
    print(f"Dependencies: llama-cpp-python only")
    print("=" * 60)

    model = OfflinePipelineModel()

    test_cases = [
        {
            "name": "Kafka Streaming Job",
            "requirement": """Generate a Spark streaming job JSON config:
- Source: Kafka topic 'user_signup' (JSON format, brokers: localhost:9092)
- Columns: user_id (string), email (string), country (string), timestamp (long)
- Target: dim_users table
- Mappings: user_id->user_id, email->email_address, country->UPPER(country)->country_code, timestamp->FROM_UNIXTIME(timestamp/1000)->created_at
- Mode: streaming, write: append"""
        },
        {
            "name": "SQL Batch ETL",
            "requirement": """Generate a SQL batch ETL JSON config:
- Source: staging.orders table
- Columns: order_id, amount (decimal), currency, status
- Target: fct_orders
- Transformations: amount->CAST(amount AS DECIMAL(18,2))->total_amount, status->CASE WHEN status='1' THEN 'CONFIRMED' ELSE 'PENDING' END->order_status
- Add etl_timestamp = CURRENT_TIMESTAMP()
- Write mode: merge on order_id"""
        },
        {
            "name": "Simple Direct Mapping",
            "requirement": "Generate a simple Spark job config that reads CSV file '/data/input.csv' and writes to Parquet '/data/output.parquet' with direct column mappings for id, name, and timestamp."
        },
    ]

    results = []
    for test in test_cases:
        print(f"\n{'='*60}")
        print(f"TEST: {test['name']}")
        print(f"{'='*60}")

        result = model.generate_config(test["requirement"])
        results.append({"test": test["name"], "result": result})

        if result["success"]:
            print(f"✅ SUCCESS (tokens: {result['raw_tokens']})")
            print("Generated Config:")
            print(json.dumps(result["config"], indent=2))
        else:
            print(f"❌ FAILED: {result['error']}")
            print("Raw output:")
            print(result["raw_output"][:500])

    # Summary
    print(f"\n{'='*60}")
    print("TEST SUMMARY")
    print(f"{'='*60}")
    passed = sum(1 for r in results if r["result"]["success"])
    print(f"Passed: {passed}/{len(results)}")

    for r in results:
        status = "✅ PASS" if r["result"]["success"] else "❌ FAIL"
        print(f"  {status} - {r['test']}")

    return results


# =============================================================================
# INTERACTIVE MODE
# =============================================================================
def interactive_mode():
    """Run interactive config generation."""
    model = OfflinePipelineModel()

    print("\n" + "=" * 60)
    print("INTERACTIVE MODE")
    print("Type your pipeline requirement (or 'quit' to exit)")
    print("=" * 60)

    while True:
        try:
            requirement = input("\n> ")
            if requirement.lower() in ["quit", "exit", "q"]:
                break
            if not requirement.strip():
                continue

            result = model.generate_config(requirement)

            if result["success"]:
                print("\nGenerated Config:")
                print(json.dumps(result["config"], indent=2))
            else:
                print(f"\nError: {result['error']}")
                print(f"Raw: {result['raw_output'][:300]}")

        except KeyboardInterrupt:
            print("\nExiting...")
            break
        except Exception as e:
            print(f"Error: {e}")


# =============================================================================
# MAIN
# =============================================================================
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Offline CPU-Only LLM Inference Test")
    parser.add_argument("--interactive", "-i", action="store_true", help="Run interactive mode")
    parser.add_argument("--model", "-m", default=GGUF_MODEL_PATH, help="Path to GGUF model file")
    args = parser.parse_args()

    GGUF_MODEL_PATH = args.model

    if args.interactive:
        interactive_mode()
    else:
        run_tests()
