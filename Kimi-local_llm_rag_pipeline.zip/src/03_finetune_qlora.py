#!/usr/bin/env python3
"""
=============================================================================
03_finetune_qlora.py — QLoRA Fine-Tuning on NVIDIA RTX 3050 (4GB VRAM)
=============================================================================
This script fine-tunes Qwen2.5-Coder-3B-Instruct using 4-bit QLoRA.
VRAM usage: ~3.2-3.8 GB (fits comfortably in RTX 3050 4GB)

REQUIREMENTS:
  - NVIDIA GPU with 4GB+ VRAM
  - CUDA 12.4+ drivers
  - ~10GB disk space for model + checkpoints

OFFLINE CAPABLE: Yes, after initial model download
=============================================================================
"""

import os
import torch
from pathlib import Path
from datasets import load_dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig,
    TrainingArguments,
)
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from trl import SFTTrainer

# =============================================================================
# CONFIGURATION — Adjust these for your setup
# =============================================================================
BASE_MODEL = "Qwen/Qwen2.5-Coder-3B-Instruct"  # 3B params, excellent for code/JSON
# Alternative: "Qwen/Qwen2.5-3B-Instruct" for general instruction following
# Alternative: "microsoft/Phi-3-mini-4k-instruct" (3.8B, may be tight on 4GB)
# Alternative: "meta-llama/Llama-3.2-3B-Instruct" (needs HuggingFace auth)

DATASET_PATH = "./data/training_dataset.jsonl"
OUTPUT_DIR = "./models/qwen2.5-coder-3b-qlora"

# QLoRA Hyperparameters (optimized for 4GB VRAM)
LORA_R = 16               # LoRA rank (8 for extreme memory constraint, 32 for quality)
LORA_ALPHA = 32           # Usually 2x rank
LORA_DROPOUT = 0.05
TARGET_MODULES = [        # Attention + MLP layers for Qwen
    "q_proj", "k_proj", "v_proj", "o_proj",
    "gate_proj", "up_proj", "down_proj",
]

# Training Hyperparameters
MAX_SEQ_LENGTH = 512      # 512 is safe for 4GB; reduce to 256 if OOM
BATCH_SIZE = 1            # MUST be 1 for 4GB VRAM
GRAD_ACCUMULATION = 8     # Effective batch = 8
NUM_EPOCHS = 3
LEARNING_RATE = 2e-4
WARMUP_RATIO = 0.03
SAVE_STEPS = 50
LOGGING_STEPS = 10

# =============================================================================
# 1. Setup 4-bit Quantization (QLoRA)
# =============================================================================
def get_bnb_config():
    """Configure 4-bit Normal Float quantization for minimal VRAM."""
    compute_dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
    return BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",           # Normal Float 4 (best quality/VRAM tradeoff)
        bnb_4bit_compute_dtype=compute_dtype,
        bnb_4bit_use_double_quant=True,       # Nested quantization saves ~0.5GB
    )

# =============================================================================
# 2. Load Model & Tokenizer
# =============================================================================
def load_model_and_tokenizer():
    """Load base model with 4-bit quantization."""
    print(f"Loading base model: {BASE_MODEL}")
    print(f"GPU: {torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU'}")
    print(f"VRAM: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB" if torch.cuda.is_available() else "N/A")

    tokenizer = AutoTokenizer.from_pretrained(
        BASE_MODEL,
        trust_remote_code=True,
        padding_side="right",
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        BASE_MODEL,
        quantization_config=get_bnb_config(),
        device_map="auto",                    # Automatically place layers on GPU
        trust_remote_code=True,
        torch_dtype=torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16,
    )

    # Prepare model for k-bit training (gradient checkpointing, etc.)
    model = prepare_model_for_kbit_training(model)

    print(f"Model loaded. Trainable params will be added via LoRA.")
    return model, tokenizer

# =============================================================================
# 3. Configure LoRA
# =============================================================================
def setup_lora(model):
    """Attach LoRA adapters to the quantized model."""
    lora_config = LoraConfig(
        r=LORA_R,
        lora_alpha=LORA_ALPHA,
        target_modules=TARGET_MODULES,
        lora_dropout=LORA_DROPOUT,
        bias="none",
        task_type="CAUSAL_LM",
        # For JSON output tasks, consider adding modules_to_save for embeddings
    )

    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()
    return model

# =============================================================================
# 4. Load & Format Dataset
# =============================================================================
def formatting_prompts_func(example):
    """Format dataset examples using Qwen chat template."""
    messages = example["messages"]
    # Qwen2.5 uses this chat template automatically via apply_chat_template
    return {"text": messages}

def load_dataset_for_training():
    """Load and preprocess training dataset."""
    dataset = load_dataset("json", data_files=DATASET_PATH, split="train")

    def apply_template(example):
        text = tokenizer.apply_chat_template(
            example["messages"],
            tokenize=False,
            add_generation_prompt=False,
        )
        return {"text": text}

    dataset = dataset.map(apply_template, batched=False)
    return dataset

# =============================================================================
# 5. Training
# =============================================================================
def train():
    global tokenizer

    # Create output directory
    Path(OUTPUT_DIR).mkdir(parents=True, exist_ok=True)

    # Load model
    model, tokenizer = load_model_and_tokenizer()
    model = setup_lora(model)

    # Load dataset
    dataset = load_dataset_for_training()
    print(f"Dataset loaded: {len(dataset)} examples")

    # Training arguments (memory-optimized for 4GB)
    use_bf16 = torch.cuda.is_bf16_supported()

    training_args = TrainingArguments(
        output_dir=OUTPUT_DIR,
        num_train_epochs=NUM_EPOCHS,
        per_device_train_batch_size=BATCH_SIZE,
        gradient_accumulation_steps=GRAD_ACCUMULATION,
        learning_rate=LEARNING_RATE,
        warmup_ratio=WARMUP_RATIO,
        lr_scheduler_type="cosine",
        logging_steps=LOGGING_STEPS,
        save_steps=SAVE_STEPS,
        save_total_limit=2,                   # Keep only last 2 checkpoints
        max_grad_norm=0.3,                    # Gradient clipping for stability
        fp16=not use_bf16,
        bf16=use_bf16,
        optim="paged_adamw_8bit",             # 8-bit AdamW saves VRAM
        group_by_length=True,                 # Reduce padding overhead
        report_to="none",                     # No wandb/tensorboard (offline)
        remove_unused_columns=False,
    )

    # Initialize SFT Trainer
    trainer = SFTTrainer(
        model=model,
        tokenizer=tokenizer,
        train_dataset=dataset,
        args=training_args,
        max_seq_length=MAX_SEQ_LENGTH,
        dataset_text_field="text",
        packing=False,                        # True saves memory but may hurt quality
    )

    # Train
    print("\n=== Starting QLoRA Training ===")
    print(f"Effective batch size: {BATCH_SIZE * GRAD_ACCUMULATION}")
    print(f"Max sequence length: {MAX_SEQ_LENGTH}")
    print(f"Epochs: {NUM_EPOCHS}")
    print(f"Learning rate: {LEARNING_RATE}")
    print("")

    trainer.train()

    # Save final adapter
    adapter_path = Path(OUTPUT_DIR) / "final_adapter"
    trainer.save_model(adapter_path)
    tokenizer.save_pretrained(adapter_path)

    print(f"\n=== Training Complete ===")
    print(f"Adapter saved to: {adapter_path}")
    print(f"Adapter size: {sum(f.stat().st_size for f in adapter_path.rglob('*')) / 1e6:.1f} MB")
    print("\nNext: Run 04_merge_export_gguf.py to merge and export to GGUF")

# =============================================================================
# MAIN
# =============================================================================
if __name__ == "__main__":
    # Verify GPU
    if not torch.cuda.is_available():
        print("WARNING: No CUDA GPU detected. Training will be extremely slow on CPU.")
        print("This script is designed for NVIDIA RTX 3050 with 4GB VRAM.")
        response = input("Continue anyway? (y/N): ")
        if response.lower() != "y":
            exit(1)

    train()
