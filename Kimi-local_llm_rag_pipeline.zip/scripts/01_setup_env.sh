#!/bin/bash
# =============================================================================
# 01_setup_env.sh — Environment Setup for Local LLM RAG Pipeline
# =============================================================================
# Run this ONCE on your RTX 3050 system (needs internet for package install)
# After setup, the entire pipeline can run OFFLINE
# =============================================================================

set -e

echo "=== Local LLM RAG Pipeline — Environment Setup ==="
echo "Target GPU: NVIDIA RTX 3050 (4GB VRAM)"
echo "Target Model: Qwen2.5-Coder-3B-Instruct (QLoRA fine-tuned)"
echo ""

# 1. Create conda environment (recommended for isolation)
conda create -n local_llm_rag python=3.11 -y || true
source "$(conda info --base)/etc/profile.d/conda.sh"
conda activate local_llm_rag

# 2. Install PyTorch with CUDA support (for training on RTX 3050)
pip install torch==2.5.1 torchvision==0.20.1 torchaudio==2.5.1 --index-url https://download.pytorch.org/whl/cu124

# 3. Install HuggingFace ecosystem (for QLoRA fine-tuning)
pip install transformers==4.48.0 datasets==3.2.0 accelerate==1.2.0 peft==0.14.0 bitsandbytes==0.45.0

# 4. Install TRL for supervised fine-tuning
pip install trl==0.13.0

# 5. Install LangChain + vector DB (for RAG pipeline)
pip install langchain==0.3.0 langchain-community==0.3.0 langchain-ollama==0.2.0
pip install chromadb==0.6.0 faiss-cpu==1.9.0  # faiss-cpu for portability

# 6. Install sentence-transformers (local embeddings, no API needed)
pip install sentence-transformers==3.3.0

# 7. Install Ollama (for serving GGUF models locally)
# WSL/Linux:
curl -fsSL https://ollama.com/install.sh | sh

# 8. Install llama-cpp-python (for CPU fallback / portable inference)
pip install llama-cpp-python==0.3.5 --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cpu

# 9. Data processing libraries
pip install pandas==2.2.3 openpyxl==3.1.5 pyarrow==18.1.0

# 10. For GGUF export (llama.cpp conversion tools)
pip install gguf==0.13.0

echo ""
echo "=== Setup Complete ==="
echo "Activate environment: conda activate local_llm_rag"
echo "Next: Run 02_prepare_data.py to create your training dataset"
