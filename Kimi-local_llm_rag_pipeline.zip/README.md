# Local LLM RAG Pipeline for JSON Config Generation

> **Complete offline pipeline** for fine-tuning, deploying, and running a local LLM that generates Spark/SQL pipeline JSON configurations from mapping documents and schema files.

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Hardware Requirements](#hardware-requirements)
3. [Model Selection Deep Dive](#model-selection-deep-dive)
4. [Step-by-Step Execution Guide](#step-by-step-execution-guide)
5. [File Structure](#file-structure)
6. [Online vs Offline Segments](#online-vs-offline-segments)
7. [CPU Portability Guide](#cpu-portability-guide)
8. [Spark UDF Integration](#spark-udf-integration)
9. [Troubleshooting](#troubleshooting)

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         TRAINING PHASE (RTX 3050 GPU)                        │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐    ┌───────────┐  │
│  │ Input Files  │───>│  Dataset     │───>│ QLoRA Fine   │───>│  Merged   │  │
│  │ (JSON/Excel/ │    │  Preparation │    │ Tune (4-bit) │    │  Model    │  │
│  │  CSV/MD)     │    │              │    │  3 epochs    │    │           │  │
│  └──────────────┘    └──────────────┘    └──────────────┘    └─────┬─────┘  │
│                                                                     │        │
│  ┌──────────────────────────────────────────────────────────────────┘        │
│  ▼                                                                           │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐                   │
│  │ llama.cpp    │───>│   GGUF       │───>│  Ollama      │                   │
│  │ Conversion   │    │  Quantized   │    │  Modelfile   │                   │
│  │              │    │  (~1.8GB)    │    │              │                   │
│  └──────────────┘    └──────────────┘    └──────────────┘                   │
└─────────────────────────────────────────────────────────────────────────────┘
                                      │
                                      ▼ (COPY TO ANY SYSTEM)
┌─────────────────────────────────────────────────────────────────────────────┐
│                      INFERENCE PHASE (CPU-Only or GPU)                       │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  RAG PIPELINE (LangChain + FAISS + sentence-transformers)           │    │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────────────┐    │    │
│  │  │ Document │─>│  Text    │─>│  FAISS   │─>│  Retrieve Top-5  │    │    │
│  │  │ Loaders  │  │  Split   │  │  Index   │  │  Relevant Chunks │    │    │
│  │  └──────────┘  └──────────┘  └──────────┘  └──────────────────┘    │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                      │                                       │
│                                      ▼                                       │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  LLM INFERENCE                                                      │    │
│  │  ┌─────────────────┐        ┌─────────────────┐                     │    │
│  │  │  Ollama Mode    │   OR   │  Direct GGUF    │                     │    │
│  │  │  (API server)   │        │  (llama-cpp-py) │                     │    │
│  │  └─────────────────┘        └─────────────────┘                     │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                      │                                       │
│                                      ▼                                       │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  OUTPUT: Valid JSON Config (Spark Job / SQL Pipeline)               │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Hardware Requirements

### Training (Your RTX 3050 System)
| Component | Minimum | Recommended |
|-----------|---------|-------------|
| GPU | NVIDIA RTX 3050 4GB | RTX 3060 12GB+ |
| VRAM | 4 GB | 8 GB+ |
| RAM | 16 GB | 32 GB |
| Disk | 20 GB free | 50 GB free |
| OS | WSL2 Ubuntu / Linux | Native Linux |

### Inference (Target CPU-Only System)
| Component | Minimum | Recommended |
|-----------|---------|-------------|
| CPU | Any x86_64 / ARM64 | 4+ cores |
| RAM | 4 GB | 8 GB+ |
| Disk | 2 GB free | 5 GB free |
| OS | Linux / Windows / macOS | Any |

---

## Model Selection Deep Dive

Based on the [XDA article](https://www.xda-developers.com/local-llms-used-prove-not-just-smaller-versions-cloud-models/) and 2026 benchmarks, here is the model comparison for **4GB VRAM**:

| Model | Params | VRAM (Q4) | JSON Quality | Code | Fine-tuneable | Recommendation |
|-------|--------|-----------|--------------|------|---------------|----------------|
| **Qwen2.5-Coder-3B** | 3B | ~2.1 GB | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ✅ Yes | **🏆 BEST CHOICE** |
| Qwen2.5-3B-Instruct | 3B | ~2.1 GB | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ✅ Yes | Excellent alternative |
| VibeThinker-3B | 3B | ~2.1 GB | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ✅ Yes | Best reasoning (article pick) |
| Llama-3.2-3B-Instruct | 3B | ~2.0 GB | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ✅ Yes | Good, needs HF auth |
| Phi-3-mini-3.8B | 3.8B | ~2.5 GB | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⚠️ Tight | May OOM during training |
| Gemma-2-2B | 2B | ~1.5 GB | ⭐⭐⭐ | ⭐⭐⭐ | ✅ Yes | Too small for complex configs |

### Why Qwen2.5-Coder-3B-Instruct?

1. **Purpose-built for code**: Trained on 5.5T tokens including code, SQL, and structured data
2. **Excellent JSON output**: Native support for structured generation
3. **Proven QLoRA compatibility**: Well-tested with PEFT/bitsandbytes
4. **Fits 4GB VRAM comfortably**: ~3.2GB peak during QLoRA training
5. **Apache 2.0 license**: Free for commercial use
6. **Article endorsement**: Qwen 3.6 family praised for Gated DeltaNet efficiency

---

## Step-by-Step Execution Guide

### Phase 0: Pre-Downloads (One-time, needs Internet)

Before going offline, download these on your RTX 3050 system:

```bash
# 1. Clone this repository
cd ~/local_llm_rag_pipeline

# 2. Install dependencies (needs internet)
bash scripts/01_setup_env.sh

# 3. Pre-download base model (for offline training)
python -c "from transformers import AutoModelForCausalLM; AutoModelForCausalLM.from_pretrained('Qwen/Qwen2.5-Coder-3B-Instruct')"
python -c "from transformers import AutoTokenizer; AutoTokenizer.from_pretrained('Qwen/Qwen2.5-Coder-3B-Instruct')"

# 4. Pre-download embedding model (for RAG)
python -c "from sentence_transformers import SentenceTransformer; SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')"

# 5. Cache locations (copy these for offline use):
#    ~/.cache/huggingface/hub/          (models)
#    ~/.cache/torch/                    (PyTorch)
```

### Phase 1: Data Preparation (Offline capable)

```bash
conda activate local_llm_rag

# Place your files in ./data/:
#   - source_events.json
#   - mapping_docs.xlsx
#   - schema_info.csv
#   - prompt_template.md

# Generate training dataset
python src/02_prepare_data.py
# Output: data/training_dataset.jsonl
```

### Phase 2: QLoRA Fine-Tuning (RTX 3050, ~2-4 hours)

```bash
# This runs ENTIRELY OFFLINE if model is cached
python src/03_finetune_qlora.py

# Expected VRAM usage: ~3.2-3.8 GB
# Expected output: models/qwen2.5-coder-3b-qlora/final_adapter/
```

**Training monitoring:**
```bash
# Watch GPU usage in another terminal
watch -n 1 nvidia-smi

# Expected: GPU utilization 80-100%, VRAM ~3.5GB
```

### Phase 3: Export to Portable GGUF (Offline capable)

```bash
# Merge adapters + convert to GGUF + create Ollama model
python src/04_merge_export_gguf.py

# Outputs:
#   - models/gguf/model-q4_k_m.gguf    (~1.8 GB, SINGLE FILE)
#   - models/gguf/Modelfile
```

### Phase 4: Test RAG Pipeline (Offline)

```bash
# Start Ollama server (in background)
ollama serve &

# Run RAG pipeline
python src/05_rag_pipeline.py
```

### Phase 5: Spark UDF Integration (Offline)

```bash
# Mode 1: Via Ollama API
python src/06_spark_udf.py --mode ollama

# Mode 2: Direct GGUF (no Ollama needed)
python src/06_spark_udf.py --mode gguf
```

### Phase 6: Deploy to CPU-Only System (Portable)

```bash
# On target CPU system:
# 1. Copy ONLY these files:
#    - models/gguf/model-q4_k_m.gguf
#    - src/07_test_offline_cpu.py

# 2. Install minimal dependency:
pip install llama-cpp-python --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cpu

# 3. Run inference:
python src/07_test_offline_cpu.py --model ./models/gguf/model-q4_k_m.gguf

# 4. Interactive mode:
python src/07_test_offline_cpu.py --interactive --model ./models/gguf/model-q4_k_m.gguf
```

---

## File Structure

```
local_llm_rag_pipeline/
├── README.md                          # This file
├── requirements.txt                   # Python dependencies
├── .gitignore
├── data/
│   ├── source_events.json            # Your source event definitions
│   ├── mapping_docs.xlsx             # Column mapping documents
│   ├── schema_info.csv               # Table schema information
│   ├── prompt_template.md            # Prompt instructions
│   └── training_dataset.jsonl        # Generated training data
├── models/
│   ├── qwen2.5-coder-3b-qlora/      # Training checkpoints
│   │   └── final_adapter/           # LoRA adapter (~50MB)
│   ├── merged/                       # Merged HF model (temp)
│   ├── gguf/
│   │   ├── model-q4_k_m.gguf        # ⭐ PORTABLE MODEL FILE (~1.8GB)
│   │   └── Modelfile                # Ollama recipe
│   └── vectorstore/                  # FAISS index (local vector DB)
├── src/
│   ├── 02_prepare_data.py           # Dataset preparation
│   ├── 03_finetune_qlora.py         # QLoRA training (GPU)
│   ├── 04_merge_export_gguf.py      # Export to GGUF
│   ├── 05_rag_pipeline.py           # RAG + inference
│   ├── 06_spark_udf.py              # Spark integration
│   └── 07_test_offline_cpu.py       # CPU-only test
└── scripts/
    └── 01_setup_env.sh              # Environment setup
```

---

## Online vs Offline Segments

| Phase | Needs Internet | Can Run Offline | Duration | Hardware |
|-------|---------------|-----------------|----------|----------|
| **Environment Setup** | ✅ Yes | ❌ No | 15 min | Any |
| **Model Download** | ✅ Yes | ❌ No | 10 min | Any |
| **Data Preparation** | ❌ No* | ✅ Yes | 5 min | Any |
| **QLoRA Training** | ❌ No | ✅ Yes | 2-4 hrs | RTX 3050 |
| **GGUF Export** | ⚠️ Partial** | ✅ Yes | 20 min | Any |
| **RAG Inference** | ❌ No | ✅ Yes | Real-time | Any |
| **Spark UDF** | ❌ No | ✅ Yes | Batch | Cluster |
| **CPU Deployment** | ❌ No | ✅ Yes | Real-time | CPU-only |

*Assuming files are local  
**Needs llama.cpp clone (one-time)

### Can the WHOLE pipeline be offline?

**YES**, with one caveat: You must pre-download the base model and install dependencies while online. After that:
- Training: Fully offline
- Export: Fully offline (llama.cpp can be cloned ahead of time)
- Inference: Fully offline
- RAG: Fully offline (FAISS is file-based)
- Spark: Fully offline

---

## CPU Portability Guide

### The "Single File" Myth vs Reality

You asked about serializing as a `.pth`/`.pt` file and using it without installing packages. **Here is the honest truth:**

| Format | Size (3B model) | Needs Runtime | Portable? | Recommendation |
|--------|----------------|---------------|-----------|----------------|
| **PyTorch .pth** | ~6 GB (FP16) | PyTorch + transformers + bitsandbytes | ❌ No | Not suitable |
| **HuggingFace SafeTensors** | ~6 GB | transformers + torch | ❌ No | Not suitable |
| **GGUF (Q4_K_M)** | ~1.8 GB | llama.cpp or Ollama | ✅ Yes | **🏆 BEST** |
| **ONNX** | ~3 GB | onnxruntime | ⚠️ Partial | Complex export |

**Why GGUF is the answer:**
- Single binary file (~1.8GB for 3B Q4)
- Runs on CPU, GPU, ARM, x86_64
- No Python dependencies needed (C++ runtime)
- Ollama provides zero-config serving
- llama-cpp-python provides Python bindings

### Porting to CPU-Only System

```bash
# On RTX 3050 system (after training):
# Copy these to a USB drive / network share:
#   models/gguf/model-q4_k_m.gguf   (1.8 GB)

# On target CPU system:
# Option A: Using Ollama (easiest)
curl -fsSL https://ollama.com/install.sh | sh
ollama create pipeline-config-generator -f Modelfile
ollama run pipeline-config-generator

# Option B: Using llama-cpp-python (Python integration)
pip install llama-cpp-python --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cpu
python src/07_test_offline_cpu.py

# Option C: Using llamafile (single executable, no install!)
# Download llamafile from Mozilla, rename to .exe, run directly
# See: https://github.com/Mozilla-Ocho/llamafile
```

---

## Spark UDF Integration

### Architecture

```
Spark Driver                          Spark Executors
┌─────────────┐                      ┌─────────────────────┐
│ DataFrame   │────> Broadcast ────>│ GGUF Model loaded   │
│ (requirements│      GGUF path     │ per executor        │
│  per row)   │                      │                     │
└─────────────┘                      │ ┌─────────────────┐ │
                                     │ │ llama_cpp.Llama │ │
                                     │ │ (CPU inference) │ │
                                     │ └─────────────────┘ │
                                     │          │          │
                                     │          ▼          │
                                     │ ┌─────────────────┐ │
                                     │ │ JSON Config     │ │
                                     │ │ (per row)       │ │
                                     │ └─────────────────┘ │
                                     └─────────────────────┘
```

### Performance Considerations

| Factor | Impact | Recommendation |
|--------|--------|----------------|
| Model loading per executor | 10-30s cold start | Use singleton pattern |
| CPU inference speed | ~5-15 tokens/sec | Batch small requirements |
| Memory per executor | ~2-3 GB | Allocate 4GB per executor |
| Parallelism | Limited by CPU cores | Start with 2-4 executors |

### Optimization Tips

1. **Pre-load model**: Use `@udf` with singleton to avoid reloading
2. **Batch inputs**: Process multiple rows per inference call
3. **Filter early**: Only call LLM for complex mappings
4. **Cache results**: Cache generated configs for identical inputs

---

## Troubleshooting

### Out of Memory During Training

```python
# In 03_finetune_qlora.py, reduce:
MAX_SEQ_LENGTH = 256        # Instead of 512
BATCH_SIZE = 1              # Keep at 1
GRAD_ACCUMULATION = 16      # Increase to compensate
LORA_R = 8                  # Reduce from 16
```

### NaN Loss During Training

```python
# Solutions:
# 1. Lower learning rate
LEARNING_RATE = 1e-4        # Instead of 2e-4

# 2. Disable fp16 if unsupported
fp16=False, bf16=False      # Use full float32 (slower but stable)

# 3. Add gradient clipping
max_grad_norm=0.3
```

### Ollama Model Not Found

```bash
# Verify model is registered
ollama list

# If missing, re-create:
ollama create pipeline-config-generator -f models/gguf/Modelfile

# Test directly:
ollama run pipeline-config-generator "Generate a Spark job config for Kafka to JDBC"
```

### Slow CPU Inference

```bash
# Increase threads (match CPU cores)
# In 07_test_offline_cpu.py:
N_THREADS = 8  # Or os.cpu_count()

# Use smaller context if possible
N_CTX = 2048   # Instead of 4096

# Consider Q4_0 quantization (faster, slightly lower quality)
```

---

## License

This pipeline code is provided as-is. The base model (Qwen2.5-Coder-3B-Instruct) is licensed under Apache 2.0.

---

## References

- [XDA: Local LLMs That Prove They're Not Just Smaller Versions](https://www.xda-developers.com/local-llms-used-prove-not-just-smaller-versions-cloud-models/)
- [QLoRA Paper](https://arxiv.org/abs/2305.14314)
- [Ollama Documentation](https://docs.ollama.com/)
- [llama.cpp](https://github.com/ggerganov/llama.cpp)
