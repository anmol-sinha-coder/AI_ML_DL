"""Light QLoRA fine-tuning for format adaptation.

This is **optional**. The base `qwen2.5-coder:3b` already produces valid JSON
most of the time. A small QLoRA run (50–500 examples of "mapping-doc + event
→ gold JobConfig") pushes it to near-100% schema adherence and adapts the
model's voice to your specific column-naming conventions.

Why QLoRA on a 4 GB GPU?

    * 4-bit quantised base (via bitsandbytes) → ~1 GB resident.
    * LoRA adapters are tiny (~50 MB) and train in a few GB of VRAM.
    * After training: merge into base, export to GGUF, re-bundle.

The script writes a `lora_adapter/` directory and a `merged_gguf/` file. Run:

    python -m rag_flow_offline_llm.train_lora --train-jsonl data/train.jsonl \
                                     --base qwen2.5-coder:3b \
                                     --output-dir artifacts/lora

Then in `main.py`:

    python main.py merge-lora --adapter artifacts/lora --base artifacts/gguf_base \
                              --out artifacts/model-merged.gguf
    python main.py bundle    --gguf artifacts/model-merged.gguf
"""

from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def train(
    train_jsonl: Path,
    *,
    base_model: str = "qwen2.5-coder:3b",
    output_dir: Path,
    epochs: int = 3,
    lr: float = 2e-4,
    batch_size: int = 1,
    grad_accum: int = 8,
    max_seq_len: int = 2048,
) -> Path:
    """Run QLoRA training. Returns the adapter directory."""

    output_dir = Path(output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    # Lazy imports — keep install footprint small when not training.
    import torch
    from datasets import load_dataset
    from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
    from transformers import (
        AutoModelForCausalLM,
        AutoTokenizer,
        BitsAndBytesConfig,
        Trainer,
        TrainingArguments,
    )

    logger.info("Loading base model %s in 4-bit …", base_model)
    bnb = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.float16,
        bnb_4bit_use_double_quant=True,
    )
    tok = AutoTokenizer.from_pretrained(base_model, trust_remote_code=True)
    if tok.pad_token is None:
        tok.pad_token = tok.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        base_model,
        quantization_config=bnb,
        device_map="auto",
        trust_remote_code=True,
    )
    model = prepare_model_for_kbit_training(model)

    lora = LoraConfig(
        r=16,
        lora_alpha=32,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj"],
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM",
    )
    model = get_peft_model(model, lora)
    model.print_trainable_parameters()

    logger.info("Loading dataset %s", train_jsonl)
    ds = load_dataset("json", data_files=str(train_jsonl), split="train")

    def _format(ex):
        # Expect rows of {"prompt": ..., "completion": ...}
        prompt = ex["prompt"]
        completion = ex["completion"]
        text = (
            f"<|im_start|>system\nYou are a data-engineering assistant.<|im_end|>\n"
            f"<|im_start|>user\n{prompt}<|im_end|>\n"
            f"<|im_start|>assistant\n{completion}<|im_end|>"
        )
        return tok(text, truncation=True, max_length=max_seq_len, padding="max_length")

    ds = ds.map(_format, remove_columns=ds.column_names)

    args = TrainingArguments(
        output_dir=str(output_dir),
        num_train_epochs=epochs,
        per_device_train_batch_size=batch_size,
        gradient_accumulation_steps=grad_accum,
        learning_rate=lr,
        fp16=True,
        logging_steps=10,
        save_strategy="epoch",
        report_to=[],
        gradient_checkpointing=True,
    )
    trainer = Trainer(model=model, args=args, train_dataset=ds, tokenizer=tok)
    trainer.train()
    trainer.save_model(str(output_dir))
    tok.save_pretrained(str(output_dir))
    logger.info("Saved LoRA adapter to %s", output_dir)
    return output_dir


def merge_to_gguf(
    adapter_dir: Path,
    base_model_path: Path,
    *,
    out_gguf: Path,
    quantization: str = "Q4_K_M",
) -> Path:
    """Merge LoRA into base, export to GGUF (so it can go straight into the bundle).

    We do this in two steps:
      1. Merge LoRA into base (HF format) using PEFT.
      2. Convert to GGUF + quantize using llama.cpp's convert_hf_to_gguf.py + llama-quantize.
    """

    out_gguf = Path(out_gguf).resolve()
    out_gguf.parent.mkdir(parents=True, exist_ok=True)

    import torch
    from peft import PeftModel
    from transformers import AutoModelForCausalLM, AutoTokenizer

    logger.info("Merging adapter %s into base %s", adapter_dir, base_model_path)
    base = AutoModelForCausalLM.from_pretrained(
        str(base_model_path), torch_dtype=torch.float16, device_map="cpu"
    )
    merged = PeftModel.from_pretrained(base, str(adapter_dir)).merge_and_unload()

    merged_dir = out_gguf.with_suffix(".merged")
    merged_dir.mkdir(parents=True, exist_ok=True)
    merged.save_pretrained(str(merged_dir), safe_serialization=True)
    AutoTokenizer.from_pretrained(str(base_model_path)).save_pretrained(str(merged_dir))

    # Convert HF → GGUF via llama.cpp's convert_hf_to_gguf.py.
    import subprocess

    fp16_gguf = out_gguf.with_name(out_gguf.stem + ".fp16.gguf")
    logger.info("Converting to GGUF (FP16) …")
    subprocess.check_call(
        ["python", "llama.cpp/convert_hf_to_gguf.py", str(merged_dir),
         "--outfile", str(fp16_gguf), "--outtype", "f16"]
    )

    logger.info("Quantising to %s …", quantization)
    subprocess.check_call(
        ["./llama.cpp/build/bin/llama-quantize", str(fp16_gguf), str(out_gguf), quantization]
    )
    fp16_gguf.unlink()
    shutil_rmtree(merged_dir)
    logger.info("Wrote merged+quantised GGUF to %s", out_gguf)
    return out_gguf


def shutil_rmtree(p: Path) -> None:
    import shutil
    shutil.rmtree(p, ignore_errors=True)


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def _main() -> None:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    t = sub.add_parser("train", help="Train a QLoRA adapter")
    t.add_argument("--train-jsonl", required=True, type=Path)
    t.add_argument("--base", default="qwen2.5-coder:3b")
    t.add_argument("--output-dir", required=True, type=Path)
    t.add_argument("--epochs", type=int, default=3)
    t.add_argument("--lr", type=float, default=2e-4)

    m = sub.add_parser("merge", help="Merge LoRA + export to GGUF")
    m.add_argument("--adapter", required=True, type=Path)
    m.add_argument("--base-path", required=True, type=Path)
    m.add_argument("--out", required=True, type=Path)
    m.add_argument("--quantization", default="Q4_K_M")

    args = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    if args.cmd == "train":
        train(args.train_jsonl, base_model=args.base, output_dir=args.output_dir,
              epochs=args.epochs, lr=args.lr)
    elif args.cmd == "merge":
        merge_to_gguf(args.adapter, args.base_path, out_gguf=args.out,
                      quantization=args.quantization)


if __name__ == "__main__":
    _main()