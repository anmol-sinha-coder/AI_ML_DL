"""Pydantic models = the JSON config contract.

Every output of the pipeline must validate against `JobConfig`. This file is the
single source of truth for what a "JSON config" looks like; downstream code
(Spark columns, validation tools, etc.) imports these models.

Why Pydantic + Ollama grammar-mode = bulletproof JSON:

  1. We pass `JobConfig.model_json_schema()` to Ollama via `format=<schema>`.
  2. Ollama constrains decoding token-by-token so the raw output is always
     valid JSON conforming to that schema (enforced at the tokenizer level).
  3. We then call `JobConfig.model_validate_json(...)` for final semantic
     validation (range checks, regex on identifiers, etc.).

The result: a typed Python object, never a string to re-parse by hand.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, field_validator


# --------------------------------------------------------------------------- #
# Sub-records
# --------------------------------------------------------------------------- #
class SourceEvent(BaseModel):
    """One row of a source-events input file (`.json`)."""

    event_id: str = Field(..., description="Stable event identifier")
    event_type: str = Field(..., description="Type of source event, e.g. 'kafka_message'")
    source_system: str = Field(..., description="Originating system, e.g. 'orders_db'")
    payload_schema: str = Field(
        ..., description="Name of the schema this event's payload conforms to"
    )
    sample: dict | None = Field(
        default=None,
        description="Optional sample payload, used to infer column types",
    )


class SparkClusterConfig(BaseModel):
    """Spark execution cluster block (may be `None` for local mode)."""

    master: str = Field(
        default="local[*]",
        description="Spark master URL. 'local[*]' for local, 'yarn' for cluster.",
    )
    executor_instances: int = Field(default=2, ge=1, le=1000)
    executor_cores: int = Field(default=2, ge=1, le=32)
    executor_memory: str = Field(default="2g", pattern=r"^\d+[gGmM]$")
    driver_memory: str = Field(default="1g", pattern=r"^\d+[gGmM]$")
    conf: dict[str, str] = Field(
        default_factory=dict,
        description="Arbitrary Spark conf, e.g. {'spark.sql.shuffle.partitions': '200'}",
    )


class ColumnMapping(BaseModel):
    """One column mapping rule produced by the pipeline."""

    target_table: str = Field(..., description="Destination table name")
    target_column: str = Field(..., description="Destination column name")
    source_expression: str = Field(
        ..., description="SQL expression that produces this column"
    )
    data_type: str = Field(
        ..., description="Spark/SQL data type, e.g. 'STRING', 'BIGINT', 'DECIMAL(18,4)'"
    )
    nullable: bool = Field(default=True)
    description: str | None = Field(
        default=None, description="Human-readable description, optional"
    )

    @field_validator("target_table", "target_column")
    @classmethod
    def _no_special_chars(cls, v: str) -> str:
        if not v.replace("_", "").isalnum():
            raise ValueError(
                f"Identifier {v!r} contains illegal characters; use letters, digits, underscores."
            )
        return v


# --------------------------------------------------------------------------- #
# Top-level output
# --------------------------------------------------------------------------- #
class JobConfig(BaseModel):
    """The full JSON config file the pipeline emits.

    Stored in a Spark DataFrame as a single `struct` column of `to_json` shape:

        df.withColumn(
            "config",
            F.to_json(F.struct(*[F.lit(None).alias("job_name"), ...]))
        )
    """

    schema_version: Literal["1.0"] = "1.0"
    job_name: str = Field(..., description="Short identifier, used as filename")
    description: str = Field(..., description="One-line human description")
    source_event: SourceEvent = Field(
        ..., description="The source event that triggered this job"
    )
    target: ColumnMapping = Field(
        ..., description="The single mapping the job materialises"
    )
    spark: SparkClusterConfig | None = Field(
        default=None,
        description="Spark cluster block. None ⇒ run with default SparkSession.",
    )
    sql: str = Field(
        ...,
        description="Full Spark SQL the job should execute. Must reference target_table.",
    )
    schedule: str | None = Field(
        default=None,
        description="Optional cron expression for scheduling, e.g. '0 2 * * *'",
    )
    tags: list[str] = Field(
        default_factory=list,
        description="Free-form labels for grouping/categorising jobs",
    )

    def to_json_config(self) -> str:
        """Convenience: serialize to compact JSON string for Spark to_json()."""
        return self.model_dump_json()