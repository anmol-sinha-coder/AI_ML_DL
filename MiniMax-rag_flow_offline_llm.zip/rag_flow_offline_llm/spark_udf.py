"""Spark UDF wrapper.

Exposes `make_generate_udf(pipeline)` returning a `pandas_udf` so the whole
offline RAG pipeline can be invoked from PySpark like a column function:

    df = df.withColumn(
        "job_config",
        make_generate_udf(pipeline, batch_size=4)(
            F.col("mapping_json"),     # mapping row, json string
            F.col("event_json"),       # source event, json string
            F.col("target_schema_json"),  # optional
        )
    )

The output is a JSON-encoded string ready for `F.from_json(...)` into a
matching Spark `StructType` (or simply stored as `STRING`).

Why a pandas_udf (not a plain UDF)?

    * Vectorised batch dispatch — we send N rows through the LLM at once
      where possible (configurable batch_size).
    * Per-row state is isolated; failures in one row don't poison the batch.
    * Plays nicely with Arrow, so the JSON parsing is essentially free.

The pipeline is loaded ONCE per JVM (Python worker), not per row.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from .pipeline import Pipeline

logger = logging.getLogger(__name__)


def make_generate_udf(pipeline: Pipeline, *, batch_size: int = 4):
    """Return a `pandas_udf` (or plain UDF if pandas_udf isn't available).

    The function signature matches `(mapping_json, event_json[, target_schema_json]) -> json_str`.
    """

    try:
        from pyspark.sql.functions import pandas_udf, PandasUDFType
        from pyspark.sql.types import StringType
        import pandas as pd

        @pandas_udf(StringType(), functionType=PandasUDFType.SCALAR)
        def _generate_udf(
            mapping_json: pd.Series,
            event_json: pd.Series,
            target_schema_json: pd.Series | None = None,
        ) -> pd.Series:
            return _run_batch(
                pipeline,
                mapping_json=mapping_json,
                event_json=event_json,
                target_schema_json=target_schema_json,
                batch_size=batch_size,
            )

        # Make the wrapper ergonomic: caller can do `udf(mapping, event)` or
        # `udf(mapping, event, schema)`. Return a thin lambda.
        def _wrapper(*cols):
            if len(cols) == 2:
                return _generate_udf(cols[0], cols[1])
            if len(cols) == 3:
                return _generate_udf(cols[0], cols[1], cols[2])
            raise TypeError(f"generate_udf expects 2 or 3 columns, got {len(cols)}")

        _wrapper.__doc__ = (
            "Apply offline RAG pipeline to each row.\n\n"
            "Usage:\n"
            "  df.withColumn('cfg', generate_udf(F.col('mapping'), F.col('event')))"
        )
        return _wrapper

    except ImportError:
        # PySpark not installed — fall back to a plain Python callable.
        logger.warning(
            "PySpark not installed — returning a plain function. "
            "Install pyspark to use as a real Spark UDF."
        )

        def _plain(mapping_json: str, event_json: str, target_schema_json: str | None = None) -> str:
            res = pipeline.generate_config(
                event=json.loads(event_json),
                mapping_doc=json.loads(mapping_json),
                target_schema=json.loads(target_schema_json) if target_schema_json else None,
            )
            return res.to_json_config()

        return _plain


def _run_batch(pipeline, *, mapping_json, event_json, target_schema_json, batch_size):
    """Apply the pipeline row-wise, batched to control memory."""
    import pandas as pd

    results: list[str | None] = [None] * len(mapping_json)
    n = len(mapping_json)

    for start in range(0, n, batch_size):
        end = min(start + batch_size, n)
        for i in range(start, end):
            try:
                event = json.loads(event_json.iloc[i])
                mapping = json.loads(mapping_json.iloc[i])
                schema = (
                    json.loads(target_schema_json.iloc[i])
                    if target_schema_json is not None
                    and pd.notna(target_schema_json.iloc[i])
                    else None
                )
                cfg = pipeline.generate_config(
                    event=event, mapping_doc=mapping, target_schema=schema
                )
                results[i] = cfg.to_json_config()
            except Exception as e:  # noqa: BLE001
                logger.exception("Row %d failed: %s", i, e)
                results[i] = json.dumps({"error": str(e), "row": int(i)})
    return pd.Series(results, index=mapping_json.index)