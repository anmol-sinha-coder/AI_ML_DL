# Job-Config Output Format

The pipeline must emit a `JobConfig` JSON object with:

- `job_name`: short identifier used as the filename.
- `source_event`: the source-event row this job is for.
- `target`: a single `ColumnMapping` row.
- `spark`: optional `SparkClusterConfig` (omit to use defaults).
- `sql`: full Spark SQL the job executes; must reference `target_table`.

Use lowercase_snake_case for identifiers. Use BIGINT/STRING/DECIMAL/TIMESTAMP types.
