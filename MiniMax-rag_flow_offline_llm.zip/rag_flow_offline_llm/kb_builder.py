"""KB vector database builder.

Reads heterogeneous input files (JSON, XLSX, CSV, Parquet, Markdown) from
`data/` and writes a single Chroma vector store to `artifacts/chroma/`.

Why Chroma (and not FAISS)?

    * SQLite-backed, persistent on disk.
    * First-class LangChain integration.
    * Zero server process — required for "fully offline".
    * Supports metadata filtering, MMR, hybrid search.

For pgVector swap, replace `_build_chroma` with `PGVector.from_documents(...)`.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Iterable

from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma

logger = logging.getLogger(__name__)


# --------------------------------------------------------------------------- #
# Per-format loaders. Each yields `Document` with metadata so we can filter
# later (e.g. "only mappings files", "only schemas for table X").
# --------------------------------------------------------------------------- #
def _load_json(path: Path) -> Iterable[Document]:
    """Each JSON file is one Document. If it's a list, we wrap it."""

    raw = json.loads(path.read_text(encoding="utf-8"))

    if isinstance(raw, list):
        # list-of-events: yield one doc per element so each event is searchable
        for i, item in enumerate(raw):
            yield Document(
                page_content=json.dumps(item, indent=2, ensure_ascii=False),
                metadata={
                    "source_type": "json",
                    "file_name": path.name,
                    "doc_id": f"{path.stem}:{i}",
                    "row_index": i,
                },
            )
    else:
        yield Document(
            page_content=json.dumps(raw, indent=2, ensure_ascii=False),
            metadata={
                "source_type": "json",
                "file_name": path.name,
                "doc_id": path.stem,
                "row_index": 0,
            },
        )


def _load_xlsx(path: Path) -> Iterable[Document]:
    """Each row of the first sheet is one Document.

    Falls back gracefully if `openpyxl` is unavailable — we still surface a
    warning instead of crashing so the rest of the KB can still build.
    """

    try:
        from openpyxl import load_workbook  # type: ignore
    except ImportError:
        logger.warning("openpyxl not installed; skipping %s", path)
        return

    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb.active
    if ws is None:
        return

    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return

    header = [str(c).strip() if c is not None else f"col_{i}" for i, c in enumerate(rows[0])]
    for i, row in enumerate(rows[1:], start=1):
        cells = ["" if c is None else str(c) for c in row]
        record = dict(zip(header, cells))
        yield Document(
            page_content=json.dumps(record, ensure_ascii=False),
            metadata={
                "source_type": "xlsx",
                "file_name": path.name,
                "sheet": ws.title,
                "doc_id": f"{path.stem}:row{i}",
                "row_index": i,
            },
        )


def _load_csv_or_parquet(path: Path) -> Iterable[Document]:
    """CSV / Parquet → one Document per row."""

    if path.suffix.lower() == ".csv":
        try:
            import pandas as pd  # type: ignore
        except ImportError:
            logger.warning("pandas not installed; skipping %s", path)
            return
        df = pd.read_csv(path)
    else:  # parquet
        try:
            import pandas as pd  # type: ignore
        except ImportError:
            logger.warning("pandas not installed; skipping %s", path)
            return
        df = pd.read_parquet(path)

    src = "csv" if path.suffix.lower() == ".csv" else "parquet"
    for i, row in df.iterrows():
        # convert numpy types to plain python for JSON serialisation
        record = {k: (None if v is None else _to_python(v)) for k, v in row.items()}
        yield Document(
            page_content=json.dumps(record, ensure_ascii=False, default=str),
            metadata={
                "source_type": src,
                "file_name": path.name,
                "doc_id": f"{path.stem}:row{i}",
                "row_index": int(i),
            },
        )


def _to_python(v: Any) -> Any:
    """Convert numpy / pandas scalars to native python for json.dumps."""
    if hasattr(v, "item"):
        try:
            return v.item()
        except Exception:  # noqa: BLE001
            return str(v)
    return v


def _load_markdown(path: Path) -> Iterable[Document]:
    """Markdown is loaded whole. We chunk later via the splitter."""

    text = path.read_text(encoding="utf-8")
    yield Document(
        page_content=text,
        metadata={
            "source_type": "md",
            "file_name": path.name,
            "doc_id": path.stem,
        },
    )


# --------------------------------------------------------------------------- #
# Public API
# --------------------------------------------------------------------------- #
def load_kb_documents(
    data_dir: Path,
    *,
    include_globs: tuple[str, ...] = ("**/*",),
    exclude_globs: tuple[str, ...] = (".*", "*.lock"),
) -> list[Document]:
    """Walk `data_dir`, dispatch each file to the right loader.

    Returns a flat list of `Document` objects ready for splitting + embedding.
    """

    docs: list[Document] = []
    for path in sorted(data_dir.rglob("*")):
        if not path.is_file():
            continue
        if any(path.match(g) for g in exclude_globs):
            continue

        ext = path.suffix.lower()
        try:
            if ext == ".json":
                docs.extend(_load_json(path))
            elif ext in {".xlsx", ".xlsm"}:
                docs.extend(_load_xlsx(path))
            elif ext == ".csv":
                docs.extend(_load_csv_or_parquet(path))
            elif ext == ".parquet":
                docs.extend(_load_csv_or_parquet(path))
            elif ext in {".md", ".markdown", ".txt"}:
                docs.extend(_load_markdown(path))
            else:
                logger.debug("Skipping unsupported file: %s", path)
        except Exception as e:  # noqa: BLE001
            logger.error("Failed to load %s: %s", path, e)

    logger.info("Loaded %d documents from %s", len(docs), data_dir)
    return docs


def build_chroma_kb(
    documents: list[Document],
    *,
    persist_dir: Path,
    collection_name: str,
    embedding_model: str = "nomic-embed-text",
    backend: str = "ollama",
    chunk_size: int = 800,
    chunk_overlap: int = 120,
) -> "Chroma":
    """Split, embed, and persist. Returns the `Chroma` store."""


    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\n\n", "\n", " ", ""],
    )
    chunks = splitter.split_documents(documents)
    logger.info("Split into %d chunks", len(chunks))

    if backend == "ollama":
        from langchain_ollama import OllamaEmbeddings
        embeddings = OllamaEmbeddings(model=embedding_model)
    else:
        # HuggingFace fallback — works fully offline if model is cached
        from langchain_community.embeddings import HuggingFaceEmbeddings
        embeddings = HuggingFaceEmbeddings(
            model_name="sentence-transformers/all-MiniLM-L6-v2",
            cache_folder=str(persist_dir / "_hf_cache"),
        )

    store = Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        persist_directory=str(persist_dir),
        collection_name=collection_name,
    )
    store.persist()
    logger.info("Persisted Chroma store to %s", persist_dir)
    return store