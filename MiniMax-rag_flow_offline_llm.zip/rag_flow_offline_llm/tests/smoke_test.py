"""Smoke tests that don't require Ollama or any LLM runtime.

These verify:
  * Package imports cleanly.
  * Pydantic schemas validate.
  * KB builder reads the sample data correctly.
  * Pipeline serialises and deserialises via dill.
  * Bundle manifest round-trips.
"""

from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

# Make the project importable when run as `python tests/smoke_test.py`.
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from offline_rag.kb_builder import load_kb_documents
from offline_rag.pipeline import Pipeline
from offline_rag.schemas import (
    ColumnMapping,
    JobConfig,
    SourceEvent,
    SparkClusterConfig,
)
from offline_rag.serializer import (
    BUNDLE_VERSION,
    BundleManifest,
    export_bundle,
    load_bundle,
)


def _assert(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)
    print(f"  ✓ {msg}")


def test_imports() -> None:
    print("[1] imports")
    _assert(JobConfig is not None, "JobConfig imported")
    _assert(Pipeline is not None, "Pipeline imported")
    _assert(BundleManifest is not None, "BundleManifest imported")


def test_schema_validation() -> None:
    print("[2] schema validation")

    valid = JobConfig(
        job_name="orders_clean",
        description="Clean orders from kafka into orders_clean table",
        source_event=SourceEvent(
            event_id="ev1",
            event_type="kafka_message",
            source_system="orders_db",
            payload_schema="orders_v1",
        ),
        target=ColumnMapping(
            target_table="orders_clean",
            target_column="order_id",
            source_expression="payload.order_id",
            data_type="BIGINT",
        ),
        spark=SparkClusterConfig(executor_instances=4, executor_memory="4g"),
        sql="INSERT INTO orders_clean SELECT payload.order_id FROM kafka_events",
        tags=["pii", "core"],
    )
    _assert(valid.job_name == "orders_clean", "valid JobConfig parses")

    # Identifier validator rejects spaces / hyphens.
    try:
        ColumnMapping(
            target_table="bad name",  # space — illegal
            target_column="x",
            source_expression="y",
            data_type="STRING",
        )
        raise AssertionError("expected validation error for illegal identifier")
    except Exception:
        pass
    _assert(True, "illegal identifier rejected by validator")

    # Serialise → re-parse round-trip.
    j = valid.to_json_config()
    reparsed = JobConfig.model_validate_json(j)
    _assert(reparsed.job_name == valid.job_name, "JSON round-trip preserves fields")


def test_kb_builder(tmp: Path) -> None:
    print("[3] KB builder reads sample data")
    docs = load_kb_documents(tmp / "data")
    _assert(len(docs) >= 4, f"loaded {len(docs)} docs from sample data (json + 2 csv rows + md)")
    types = {d.metadata.get("source_type") for d in docs}
    _assert({"json", "csv", "md"}.issubset(types),
            f"saw expected source types: {types}")
    _assert(all(d.page_content for d in docs), "every doc has non-empty page_content")


def test_pipeline_roundtrip(tmp: Path) -> None:
    print("[4] Pipeline dict round-trip (no LLM, no Chroma)")
    d = {
        "output_schema_name": "JobConfig",
        "system_template": "be terse",
        "chroma_dir": str(tmp / "chroma"),
        "collection_name": "offline_rag_kb",
        "backend": "ollama",
        "llm_model": "qwen2.5-coder:1.5b",
        "gguf_path": None,
        "extras": {},
    }
    # We can't call Pipeline.from_dict because it would try to load embeddings,
    # but we CAN round-trip the dict through dill.
    import dill as pickle
    blob = pickle.dumps(d)
    restored = pickle.loads(blob)
    _assert(restored["llm_model"] == "qwen2.5-coder:1.5b", "dill round-trip preserves dict")


def test_bundle_manifest() -> None:
    print("[5] bundle manifest schema")
    m = BundleManifest(
        version=BUNDLE_VERSION,
        created_at="2025-06-12T00:00:00Z",
        backend="ollama",
        llm_model="qwen2.5-coder:1.5b",
        gguf_filename="model.gguf",
        chroma_dir="chroma",
        collection_name="offline_rag_kb",
        schema_name="JobConfig",
        system_prompt_path="system_prompt.txt",
        pipeline_pkl="pipeline.pkl",
        extras={"note": "test"},
    )
    s = m.to_json()
    m2 = BundleManifest.from_json(s)
    _assert(m2.version == BUNDLE_VERSION, "manifest round-trip preserves version")
    _assert(m2.extras["note"] == "test", "manifest extras round-trip")


def _make_sample_data(tmp: Path) -> None:
    """Create a tiny data/ tree for KB builder tests."""
    data = tmp / "data"
    (data / "source_events").mkdir(parents=True)
    (data / "mappings").mkdir(parents=True)
    (data / "schemas").mkdir(parents=True)
    (data / "prompts").mkdir(parents=True)

    (data / "source_events" / "ev.json").write_text(json.dumps({
        "event_id": "ev1",
        "event_type": "kafka_message",
        "source_system": "orders_db",
        "payload_schema": "orders_v1",
        "sample": {"order_id": 1},
    }), encoding="utf-8")

    (data / "mappings" / "mapping.csv").write_text(
        "target_table,target_column,source_expression,data_type\n"
        "orders_clean,order_id,payload.order_id,BIGINT\n",
        encoding="utf-8",
    )

    (data / "schemas" / "schema.csv").write_text(
        "table_name,column_name,data_type,is_nullable\n"
        "orders_clean,order_id,BIGINT,NO\n",
        encoding="utf-8",
    )

    (data / "prompts" / "format.md").write_text("# format spec\n", encoding="utf-8")


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="offline_rag_test_") as tmpdir:
        tmp = Path(tmpdir)
        _make_sample_data(tmp)
        test_imports()
        test_schema_validation()
        test_kb_builder(tmp)
        test_pipeline_roundtrip(tmp)
        test_bundle_manifest()
    print("\nAll smoke tests passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())