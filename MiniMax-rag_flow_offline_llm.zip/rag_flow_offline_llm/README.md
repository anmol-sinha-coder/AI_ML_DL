# Offline RAG Pipeline

A fully-offline, locally-runnable RAG pipeline that turns heterogeneous KB files
(JSON / XLSX / CSV / Parquet / Markdown) into schema-validated JSON config files,
backed by a small LLM that fits a 4 GB-VRAM RTX 3050.

The whole thing exports to a **single portable bundle** (the `.pt/.pth`
equivalent of this whole system) that runs anywhere with just four pip
packages: `dill`, `pydantic`, `chromadb`, `llama-cpp-python`.

> 👉 **For the complete directory map (every file explained by extension) plus
> the full NVIDIA RTX → CPU runbook, see [`WALKTHROUGH.md`](WALKTHROUGH.md).**
>
> 👉 For model-selection research and architecture decisions, see
> [`RESEARCH_AND_PLAN.md`](RESEARCH_AND_PLAN.md).

---

## Quick start (5 commands)

```bash
# 0. One-time online setup (internet OK here)
ollama pull qwen2.5-coder:3b     # 1 GB VRAM — best fit for RTX 3050 4 GB
ollama pull nomic-embed-text       # embedding model
pip install -r requirements.txt

# 1. Sample data + build KB
python data/_generate_samples.py
python main.py build

# 2. End-to-end smoke test
python main.py smoke

# 3. Generate one config from explicit input files
python main.py generate \
    --event   data/configs/orders_kafka.json \
    --mapping data/mappings/orders_mapping.xlsx \
    --schema  data/schemas/orders_clean_schema.csv \
    --out     artifacts/test_orders.json

# 4. Export the pipeline as a single portable bundle (the .pt equivalent)
python main.py bundle --gguf models/qwen2.5-coder-3b-q4_k_m.gguf --zip
# → bundles/pipeline.bundle.zip
```

**On any CPU-only machine** (4 pip packages, then offline forever):

```bash
pip install dill pydantic chromadb llama-cpp-python
python scripts/verify_bundle.py bundles/pipeline.bundle.zip
```

---

## Directory map (high-level)

```
rag_flow_offline_llm/
├── README.md                  ← you are here
├── WALKTHROUGH.md             ← complete directory + extension map + GPU→CPU runbook
├── RESEARCH_AND_PLAN.md        ← model selection rationale
│
├── *.py                       ← pipeline source (kb_builder, retriever, generator,
│                                  pipeline, serializer, spark_udf, train_lora, main)
├── requirements.txt           ← dev deps
│
├── data/                      ← KB inputs (5 formats × 19 files)
│   ├── configs/*.json
│   ├── mappings/*.xlsx, *.csv
│   ├── schemas/*.csv, *.parquet
│   └── prompts/*.md
│
├── artifacts/                 ← generated outputs
│   ├── chroma/                ← vector DB
│   └── gold_outputs/          ← reference JobConfig (acceptance criteria)
│
├── bundles/                   ← exported .bundle (the .pt equivalent)
│   └── pipeline.bundle.zip
│
├── models/                    ← GGUF model files
├── scripts/                   ← automation
│   ├── runbook_gpu_to_cpu.sh  ← end-to-end GPU→CPU automation
│   └── verify_bundle.py       ← CPU-side bundle validator
│
└── tests/
    └── smoke_test.py          ← 5 sanity assertions (no LLM needed)
```

> **Every file is explained in detail, by extension type, in `WALKTHROUGH.md`.**

---

## What runs where

| Stage | Where | Backend | Notes |
|---|---|---|---|
| **Build KB** (`main.py build`) | RTX 3050 | `OllamaEmbeddings` | One-time, needs Ollama running |
| **Generate configs** (`main.py generate`) | RTX 3050 | `ChatOllama` | Iterative dev |
| **Export bundle** (`main.py bundle`) | RTX 3050 | – | Copies GGUF + Chroma + schema |
| **Run bundle** (`verify_bundle.py` / `load_bundle`) | **ANY machine** | `llama-cpp-python` | No Ollama, no internet |

After the bundle is exported, a fresh machine with **only**:

```bash
pip install dill pydantic chromadb llama-cpp-python
```

can do:

```python
from rag_flow_offline_llm import load_bundle
pipeline = load_bundle("bundles/pipeline.bundle/")
cfg = pipeline.generate_config(event={...}, mapping_doc={...})
print(cfg.to_json_config())
```

---

## Architecture

```
data/{json,xlsx,csv,parquet,md}  →  kb_builder.py  →  Chroma (SQLite)
                                                          ↓
main.py generate  →  pipeline.py  →  retriever (MMR) → generator (Pydantic+grammar)
                                            ↓
                              validated JobConfig (Python object or JSON string)
                                            ↓
                              spark_udf.py  →  DataFrame with struct/to_json column
                                            ↓
                              serializer.py →  bundles/pipeline.bundle.zip  ← THE .pt equivalent
```

---

## Spark usage

```python
from pyspark.sql import SparkSession
import pyspark.sql.functions as F

from rag_flow_offline_llm import Pipeline
from rag_flow_offline_llm.spark_udf import make_generate_udf

spark = SparkSession.builder.getOrCreate()
pipeline = Pipeline.load_bundle("bundles/pipeline.bundle")
gen = make_generate_udf(pipeline, batch_size=4)

df = spark.read.json("s3://my-bucket/events/*")
df = df.withColumn("event_json", F.to_json("payload"))
df = df.withColumn("job_config", gen(F.col("mapping_json"), F.col("event_json")))
```

> Make sure the bundle is reachable from every Spark worker (mounted volume, S3
> download at start, etc.).

---

## Why these specific choices?

| Decision | Rationale |
|---|---|
| `qwen2.5-coder:3b` | Best small code-specialised model; produces reliable JSON; 1 GB VRAM. |
| Ollama `format=<pydantic_schema>` | Grammar-constrained decoding → output is *always* valid JSON. |
| ChromaDB (not pgVector by default) | Zero-server, SQLite-backed, fully offline. pgVector works as drop-in if you already have Postgres. |
| `dill` for the bundle's pipeline pickle | Handles lambdas/local classes better than stock `pickle`. |
| GGUF as the "single model file" | Self-contained (weights + tokenizer + metadata), runs on CPU or GPU, single wheel to install (`llama-cpp-python`). |
| Optional QLoRA | Pushes small models from "okay" to "reliable" on a domain-specific format. |

---

## The full GPU → CPU runbook (one-pager)

```bash
# === NVIDIA RTX 3050 (your dev box, internet OK) ===
ollama pull qwen2.5-coder:3b && ollama pull nomic-embed-text
pip install -r requirements.txt
python data/_generate_samples.py
python main.py build && python main.py smoke
python main.py bundle --gguf ~/.ollama/models/blobs/sha256-<biggest> --zip
scp bundles/pipeline.bundle.zip user@cpu-box:/opt/pipeline/

# === CPU-only target (no internet needed after pip) ===
pip install dill pydantic chromadb llama-cpp-python
python scripts/verify_bundle.py /opt/pipeline/pipeline.bundle.zip
```

For the full 7-phase runbook with explanations, troubleshooting, and the
fine-tune path, see **`WALKTHROUGH.md`**.

---

## Troubleshooting

**Ollama is not running.** Start it with `ollama serve` (or the systemd unit).

**Chroma DB has no documents.** Run `python data/_generate_samples.py` then `python main.py build`.

**Llama-cpp can't find CUDA.** Install the CUDA build: `pip install llama-cpp-python --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cu121`. CPU build also works, just slower.

**Bundle import errors on a fresh machine.** Bundle ships a `pipeline.pkl` written by `dill`. If you upgraded `rag_flow_offline_llm` past a breaking change, regenerate the bundle.

---

## License

The pipeline code in this repo is MIT-licensed. The models (`qwen2.5-coder`,
`nomic-embed-text`) carry their own licences — please check the upstream
HuggingFace / Ollama model cards before redistribution.