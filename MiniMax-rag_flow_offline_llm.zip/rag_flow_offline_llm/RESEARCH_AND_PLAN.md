# Offline RAG Pipeline — Research & Architecture Plan

> Target hardware: NVIDIA RTX 3050 (4 GB VRAM, compute capability 8.6), WSL on Windows.
> Goal: fully offline LLM + RAG pipeline that ingests heterogeneous KB inputs and emits
> schema-validated JSON config files, exportable as a single portable artifact.

---

## 1. Model Selection (RTX 3050 4 GB VRAM — verified May 2026)

| Model (Ollama tag) | Params | Q4_K_M disk | Min VRAM | Tool/JSON | Pick? |
|---|---|---|---|---|---|
| `qwen2.5-coder:3b` | 1.5 B | ~1.0 GB | ~2 GB | yes (format=json) | **★ Primary** |
| `qwen2.5-coder:3b`   | 3.1 B | ~1.9 GB | ~3 GB | yes (format=json) | High-quality alt |
| `qwen2.5:3b`         | 3.1 B | ~1.9 GB | ~3 GB | yes | General-purpose alt |
| `phi4-mini`          | 3.8 B | ~2.5 GB | ~3.5 GB | weak | Reasoning-heavy |
| `llama3.2:3b`        | 3.2 B | ~2.0 GB | ~3 GB | yes | Fallback |
| `qwen2.5:7b`         | 7.6 B | ~4.4 GB | **>4 GB** | yes | Will spill to RAM |
| `qwen3:8b`           | 8.2 B | ~5.0 GB | **>4 GB** | yes | Will spill to RAM |

**Decision: `qwen2.5-coder:3b` as default, `qwen2.5-coder:3b` as quality upgrade.**

Reasoning:
1. Coder models produce more reliable structured JSON than general chat models of the same size.
2. 1.5 B leaves ~3 GB free on the 3050 → generous context window for RAG (4–8 K tokens).
3. Supports Ollama's `format=json` and `format=<schema>` grammar-constrained decoding.
4. Apache-2.0 license, no gating, GGUF pre-quantized.

Embedding model: `nomic-embed-text` (137 M params, 768-dim, ~50 ms/chunk on RTX 3050).
Pure-CPU fallback: `all-MiniLM-L6-v2` via `sentence-transformers` (~46 MB).

---

## 2. The "Single Serialized File" Mapping

The user wants a `.pth/.pt`-equivalent for this entire pipeline. There is no single PyTorch
file that holds *an LLM + a RAG pipeline + a vector DB*, so we define an explicit artifact:

```
pipeline.bundle/                      ← a self-contained directory (zipped for portability)
├── manifest.json                     ← versioned schema, lists every component
├── model.gguf                        ← THE single model file (≈ PyTorch .pth equivalent)
├── chroma/                           ← persisted vector DB (SQLite + Parquet)
├── pipeline.pkl                      ← serialized Python pipeline (dill)
├── schema.json                       ← Pydantic output schema (the "JSON config format")
├── tokenizer.json                    ← snapshot of embedding tokenizer config
└── README.md                         ← how to load + run, no extra installs needed
```

The **GGUF** is the single model file — it bundles weights + tokenizer + metadata so it can be
loaded on any machine with `llama-cpp-python` (a single C-extension wheel). The bundle as a
whole is the "PyTorch equivalent" of the entire system: copy it, run a tiny loader, done.

`src/serializer.py` exposes `export_bundle()` (writes the directory) and `load_bundle()`
(reads it back anywhere, no Ollama needed — uses `llama-cpp-python` directly).

---

## 3. Architecture

```
┌──────────────────────────────────────────────────────────────────────────┐
│  KB Source Files                                                          │
│  ─ .json   (source events + process execution)                            │
│  ─ .xlsx   (project / column mapping docs)                               │
│  ─ .csv/.parquet (table schema / information_schema dumps)                │
│  ─ .md     (prompt-format documentation)                                 │
└──────────────────────────────────────────────────────────────────────────┘
                          │  (one-time, offline)
                          ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  KB Builder (src/kb_builder.py)                                          │
│  ─ loaders per file type (json, xlsx, csv, parquet, md)                   │
│  ─ chunking: RecursiveTextSplitter, semantic-aware for tables            │
│  ─ embeddings: OllamaEmbeddings(nomic-embed-text) or HF fallback         │
│  ─ store: ChromaDB (SQLite-backed, persisted)                            │
└──────────────────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  Pipeline (src/pipeline.py)                                              │
│  ─ retriever: top-k similarity + metadata filter                         │
│  ─ prompt: ChatPromptTemplate with Pydantic schema injection             │
│  ─ llm: ChatOllama(model=..., format=schema)  ← during dev               │
│       OR LlamaCpp(gguf_path)             ← when loading .bundle          │
│  ─ parser: PydanticOutputParser → strict JSON validation                 │
└──────────────────────────────────────────────────────────────────────────┘
                          │
                          ▼
                Spark JSON Config (validated)
                OR Spark pandas_udf for row-wise generation
```

---

## 4. File Layout

```
rag_flow_offline_llm/
├── RESEARCH_AND_PLAN.md            ← this file
├── README.md
├── requirements.txt
├── main.py                          ← orchestrator
├── Modelfile.qwen-coder             ← custom Ollama Modelfile (optional)
├── src/
│   ├── __init__.py
│   ├── config.py                    ← paths, env defaults
│   ├── kb_builder.py                ← ingest heterogeneous KB files
│   ├── retriever.py                 ← RAG retrieval + rerank
│   ├── schemas.py                   ← Pydantic models (the JSON output contract)
│   ├── generator.py                 ← LLM + structured-output wrapper
│   ├── pipeline.py                  ← end-to-end Pipeline class
│   ├── serializer.py                ← .bundle export/load
│   ├── spark_udf.py                 ← PySpark pandas_udf wrapper
│   └── train_lora.py                ← optional QLoRA fine-tune for format
├── data/                            ← sample inputs (gitignored if large)
├── artifacts/                       ← generated KB + pipeline
├── bundles/                         ← exported .bundle artifacts
└── tests/
    └── smoke_test.py
```

---

## 5. Key Design Decisions

### 5.1 LLM backend: dual-mode

| Phase | Backend | Why |
|---|---|---|
| Development (with internet, on RTX 3050) | `ChatOllama` (langchain-ollama) | Fast iteration, easy model swap, supports `format=schema` |
| Distribution (no install needed) | `LlamaCpp` (langchain-community) inside the .bundle | One GGUF file, single pip wheel to install (`llama-cpp-python`), runs anywhere |

The pipeline abstracts this behind a `BaseGenerator` interface so the same code works in both modes.

### 5.2 Structured output: Pydantic + Ollama grammar mode

We never trust free-form LLM JSON. The flow is:

1. Define `JobConfig` as a `BaseModel` (the user's "JSON config format").
2. Pass `JobConfig.model_json_schema()` to `ChatOllama(format=<schema>)` → grammar-constrained decoding.
3. Wrap with `with_structured_output(JobConfig)` so the result is a typed Python object, not a string.
4. Output: ready to be `df.withColumn("config", F.struct(...))` in Spark.

### 5.3 Vector DB: Chroma (default) or pgVector (opt-in)

- ChromaDB: zero-server, SQLite-backed, perfect for single-machine offline. Default.
- pgVector: when the user already has Postgres — same interface via `langchain-postgres`.

Both expose `similarity_search` so the rest of the pipeline is identical.

### 5.4 Spark integration

`src/spark_udf.py` exposes `make_generate_udf(pipeline)` returning a `pandas_udf` that
applies the offline LLM to each row of a DataFrame in batches. This is exactly the "UDF
in Spark for generating JSON configs" the user asked for.

### 5.5 Optional fine-tuning

The user said "we may need a bit of training". A tiny QLoRA run (50–500 examples) on the
mapping-doc → JSON-config task pushes small models from "okay" to "reliable". Provided as
`src/train_lora.py` using `peft` + `bitsandbytes`, fitting in 4 GB VRAM.

After training, the LoRA is merged into the base model, exported to GGUF, and re-bundled.
This is the only step that needs internet (to download the base model). After that, fully offline.

---

## 6. Offline Guarantees After Bundle Export

Once `pipeline.bundle` is exported, the runtime needs **only**:

```text
Python 3.10+
llama-cpp-python    ← one wheel, compiled with CUDA if GPU present, CPU-only otherwise
pydantic >= 2
```

No Ollama server, no HuggingFace downloads, no internet. The bundle contains everything else:
GGUF weights, vector DB, schema, prompt template.

---

## 7. Quick-Start (TL;DR for the user)

```bash
# 0. One-time: install Ollama + pull model (internet OK here)
curl -fsSL https://ollama.com/install.sh | sh
ollama pull qwen2.5-coder:3b
ollama pull nomic-embed-text

# 1. Put your KB files in data/
cp my_events/*.json  data/source_events/
cp my_mappings/*.xlsx data/mappings/
cp my_schema/*.csv    data/schemas/
cp my_prompt.md       data/prompts/

# 2. Build KB + run pipeline
python main.py build      # builds artifacts/chroma/
python main.py generate   # generates JSON configs from sample inputs

# 3. Export portable bundle (the .pth equivalent)
python main.py bundle     # writes bundles/pipeline.bundle/

# 4. Use it anywhere, even on a low-spec box
python -m rag_flow_offline_llm run bundles/pipeline.bundle --input row.json
```

For Spark:

```python
from rag_flow_offline_llm.src.spark_udf import make_generate_udf
from rag_flow_offline_llm.src.pipeline import Pipeline
p = Pipeline.load_bundle("bundles/pipeline.bundle")
gen_udf = make_generate_udf(p, batch_size=8)
df = df.withColumn("config", gen_udf(F.struct("mapping_json", "event_json")))
```