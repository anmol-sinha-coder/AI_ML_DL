# Complete Walkthrough — Directory Structure & GPU→CPU Runbook

> **You said:** explain every file by extension type, and define steps to train on
> the NVIDIA RTX 3050, then serialize and deploy on a low-end CPU-only box.
> This document does both.

---

## Part 1 — Directory Structure (extension-by-extension)

```
rag_flow_offline_llm/                                    ← project root
│
├── README.md                                   ← quickstart (5 min read)
├── RESEARCH_AND_PLAN.md                        ← model selection & rationale
├── WALKTHROUGH.md                              ← THIS FILE
├── requirements.txt                            ← Python dependencies
├── .gitignore                                  ← ignore artifacts + bundles
│
├── ─── Python source (.py) ────────────────────
│
├── __init__.py                                 ← package init (lazy imports)
├── config.py                                   ← paths + LLMConfig / RetrievalConfig
├── schemas.py                                  ← Pydantic JobConfig (output contract)
├── kb_builder.py                               ← loaders: JSON/XLSX/CSV/Parquet/MD
├── retriever.py                                ← MMR top-k over Chroma
├── generator.py                                ← OllamaGenerator + LlamaCppGenerator
├── pipeline.py                                 ← end-to-end Pipeline class
├── serializer.py                               ← single-bundle export/load
├── spark_udf.py                                ← pandas_udf wrapper for Spark
├── train_lora.py                               ← optional QLoRA fine-tune + merge
├── main.py                                     ← CLI (build / generate / bundle / smoke)
│
├── ─── KB inputs (data/) ─────────────────────
│
├── data/
│   ├── _generate_samples.py                    ← idempotent sample-data generator
│   ├── configs/                          ← JSON inputs (single + list)
│   ├── mappings/                               ← XLSX + CSV mapping docs
│   ├── schemas/                                ← CSV + Parquet schema metadata
│   └── prompts/                                ← Markdown format / SQL / Spark specs
│
├── ─── Generated artifacts (artifacts/) ───────
│
├── artifacts/
│   ├── chroma/                                 ← persisted vector DB (SQLite)
│   ├── gold_outputs/                           ← reference JobConfig JSON (test fixtures)
│   └── example_job_config.json                 ← one example output
│
├── ─── Exported bundles (bundles/) ────────────
│
├── bundles/                                    ← .bundle dirs + .bundle.zip files
│   └── pipeline.bundle.zip                     ← THE .pt/.pth equivalent (portable)
│       ├── manifest.json                       ← version + component pointers
│       ├── pipeline.pkl                        ← dill-pickled Pipeline metadata
│       ├── model.gguf                          ← THE single model file (~1 GB)
│       ├── chroma/                             ← SQLite-backed vector DB
│       ├── schema.json                         ← Pydantic schema as JSON
│       ├── system_prompt.txt                   ← persona template
│       └── README.md                           ← consumer-facing usage
│
├── ─── Models (models/) ───────────────────────
│
├── models/                                     ← raw GGUF files (pre-bundling)
│
├── ─── Automation scripts (scripts/) ──────────
│
├── scripts/
│   ├── runbook_gpu_to_cpu.sh                   ← copy-paste GPU→CPU runbook
│   └── verify_bundle.py                        ← CPU-side bundle validator
│
└── ─── Tests (tests/) ─────────────────────────
    │
    └── smoke_test.py                           ← 5 sanity assertions (no LLM needed)
```

---

### File-by-file, **by extension type**

#### `.py` — Python source (13 files, ~2,300 LOC)

| File | Lines | Role | Imports from |
|---|---|---|---|
| `__init__.py` | 39 | Package entry. Uses `PEP 562 __getattr__` so the package can be imported even when LangChain isn't installed — important for low-spec CPU-only boxes that only need the bundle runtime. | `schemas`, lazy `pipeline` |
| `config.py` | 115 | Path defaults (`PATHS`), `LLMConfig` (backend, model, n_ctx, etc.), `RetrievalConfig` (chunk_size, top_k, MMR λ). Reads env vars via `os.getenv` so you can override without code changes. | stdlib only |
| `schemas.py` | 127 | **The single source of truth for output JSON.** Defines `SourceEvent`, `ColumnMapping`, `SparkClusterConfig`, `JobConfig`. Includes `field_validator`s (regex on identifiers, range checks). | `pydantic` |
| `kb_builder.py` | 239 | One loader per format: `_load_json` (handles single object + list), `_load_xlsx` (multi-sheet, openpyxl), `_load_csv_or_parquet` (pandas), `_load_markdown`. Public API: `load_kb_documents()` and `build_chroma_kb()`. | `langchain_core.documents`, `pandas`, `openpyxl`, `chromadb` |
| `retriever.py` | 75 | `Retriever` class wrapping Chroma. Methods: `retrieve(query, k, filter, mmr)`, `format_context(docs)`. Uses MMR with `λ=0.5` for the 1.5–3B target — no reranker model needed. | `langchain_core.documents`, `chromadb` |
| `generator.py` | 172 | `BaseGenerator` ABC + two concrete: `OllamaGenerator` (talks to local Ollama, uses `format=<pydantic_schema>` for grammar-constrained JSON) and `LlamaCppGenerator` (loads GGUF directly via `llama-cpp-python`, used in the bundle). `make_generator(cfg)` factory. | `langchain_ollama`, `llama_cpp` |
| `pipeline.py` | 199 | `Pipeline` dataclass: `llm`, `retriever`, `output_schema`, `system_template`, path hints. Core method: `generate_config(event, mapping_doc, target_schema)` — assembles prompt, calls retriever, calls LLM, returns validated `JobConfig`. `to_dict` / `from_dict` for serialization. | internal modules |
| `serializer.py` | 275 | **The `.pt/.pth` equivalent maker.** `export_bundle()` writes a self-contained directory (manifest + dill pickle + GGUF + Chroma + schema + system prompt + README). `export_zip()` zips it into a single file. `load_bundle()` reverses either form. Includes version check so old bundles are refused on breaking changes. | `dill`, `zipfile`, `shutil` |
| `spark_udf.py` | 123 | `make_generate_udf(pipeline, batch_size)` returns a `pandas_udf` (or plain function if PySpark isn't installed). Vectorized batch dispatch, per-row error isolation, ready for `df.withColumn("config", gen_udf(...))`. | `pyspark` (optional) |
| `train_lora.py` | 218 | Optional QLoRA fine-tuning. `train()` does 4-bit quantised + LoRA adapter training (fits 1.5B on 4 GB VRAM). `merge_to_gguf()` merges adapter into base, runs llama.cpp's `convert_hf_to_gguf.py`, then `llama-quantize` to Q4_K_M. CLI subcommands: `train`, `merge`. | `peft`, `bitsandbytes`, `transformers` |
| `main.py` | 271 | CLI orchestrator. Subcommands: `build` (KB), `generate` (one config), `bundle` (export), `smoke` (E2E test), `sample` (drop demo data). Wires all modules together for human use. | internal modules |
| `data/_generate_samples.py` | 320 | Idempotent sample-data generator. Builds the 19 sample files (5 JSON + 4 XLSX + 4 CSV + 1 Parquet + 5 MD) + 3 gold-output fixtures. Re-run any time to refresh. | `pandas`, `openpyxl`, `json` |
| `tests/smoke_test.py` | 189 | 5 sanity assertions: imports, schema validation (incl. illegal-identifier rejection), KB builder reads sample data, dill round-trip, bundle manifest round-trip. **No Ollama / LLM required** — runs in CI. | internal modules + minimal deps |

#### `.md` — Documentation (8 files)

| File | Role |
|---|---|
| `README.md` | Quickstart in 5 commands. First thing a new user reads. |
| `RESEARCH_AND_PLAN.md` | Model selection matrix for 4 GB VRAM, GGUF rationale, architecture diagram. |
| `WALKTHROUGH.md` | THIS FILE. Directory map + extension explanation + GPU→CPU runbook. |
| `data/prompts/format_spec.md` | JobConfig field-by-field spec. Consumed by the LLM as part of KB context. |
| `data/prompts/naming_conventions.md` | snake_case rules + reserved-word list. |
| `data/prompts/sql_templates.md` | 3 SQL patterns: Kafka→clean, Stripe→clean, CDC MERGE. |
| `data/prompts/spark_defaults.md` | Executor/cores/memory matrix by job class. |
| `data/prompts/pii_handling.md` | PII hashing rules. |
| `bundles/*/README.md` | Auto-generated consumer-facing usage notes (regenerated on each export). |

#### `.json` — Structured data (4 categories)

| Location | Format | Purpose |
|---|---|---|
| `data/configs/*.json` | Source events | Input — one row per file. Single objects + lists both supported. |
| `artifacts/gold_outputs/*.json` | Gold JobConfig | **Acceptance criteria** — diff your LLM output against these. |
| `artifacts/example_job_config.json` | One example | Reference for users to see expected shape. |
| `bundles/*/manifest.json` | Bundle metadata | `{version, backend, llm_model, gguf_filename, chroma_dir, ...}` — version-checked on load. |
| `bundles/*/schema.json` | Pydantic JSON-Schema | External validators can read without importing the package. |

#### `.csv` — Tabular metadata (4 files)

| File | Columns | Purpose |
|---|---|---|
| `data/schemas/orders_clean_schema.csv` | table_name, column_name, data_type, is_nullable, description | Per-table column list (simulates `information_schema.columns`). |
| `data/schemas/payments_clean_schema.csv` | same | Per-table column list. |
| `data/schemas/customers_clean_schema.csv` | same | Per-table column list. |
| `data/schemas/database_metadata.csv` | database, table_name, owner, size_gb, row_count, pii, classification | Catalog-level metadata (table size, PII flag, data classification). |

#### `.xlsx` — Excel workbooks (4 files, 5 sheets total)

| File | Sheets | Notable columns |
|---|---|---|
| `orders_mapping.xlsx` | `orders_clean` (10) + `orders_daily_summary` (4) | PII flags, partition/cluster keys, complex Spark SQL: `size()`, `exists()`, `current_timestamp()` |
| `payments_mapping.xlsx` | `payments_clean` (8) | Nested-path expressions: `data.object.metadata.order_id` |
| `customers_mapping.xlsx` | `customers_clean` (6) | SHA-256 hashing, MERGE SQL, soft-delete derived from CDC op |
| `inventory_mapping.xlsx` | `inventory_snapshot` (6) | Computed columns: `on_hand - reserved` |

#### `.parquet` — Binary columnar (1 file)

| File | Purpose |
|---|---|
| `data/schemas/column_metadata.parquet` | Column-level metadata in Parquet format — tests the Parquet loader path. |

#### `.txt` — Plain text (1 file, auto-generated)

| File | Purpose |
|---|---|
| `bundles/*/system_prompt.txt` | Persona template the pipeline prepends to every LLM call. Editable per project. |

#### `.pkl` — Pickled Python objects (1 file per bundle)

| File | Purpose |
|---|---|
| `bundles/*/pipeline.pkl` | dill-serialised `Pipeline.to_dict()` (just metadata + paths; no model weights). Tiny — a few KB. |

#### `.gguf` — Quantised model weights (1 file per bundle)

| File | Purpose |
|---|---|
| `bundles/*/model.gguf` | **The single model file** — weights + tokenizer + metadata + chat template. Q4_K_M quant. ~1 GB for 1.5B, ~1.9 GB for 3B. |

#### `.sh` — Shell scripts (1 file)

| File | Purpose |
|---|---|
| `scripts/runbook_gpu_to_cpu.sh` | The end-to-end GPU→CPU automation script. See Part 2 below. |

---

## Part 2 — Detailed Steps: NVIDIA RTX GPU → CPU-only System

### Overall architecture

```
┌──────────────────────────────────┐    ┌────────────────────────────┐
│  RTX 3050 box (your dev machine) │    │ CPU-only target            │
│  ──────────────────────────────  │    │ ─────────────────────────  │
│  Build KB (Chroma)               │    │                            │
│  Generate gold configs           │    │                            │
│  (Optional) QLoRA fine-tune      │    │                            │
│  Merge LoRA → export GGUF        │    │                            │
│  Bundle export (GGUF + Chroma)   │ ──▶│  pip install 4 packages    │
│  Verify bundle locally           │    │  Run pipeline              │
│                                  │    │  (LLM via llama-cpp CPU)   │
└──────────────────────────────────┘    └────────────────────────────┘
```

### Phase 0 — Pre-flight (both machines)

```bash
# Confirm RTX 3050 is visible inside WSL
nvidia-smi | head -10
# Should print:
#   | NVIDIA-SMI 5xx.xx    Driver Version: 5xx.xx    CUDA Version: 12.x
#   | GPU  Name             Persistence-M  Bus-Id        Memory-Usage | GPU-Util
#   |   0  NVIDIA GeForce RTX 3050 ...     ...           4096MiB      0%
```

If empty, install NVIDIA driver on the Windows host (Studio or Game Ready ≥ 525), reboot, then re-enter WSL.

### Phase 1 — One-time online install (GPU machine)

```bash
# 1.1 Install Ollama inside WSL
curl -fsSL https://ollama.com/install.sh -o /tmp/install.sh
sha256sum /tmp/install.sh   # compare with https://ollama.com/install.sh.sha256
sh /tmp/install.sh
ollama --version            # ≥ 0.5 recommended

# 1.2 Start the Ollama server (or enable the systemd unit)
ollama serve &              # or: sudo systemctl enable --now ollama
sleep 3
curl http://localhost:11434/api/tags   # should return {"models":[]}

# 1.3 Pull the models (this is the big ~2 GB download)
ollama pull qwen2.5-coder:3b          # 1.0 GB — primary LLM
ollama pull qwen2.5-coder:3b            # 1.9 GB — quality upgrade (optional)
ollama pull nomic-embed-text            # 274 MB — embedding model
ollama list                              # verify all 3 are present

# 1.4 Set up the Python project
cd ~ && mkdir -p projects && cd projects
# Copy the rag_flow_offline_llm/ folder here (or git clone)
cd rag_flow_offline_llm
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

### Phase 2 — Build the KB (offline from here)

```bash
# 2.1 Drop your KB inputs into data/, or use the sample corpus
python data/_generate_samples.py     # creates 19 sample files + 3 gold outputs

# 2.2 Build the Chroma vector store (one-time, takes ~30s on RTX 3050)
python main.py build
# Expected output:
#   Loaded 79 documents from data
#   Split into ~210 chunks
#   Persisted Chroma store to artifacts/chroma

# 2.3 Smoke test
python main.py smoke
# Expected: "Smoke test OK — JobConfig validated: {...}"
```

### Phase 3 — Generate sample configs (offline, validates the pipeline works)

```bash
# 3.1 Generate one config from explicit files
python main.py generate \
    --event   data/configs/orders_kafka.json \
    --mapping data/mappings/orders_mapping.xlsx \
    --schema  data/schemas/orders_clean_schema.csv \
    --out     artifacts/test_orders.json

# 3.2 Compare against the gold reference
diff <(python -c "import json; print(json.dumps(json.load(open('artifacts/test_orders.json')), indent=2, sort_keys=True))") \
     <(python -c "import json; print(json.dumps(json.load(open('artifacts/gold_outputs/gold_job_config_01.json')), indent=2, sort_keys=True))")
# A perfect pipeline will produce nearly-identical JSON.
```

### Phase 4 — Optional QLoRA fine-tune (online: base model download)

> Skip this phase if the base model already produces acceptable JSON for your
> domain — for many users, `qwen2.5-coder:3b` with grammar-constrained decoding
> is good enough out of the box.

```bash
# 4.1 Install training-only deps
pip install peft bitsandbytes transformers datasets accelerate torch

# 4.2 Build a training JSONL — one example per line:
#     {"prompt": "<event + mapping row>", "completion": "<gold JobConfig JSON>"}
# Use the gold outputs from artifacts/gold_outputs/ as seeds, generate ~50–500
# variants manually or by running the base model on slightly perturbed inputs
# and filtering the valid JSON.
python -c "
import json, pathlib
out = pathlib.Path('data/train.jsonl').open('w')
for gold_file in sorted(pathlib.Path('artifacts/gold_outputs').glob('*.json')):
    gold = json.loads(gold_file.read_text())
    # Build a prompt that looks like what the pipeline actually sends.
    event = json.loads(pathlib.Path('data/configs/orders_kafka.json').read_text())
    mapping_row = {
        'target_table': gold['target']['target_table'],
        'target_column': gold['target']['target_column'],
        'source_expression': gold['target']['source_expression'],
        'data_type': gold['target']['data_type'],
    }
    prompt = f'Generate a JobConfig JSON for: {json.dumps(event)} and {json.dumps(mapping_row)}'
    out.write(json.dumps({'prompt': prompt, 'completion': json.dumps(gold)}) + '\n')
out.close()
print(f'Wrote {len(list(pathlib.Path(\"artifacts/gold_outputs\").glob(\"*.json\")))} examples to data/train.jsonl')
"

# 4.3 Download the HuggingFace base checkpoint (one-time, ~3 GB)
python -c "
from huggingface_hub import snapshot_download
snapshot_download('Qwen/Qwen2.5-Coder-1.5B-Instruct', cache_dir='./artifacts/hf_cache')
"
# Note the actual snapshot path printed — you'll need it for the merge step.
ls artifacts/hf_cache/models--Qwen--Qwen2.5-Coder-1.5B-Instruct/snapshots/

# 4.4 Train (4 GB VRAM safe: 4-bit base + LoRA adapter)
python -m rag_flow_offline_llm.train_lora train \
    --train-jsonl data/train.jsonl \
    --base Qwen/Qwen2.5-Coder-1.5B-Instruct \
    --output-dir artifacts/lora_adapter \
    --epochs 3 --lr 2e-4

# 4.5 Merge adapter into base, export to GGUF, quantise to Q4_K_M
python -m rag_flow_offline_llm.train_lora merge \
    --adapter artifacts/lora_adapter \
    --base-path artifacts/hf_cache/models--Qwen--Qwen2.5-Coder-1.5B-Instruct/snapshots/<hash> \
    --out artifacts/model-merged.gguf \
    --quantization Q4_K_M

ls -lh artifacts/model-merged.gguf     # should be ~1.0–1.2 GB
```

### Phase 5 — Bundle export (offline)

The **bundle is the `.pt/.pth` equivalent** — a single file (or directory) that
contains the model + vector DB + schema + prompts, all together.

```bash
# 5.1 If you SKIPPED Phase 4, use the unmodified Ollama-downloaded weights.
# Find the GGUF blob Ollama already cached (largest file in the blobs dir):
ls -lhS ~/.ollama/models/blobs/ | head -3
# Copy the largest one (the model weights) to models/ as a regular file:
cp ~/.ollama/models/blobs/sha256-<biggest-hash> models/qwen2.5-coder-3b-q4_k_m.gguf

# 5.2 Export the bundle (directory form — easier to inspect)
python main.py bundle \
    --gguf models/qwen2.5-coder-3b-q4_k_m.gguf \
    --out-dir bundles/pipeline.bundle

ls bundles/pipeline.bundle/
#   manifest.json       pipeline.pkl      schema.json     system_prompt.txt
#   model.gguf          chroma/           README.md

# 5.3 (Recommended) Zip into ONE single file for easy transport
python main.py bundle \
    --gguf models/qwen2.5-coder-3b-q4_k_m.gguf \
    --out-dir bundles/pipeline.bundle \
    --zip
ls -lh bundles/pipeline.bundle.zip     # ~1.2 GB single file

# 5.4 Verify the bundle loads cleanly (this uses the llama-cpp path, not Ollama)
source .venv/bin/activate
pip install llama-cpp-python    # one wheel, auto-detects CPU vs CUDA
python scripts/verify_bundle.py bundles/pipeline.bundle.zip
```

### Phase 6 — Port to CPU-only system

The whole point: copy the bundle to a box without a GPU, install 4 packages,
and run.

```bash
# 6.1 Copy the bundle to the target machine
# (scp, rsync, USB stick, whatever — single file transfer)
scp bundles/pipeline.bundle.zip user@cpu-box:/opt/pipeline/

# 6.2 On the CPU box, install the bundle runtime (4 packages)
ssh user@cpu-box
python3 -m venv /opt/pipeline/.venv
source /opt/pipeline/.venv/bin/activate
pip install --upgrade pip
pip install dill pydantic chromadb llama-cpp-python
# For maximum CPU speed, also install the CPU-optimised build:
# pip install llama-cpp-python --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cpu

# 6.3 Verify the bundle runs (no GPU needed)
python scripts/verify_bundle.py /opt/pipeline/pipeline.bundle.zip \
    --prompt "Generate a JobConfig for a Kafka orders event mapped into orders_clean.order_id"

# 6.4 Run the pipeline from any script on the CPU box
python -c "
from rag_flow_offline_llm import load_bundle
p = load_bundle('/opt/pipeline/pipeline.bundle.zip')
cfg = p.generate_config(
    event={'event_id': 'demo', 'event_type': 'kafka_message',
           'source_system': 'orders_db', 'payload_schema': 'orders_v1',
           'sample': {'order_id': 999, 'amount': 50}},
    mapping_doc={'target_table': 'orders_clean', 'target_column': 'order_id',
                 'source_expression': 'payload.order_id', 'data_type': 'BIGINT'},
)
print(cfg.to_json_config())
"
```

### Phase 7 — Spark integration on the CPU box

```bash
# 7.1 Add PySpark to the venv
pip install pyspark==3.5

# 7.2 Submit a Spark job that uses the offline pipeline
spark-submit \
    --master local[4] \
    --py-files rag_flow_offline_llm.zip \
    my_spark_job.py
```

```python
# my_spark_job.py
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from rag_flow_offline_llm import Pipeline
from rag_flow_offline_llm.spark_udf import make_generate_udf

spark = SparkSession.builder.getOrCreate()
pipeline = Pipeline.load_bundle("/opt/pipeline/pipeline.bundle.zip")
gen_udf = make_generate_udf(pipeline, batch_size=4)

df = spark.read.json("hdfs:///data/orders/")
df = df.withColumn("event_json", F.to_json("payload"))
df = df.withColumn("job_config", gen_udf(F.col("mapping_json"), F.col("event_json")))
df.write.mode("overwrite").parquet("hdfs:///out/job_configs/")
```

---

## What runs where — summary table

| Step | Internet | GPU needed | Time on RTX 3050 |
|---|---|---|---|
| Install Ollama + pull models | ✅ Yes | No | ~5 min |
| pip install requirements | ✅ Yes | No | ~2 min |
| Build KB (`main.py build`) | ❌ No | Recommended (auto-falls-back to CPU) | ~30 s |
| Generate configs | ❌ No | Yes (1.3 GB VRAM) | ~1–2 s/config |
| QLoRA train | ✅ Yes (HF download) | Yes (4 GB VRAM) | ~10–30 min |
| Merge + GGUF export | ❌ No | No | ~1 min |
| Bundle export | ❌ No | No | ~30 s |
| **Bundle load on CPU box** | ❌ No | **No** | n/a |
| **Bundle inference on CPU box** | ❌ No | **No** | ~5–15 s/config |

## Key portability guarantees

1. **GGUF auto-falls-back to CPU** when no GPU is detected — the same .bundle.zip runs on RTX 3050, M2 Mac, AWS CPU instance, your laptop, anywhere.
2. **ChromaDB is SQLite-only** — no separate DB process needed.
3. **The bundle is self-describing** — `manifest.json` carries versions so the loader can refuse incompatible bundles (no silent breakage).
4. **Four pip packages on the target** — `dill pydantic chromadb llama-cpp-python` (or replace `chromadb` with `langchain-postgres` if you want pgVector).
5. **No Ollama server needed** on the target — the GGUF is loaded directly by `llama-cpp-python`.

---

## One-page cheat sheet

```bash
# === GPU machine (RTX 3050) ===
ollama pull qwen2.5-coder:3b && ollama pull nomic-embed-text
pip install -r requirements.txt
python data/_generate_samples.py
python main.py build && python main.py smoke
python main.py bundle --gguf ~/.ollama/models/blobs/sha256-<biggest> --zip
scp bundles/pipeline.bundle.zip user@cpu-box:/opt/pipeline/

# === CPU machine ===
pip install dill pydantic chromadb llama-cpp-python
python scripts/verify_bundle.py /opt/pipeline/pipeline.bundle.zip
```

That's the whole loop. Every byte of model logic lives in `model.gguf`; every byte of pipeline state lives in the other bundle files. No internet, no Ollama, no extra installs on the target.