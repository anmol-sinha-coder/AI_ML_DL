"""End-to-end RAG → JSON pipeline.

This is the class that:
  1. Holds the KB retriever + the LLM generator.
  2. Exposes `generate_config(...)` that turns one (event, mapping_doc) row
     into a validated `JobConfig` object.
  3. Can be serialized to a single `.bundle` directory and reloaded on any
     machine without Ollama, without internet, without re-installing dozens
     of packages.

The `dill`-serialized `Pipeline` object is small — it's just pointers to the
GGUF file path + the Chroma directory path + the schema class. The heavy
artifacts live as separate files in the bundle.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from pydantic import BaseModel

from config import LLM_CFG, LLMConfig, PATHS, RETR_CFG, RetrievalConfig
from generator import BaseGenerator, make_generator
from retriever import Retriever
from schemas import JobConfig

logger = logging.getLogger(__name__)


# --------------------------------------------------------------------------- #
# The orchestration primitive
# --------------------------------------------------------------------------- #
@dataclass
class Pipeline:
    """The offline RAG → JSON pipeline.

    Fields are deliberately minimal — everything heavy (GGUF, Chroma, …) lives
    on disk in the bundle. This object is small enough to `dill` in milliseconds.
    """

    llm: BaseGenerator
    retriever: Retriever
    output_schema: type[BaseModel] = JobConfig
    # The "system prompt" template. We keep it as a field so users can override
    # the persona without subclassing.
    system_template: str = (
        "You are an offline data-engineering assistant. Given a source event, "
        "a column mapping document, and a target table schema, produce a Spark "
        "job config as strict JSON. Do not invent columns or tables. Use only "
        "identifiers present in the provided context. If something is missing, "
        "omit the field rather than guess."
    )
    # Path hints — only used at load time.
    chroma_dir: str = str(PATHS.chroma_dir)
    collection_name: str = RETR_CFG.collection_name
    backend: str = LLM_CFG.backend
    llm_model: str = LLM_CFG.ollama_model
    gguf_path: str | None = LLM_CFG.gguf_path
    extras: dict[str, Any] = field(default_factory=dict)

    # ------------------------------------------------------------------ #
    # Core inference
    # ------------------------------------------------------------------ #
    def retrieve_context(
        self,
        query: str,
        *,
        k: int | None = None,
        filter: dict[str, Any] | None = None,
    ) -> str:
        docs = self.retriever.retrieve(query, k=k, filter=filter)
        return self.retriever.format_context(docs)

    def generate_config(
        self,
        *,
        event: dict[str, Any],
        mapping_doc: dict[str, Any],
        target_schema: dict[str, Any] | None = None,
        extra_context: str | None = None,
    ) -> JobConfig:
        """Generate one validated `JobConfig` from one row's worth of inputs.

        Args:
            event:          source-event row (JSON-decoded dict).
            mapping_doc:    column-mapping row (JSON-decoded dict).
            target_schema:  optional target-table schema row.
            extra_context:  optional literal context to append (for tests).
        """

        query_parts = [
            json.dumps(event, ensure_ascii=False),
            json.dumps(mapping_doc, ensure_ascii=False),
        ]
        if target_schema is not None:
            query_parts.append(json.dumps(target_schema, ensure_ascii=False))
        query = "\n\n".join(query_parts)

        context = self.retrieve_context(query)
        if extra_context:
            context = context + "\n\n" + extra_context

        user = (
            "## Source Event\n"
            f"```json\n{json.dumps(event, indent=2, ensure_ascii=False)}\n```\n\n"
            "## Column Mapping\n"
            f"```json\n{json.dumps(mapping_doc, indent=2, ensure_ascii=False)}\n```\n\n"
        )
        if target_schema is not None:
            user += (
                "## Target Table Schema\n"
                f"```json\n{json.dumps(target_schema, indent=2, ensure_ascii=False)}\n```\n\n"
            )
        user += "## Retrieved Knowledge Base Context\n" + context + "\n\n"
        user += (
            "Produce the JSON config now. Output ONLY the JSON object — "
            "no prose, no markdown fence."
        )

        result = self.llm.generate(
            system=self.system_template,
            user=user,
            schema=self.output_schema,
        )
        if not isinstance(result, JobConfig):
            # Defensive — should be guaranteed by schema enforcement.
            result = JobConfig.model_validate(result.model_dump() if isinstance(result, BaseModel) else result)
        return result

    # ------------------------------------------------------------------ #
    # Bundle I/O — these are the "PyTorch .pt/.pth" of the whole pipeline.
    # ------------------------------------------------------------------ #
    def to_dict(self) -> dict[str, Any]:
        """Minimal serialisable representation (dill/pickle-safe)."""
        return {
            "output_schema_name": self.output_schema.__name__,
            "system_template": self.system_template,
            "chroma_dir": self.chroma_dir,
            "collection_name": self.collection_name,
            "backend": self.backend,
            "llm_model": self.llm_model,
            "gguf_path": self.gguf_path,
            "extras": self.extras,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Pipeline":
        """Rebuild from a dict — needs the GGUF + Chroma to be present on disk.

        The serializer (see `src/serializer.py`) writes those alongside the
        dill pickle, so by the time you call `from_dict` everything is wired up.
        """
        # Resolve schema class by name — avoids hard-import cycles.
        from . import schemas as _schemas

        schema_cls = getattr(_schemas, d["output_schema_name"])

        # Build the right generator based on backend hint.
        cfg = LLMConfig(
            backend=d["backend"],
            ollama_model=d["llm_model"],
            gguf_path=d.get("gguf_path"),
        )
        llm = make_generator(cfg)

        # Build a retriever that re-uses the persisted Chroma.
        if d["backend"] == "ollama":
            from langchain_ollama import OllamaEmbeddings  # type: ignore
            embed = OllamaEmbeddings(model=d.get("llm_model") or LLM_CFG.ollama_embed_model)
        else:
            from langchain_community.embeddings import HuggingFaceEmbeddings
            embed = HuggingFaceEmbeddings(
                model_name="sentence-transformers/all-MiniLM-L6-v2",
                cache_folder=str(Path(d["chroma_dir"]) / "_hf_cache"),
            )
        retriever = Retriever.load(
            d["chroma_dir"],
            collection_name=d["collection_name"],
            embedding=embed,
        )

        return cls(
            llm=llm,
            retriever=retriever,
            output_schema=schema_cls,
            system_template=d["system_template"],
            chroma_dir=d["chroma_dir"],
            collection_name=d["collection_name"],
            backend=d["backend"],
            llm_model=d["llm_model"],
            gguf_path=d.get("gguf_path"),
            extras=d.get("extras", {}),
        )


