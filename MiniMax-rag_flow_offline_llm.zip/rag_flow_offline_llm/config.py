"""Project-wide configuration. All paths and env defaults live here.

We deliberately avoid `pydantic-settings` or `dynaconf` to keep the install footprint
small — the bundle needs to run with only `pydantic` + `llama-cpp-python` if possible.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


# --------------------------------------------------------------------------- #
# Default paths (relative to the project root, which is the parent of `src/`).
# --------------------------------------------------------------------------- #
PROJECT_ROOT: Path = Path(__file__).resolve().parent.parent
DATA_DIR: Path = PROJECT_ROOT / "data"
ARTIFACTS_DIR: Path = PROJECT_ROOT / "artifacts"
BUNDLES_DIR: Path = PROJECT_ROOT / "bundles"
MODELS_DIR: Path = PROJECT_ROOT / "models"

# Sub-directories under data/
DATA_JSON_CONFIGS: Path = DATA_DIR / "configs"
DATA_MAPPINGS: Path = DATA_DIR / "mappings"
DATA_SCHEMAS: Path = DATA_DIR / "schemas"
DATA_PROMPTS: Path = DATA_DIR / "prompts"

# Sub-directories under artifacts/
CHROMA_DIR: Path = ARTIFACTS_DIR / "chroma"
EMBEDDINGS_CACHE: Path = ARTIFACTS_DIR / "embeddings_cache"
PIPELINE_PKL: Path = ARTIFACTS_DIR / "pipeline.pkl"


# --------------------------------------------------------------------------- #
# LLM defaults — change here, not in module bodies.
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class LLMConfig:
    """LLM runtime configuration.

    Two backends supported:

    * `ollama`     — used during development on the RTX 3050. Talks to a local
                     Ollama server (must be running). Easiest iteration.
    * `llamacpp`   — used inside an exported `.bundle`. Self-contained: loads
                     a GGUF directly via `llama-cpp-python`, no server needed.

    For a 4 GB VRAM RTX 3050, the sweet spot is `qwen2.5-coder:3b` or
    `qwen2.5-coder:3b` at Q4_K_M. Heavier models spill to system RAM and run
    2-10x slower.
    """

    backend: str = os.getenv("OFFLINE_RAG_BACKEND", "ollama")

    # Ollama-side
    ollama_base_url: str = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    ollama_model: str = os.getenv("OFFLINE_RAG_LLM", "qwen2.5-coder:3b")
    ollama_embed_model: str = os.getenv(
        "OFFLINE_RAG_EMBED", "nomic-embed-text"
    )

    # llama.cpp-side
    gguf_path: str | None = os.getenv("OFFLINE_RAG_GGUF", None)
    n_ctx: int = int(os.getenv("OFFLINE_RAG_NCTX", "4096"))
    n_threads: int = int(os.getenv("OFFLINE_RAG_THREADS", "0"))  # 0 = auto
    n_gpu_layers: int = int(os.getenv("OFFLINE_RAG_NGL", "99"))  # 99 = all

    # Generation params
    temperature: float = 0.0  # structured output → deterministic
    max_retries: int = 3


@dataclass(frozen=True)
class RetrievalConfig:
    """Vector retrieval defaults."""

    collection_name: str = "rag_flow_offline_llm_kb"
    chunk_size: int = 800
    chunk_overlap: int = 120
    top_k: int = 6
    fetch_k: int = 20  # over-fetch for MMR
    mmr_lambda: float = 0.5


@dataclass(frozen=True)
class ProjectPaths:
    """Bundle of all paths so callers don't import each one."""

    project_root: Path = PROJECT_ROOT
    data_dir: Path = DATA_DIR
    artifacts_dir: Path = ARTIFACTS_DIR
    bundles_dir: Path = BUNDLES_DIR
    models_dir: Path = MODELS_DIR
    chroma_dir: Path = CHROMA_DIR
    pipeline_pkl: Path = PIPELINE_PKL


PATHS = ProjectPaths()
LLM_CFG = LLMConfig()
RETR_CFG = RetrievalConfig()


def ensure_dirs() -> None:
    """Create all output directories if missing (idempotent)."""
    for p in (
        PATHS.artifacts_dir,
        PATHS.bundles_dir,
        PATHS.models_dir,
        PATHS.chroma_dir,
        DATA_JSON_CONFIGS,
        DATA_MAPPINGS,
        DATA_SCHEMAS,
        DATA_PROMPTS,
    ):
        p.mkdir(parents=True, exist_ok=True)