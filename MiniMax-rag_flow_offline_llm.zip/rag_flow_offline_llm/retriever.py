"""RAG retriever.

A thin wrapper around the Chroma store exposing:

  * `retrieve(query, k, filter)` — top-k by similarity, with optional metadata filter.
  * `format_context(docs)` — concatenates docs into a single string the LLM can chew on.

In production, this is also where you'd plug reranking (BGE-reranker, Cohere, …).
For a 1.5–3 B model on a 4 GB GPU, plain MMR with `lambda=0.5` is the sweet spot —
no extra model needed.
"""

from __future__ import annotations

import logging
from typing import Any

from langchain_core.documents import Document
from langchain_community.vectorstores import Chroma

logger = logging.getLogger(__name__)


class Retriever:
    """Stateless wrapper around a Chroma vector store."""

    def __init__(self, store: Chroma, *, default_k: int = 6) -> None:
        self.store = store
        self.default_k = default_k

    @classmethod
    def load(cls, persist_dir: str, *, collection_name: str, embedding) -> "Retriever":
        store = Chroma(
            persist_directory=persist_dir,
            collection_name=collection_name,
            embedding_function=embedding,
        )
        return cls(store)

    def retrieve(
        self,
        query: str,
        *,
        k: int | None = None,
        filter: dict[str, Any] | None = None,
        mmr: bool = True,
        fetch_k: int = 20,
        lambda_mult: float = 0.5,
    ) -> list[Document]:
        k = k or self.default_k

        if mmr:
            return self.store.max_marginal_relevance_search(
                query, k=k, fetch_k=fetch_k, lambda_mult=lambda_mult, filter=filter
            )
        return self.store.similarity_search(query, k=k, filter=filter)

    @staticmethod
    def format_context(docs: list[Document], *, max_chars_per_doc: int = 1500) -> str:
        """Concatenate docs with provenance into a single context block.

        We cap each doc to keep total context predictable; the LLM only needs
        salient snippets for the JSON-config task.
        """
        parts: list[str] = []
        for i, d in enumerate(docs, start=1):
            meta = d.metadata or {}
            provenance = (
                f"{meta.get('source_type','?')}:{meta.get('file_name','?')}"
                + (f" row={meta['row_index']}" if "row_index" in meta else "")
            )
            content = d.page_content
            if len(content) > max_chars_per_doc:
                content = content[:max_chars_per_doc] + "…"
            parts.append(f"[{i}] ({provenance})\n{content}")
        return "\n\n---\n\n".join(parts)