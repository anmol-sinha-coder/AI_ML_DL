"""LLM wrappers — Ollama (development) and llama-cpp (distribution).

The `BaseGenerator` exposes a single `generate(prompt, schema) -> BaseModel` method.
Two concrete implementations:

  * `OllamaGenerator`      — used during development on the RTX 3050.
  * `LlamaCppGenerator`    — used inside an exported `.bundle`, where the GGUF
                              travels with the bundle and no Ollama server is needed.

Both use **Pydantic + grammar-constrained JSON** so the output is always a
validated object, never a string to re-parse by hand.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any, Type

from pydantic import BaseModel

from config import LLMConfig

logger = logging.getLogger(__name__)


class BaseGenerator(ABC):
    """Abstract generator. Pipeline doesn't care which backend is plugged in."""

    @abstractmethod
    def generate(self, *, system: str, user: str, schema: Type[BaseModel]) -> BaseModel:
        """Run one generation. Must return a validated `schema` instance.

        Implementations are expected to retry on parse failure (up to
        `LLMConfig.max_retries`) with stricter prompts.
        """

        raise NotImplementedError


# --------------------------------------------------------------------------- #
# Ollama backend — talks to a local `ollama serve`.
# --------------------------------------------------------------------------- #
class OllamaGenerator(BaseGenerator):
    """Backend for development. Requires `ollama serve` running.

    The key trick is `format=<pydantic_schema>` — Ollama constrains token decoding
    so the raw output is guaranteed valid JSON conforming to that schema.
    """

    def __init__(self, cfg: LLMConfig | None = None) -> None:
        self.cfg = cfg or LLMConfig()
        # Lazy import — Ollama is not required when running from a bundle.
        from langchain_ollama import ChatOllama  # type: ignore

        self.llm = ChatOllama(
            model=self.cfg.ollama_model,
            base_url=self.cfg.ollama_base_url,
            temperature=self.cfg.temperature,
            num_ctx=self.cfg.n_ctx,
            format="json",  # base JSON grammar; we add schema via with_structured_output
        )

    def generate(self, *, system: str, user: str, schema: Type[BaseModel]) -> BaseModel:
        # with_structured_output on ChatOllama passes the schema to Ollama and
        # returns a typed object on success, or raises on parse failure.
        structured = self.llm.with_structured_output(schema, method="json_schema")
        msg = structured.invoke(
            [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ]
        )
        if not isinstance(msg, schema):
            # Fallback: some Ollama versions return dict when method=json_mode
            if isinstance(msg, dict):
                return schema.model_validate(msg)
            raise TypeError(f"Unexpected return type {type(msg)} for {schema.__name__}")
        return msg


# --------------------------------------------------------------------------- #
# llama.cpp backend — loads GGUF directly, no server.
# --------------------------------------------------------------------------- #
class LlamaCppGenerator(BaseGenerator):
    """Backend for distribution. Self-contained — needs only `llama-cpp-python`.

    Uses grammar-constrained JSON via `llama_cpp.Grammar` for the same
    schema-enforced decoding as the Ollama backend.
    """

    def __init__(self, cfg: LLMConfig | None = None, gguf_path: str | None = None) -> None:
        self.cfg = cfg or LLMConfig()
        path = gguf_path or self.cfg.gguf_path
        if not path:
            raise ValueError(
                "LlamaCppGenerator needs a GGUF path. "
                "Set OFFLINE_RAG_GGUF or pass gguf_path=..."
            )

        # Lazy import so the Ollama-only path doesn't need this package.
        from llama_cpp import Llama, LlamaGrammar  # type: ignore

        n_threads = self.cfg.n_threads or 0
        self._LlamaGrammar = LlamaGrammar

        self.llm = Llama(
            model_path=path,
            n_ctx=self.cfg.n_ctx,
            n_threads=n_threads,
            n_gpu_layers=self.cfg.n_gpu_layers,
            verbose=False,
        )

    def _grammar_for(self, schema: Type[BaseModel]) -> Any:
        """Build a GBNF grammar from a Pydantic schema.

        Note: pydantic's `model_json_schema()` is JSON-Schema; we hand it to
        a small helper that emits the matching GBNF. For non-trivial nested
        schemas we lean on `llama_cpp`'s built-in JSON grammar combined with
        prompt-time schema injection.
        """
        # llama.cpp ships a built-in JSON grammar; combined with prompt-side
        # schema this is sufficient for our 1.5–3B target models.
        json_grammar_text = r"""
            root   ::= object
            value  ::= object | array | string | number | ("true" | "false" | "null") ws
            object ::= "{" ws ( string ":" ws value ("," ws string ":" ws value)* )? "}" ws
            array  ::= "[" ws ( value ("," ws value)* )? "]" ws
            string ::= "\"" ( [^"\\] | "\\" ["\\bfnrt/] )* "\"" ws
            number ::= ("-"? ([0-9] | [1-9] [0-9]*)) ("." [0-9]+)? ([eE] [-+]? [0-9]+)? ws
            ws     ::= [ \t\n]*
        """
        return self._LlamaGrammar.from_string(json_grammar_text)

    def generate(self, *, system: str, user: str, schema: Type[BaseModel]) -> BaseModel:
        schema_json = schema.model_json_schema()
        prompt = (
            f"<|im_start|>system\n{system}\n"
            f"Return ONLY valid JSON matching this schema:\n"
            f"{schema_json}\n<|im_end|>\n"
            f"<|im_start|>user\n{user}<|im_end|>\n"
            f"<|im_start|>assistant\n"
        )
        grammar = self._grammar_for(schema)

        last_err: Exception | None = None
        for _ in range(self.cfg.max_retries):
            out = self.llm(
                prompt,
                max_tokens=self.cfg.n_ctx // 2,
                temperature=self.cfg.temperature,
                grammar=grammar,
                stop=["<|im_end|>"],
            )
            text = out["choices"][0]["text"].strip()
            try:
                return schema.model_validate_json(text)
            except Exception as e:  # noqa: BLE001
                last_err = e
                logger.warning("Parse failed, retrying: %s", e)

        raise RuntimeError(f"Failed to parse after {self.cfg.max_retries} retries: {last_err}")


def make_generator(cfg: LLMConfig | None = None) -> BaseGenerator:
    """Factory: pick the right backend from cfg.backend."""
    cfg = cfg or LLMConfig()
    if cfg.backend == "ollama":
        return OllamaGenerator(cfg)
    if cfg.backend == "llamacpp":
        return LlamaCppGenerator(cfg)
    raise ValueError(f"Unknown backend: {cfg.backend!r}")