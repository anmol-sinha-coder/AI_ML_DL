#!/usr/bin/env python3
"""Verify a bundle works on any machine (GPU or CPU).

This is the script that proves your single-file bundle is portable. Run it on
the CPU-only target machine after copying `pipeline.bundle.zip` over:

    pip install dill pydantic chromadb llama-cpp-python
    python scripts/verify_bundle.py /opt/pipeline/pipeline.bundle.zip

It will:

1. Load the bundle (zip or directory).
2. Print the manifest contents.
3. Load the GGUF into `llama-cpp-python` (auto-detects GPU vs CPU).
4. Run one generation with a hard-coded event + mapping.
5. Validate the result against the `JobConfig` Pydantic schema.
6. Print the resulting JSON.

Exit code 0 on success, non-zero on failure.

Optional flag `--prompt "..."` lets you supply a custom test prompt.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def _ensure_minimum_deps() -> None:
    """Fail with a helpful message if any required dep is missing."""
    missing = []
    for mod in ("dill", "pydantic", "chromadb", "llama_cpp"):
        try:
            __import__(mod)
        except ImportError:
            missing.append(mod)
    if missing:
        sys.exit(
            f"Missing required packages: {', '.join(missing)}\n"
            "Install with:\n"
            "    pip install dill pydantic chromadb llama-cpp-python\n"
            "For CPU-only speed:\n"
            "    pip install llama-cpp-python "
            "--extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cpu"
        )


def verify(bundle_path: Path, custom_prompt: str | None = None) -> int:
    # Make `offline_rag` importable when run from the scripts/ directory.
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

    _ensure_minimum_deps()

    print(f"[1/5] Loading bundle: {bundle_path}")
    if not bundle_path.exists():
        print(f"  ERROR: bundle not found at {bundle_path}")
        return 1
    from offline_rag import load_bundle  # noqa: WPS433 (lazy import)

    pipeline = load_bundle(bundle_path)
    print(f"  ✓ bundle loaded")
    print(f"     backend   = {pipeline.backend}")
    print(f"     LLM model = {pipeline.llm_model}")
    print(f"     GGUF path = {pipeline.gguf_path}")
    print(f"     Chroma    = {pipeline.chroma_dir}")
    print(f"     schema    = {pipeline.output_schema.__name__}")

    # The bundle is wired with the LlamaCppGenerator because we exported for
    # CPU portability. Force-load the GGUF and confirm the model is alive.
    print(f"[2/5] Loading GGUF into llama-cpp-python")
    from llama_cpp import Llama  # type: ignore

    llm = Llama(
        model_path=pipeline.gguf_path,
        n_ctx=2048,
        n_threads=0,         # auto = all cores
        n_gpu_layers=99,      # all layers on GPU if available, else CPU auto-fallback
        verbose=False,
    )
    print(f"  ✓ GGUF loaded into memory")

    # Quick liveness check
    print(f"[3/5] Liveness check (tokenise + decode)")
    test = llm.tokenize(b"hello")
    assert len(test) > 0
    print(f"  ✓ tokenized 'hello' → {len(test)} tokens")

    # Run one generation
    print(f"[4/5] Running a real JobConfig generation")
    sample_event = {
        "event_id": "verify.orders.kafka",
        "event_type": "kafka_message",
        "source_system": "orders_db",
        "payload_schema": "orders_v1",
        "sample": {"order_id": 99999, "customer_id": "C-VERIFY",
                   "amount": 199.99, "currency": "USD"},
    }
    sample_mapping = {
        "target_table": "orders_clean",
        "target_column": "order_id",
        "source_expression": "payload.order_id",
        "data_type": "BIGINT",
    }

    # Skip the Chroma retriever (the verify script doesn't need a built KB).
    # We just confirm the LLM path emits valid JSON conforming to JobConfig.
    schema = pipeline.output_schema
    schema_json = json.dumps(schema.model_json_schema(), indent=2)
    system = (
        "You are an offline data-engineering assistant. Produce a strict JSON "
        "object matching the user's JobConfig schema. No prose, no markdown."
    )
    user = (
        f"SCHEMA:\n{schema_json}\n\n"
        f"EVENT:\n{json.dumps(sample_event, indent=2)}\n\n"
        f"MAPPING:\n{json.dumps(sample_mapping, indent=2)}\n\n"
        "Produce the JobConfig now."
    )

    # Grammar-constrained JSON decoding
    json_grammar = r"""
        root   ::= object
        value  ::= object | array | string | number | ("true" | "false" | "null") ws
        object ::= "{" ws ( string ":" ws value ("," ws string ":" ws value)* )? "}" ws
        array  ::= "[" ws ( value ("," ws value)* )? "]" ws
        string ::= "\"" ( [^"\\] | "\\" ["\\bfnrt/] )* "\"" ws
        number ::= ("-"? ([0-9] | [1-9] [0-9]*)) ("." [0-9]+)? ([eE] [-+]? [0-9]+)? ws
        ws     ::= [ \t\n]*
    """
    grammar = None
    try:
        from llama_cpp import LlamaGrammar  # type: ignore
        grammar = LlamaGrammar.from_string(json_grammar)
    except Exception:  # noqa: BLE001
        print("  ! grammar not supported in this llama-cpp build; falling back to plain JSON")

    prompt = (
        "<|im_start|>system\n" + system + "<|im_end|>\n"
        "<|im_start|>user\n" + user + "<|im_end|>\n"
        "<|im_start|>assistant\n"
    )

    out = llm(
        prompt,
        max_tokens=600,
        temperature=0.0,
        grammar=grammar,
        stop=["<|im_end|>"],
    )
    text = out["choices"][0]["text"].strip()

    # Validate
    print(f"[5/5] Validating against JobConfig schema")
    try:
        cfg = schema.model_validate_json(text)
    except Exception as e:  # noqa: BLE001
        print(f"  ✗ validation failed: {e}")
        print(f"  raw output: {text[:500]}…")
        return 2

    print(f"  ✓ JobConfig validated")
    print()
    print("============================================================")
    print(f"job_name       : {cfg.job_name}")
    print(f"description    : {cfg.description}")
    print(f"target_table   : {cfg.target.target_table}")
    print(f"target_column  : {cfg.target.target_column}")
    print(f"data_type      : {cfg.target.data_type}")
    print(f"spark.master   : {cfg.spark.master if cfg.spark else 'None'}")
    print(f"sql[:80]       : {cfg.sql[:80]}{'…' if len(cfg.sql) > 80 else ''}")
    print(f"tags           : {cfg.tags}")
    print("============================================================")
    print()
    print("Full JSON output:")
    print(cfg.to_json_config())
    print()
    print("✓ Bundle verified successfully.")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("bundle", type=Path,
                    help="Path to the bundle directory or .zip file")
    ap.add_argument("--prompt", default=None,
                    help="Optional custom prompt (reserved for future use)")
    args = ap.parse_args()

    try:
        return verify(args.bundle, args.prompt)
    except KeyboardInterrupt:
        print("\nAborted.")
        return 130


if __name__ == "__main__":
    sys.exit(main())