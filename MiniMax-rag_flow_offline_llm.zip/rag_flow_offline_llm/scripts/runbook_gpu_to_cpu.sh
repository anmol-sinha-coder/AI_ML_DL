#!/usr/bin/env bash
# ============================================================================
#  Offline RAG Pipeline — GPU → CPU runbook
#  ----------------------------------------------------------------------------
#  Executes the entire pipeline from KB build on the RTX 3050 through to
#  bundle verification. Each phase is gated on a confirmation prompt so you
#  can stop at any checkpoint.
#
#  Usage:
#     bash scripts/runbook_gpu_to_cpu.sh                 # interactive
#     bash scripts/runbook_gpu_to_cpu.sh --yes           # no prompts (CI mode)
#     bash scripts/runbook_gpu_to_cpu.sh --skip-train    # skip QLoRA phase
#     bash scripts/runbook_gpu_to_cpu.sh --skip-verify   # skip post-export check
# ============================================================================

set -euo pipefail

# ------------------------------ Configuration ------------------------------ #
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LLM_MODEL="${OFFLINE_RAG_LLM:-qwen2.5-coder:1.5b}"
EMBED_MODEL="${OFFLINE_RAG_EMBED:-nomic-embed-text}"
BUNDLE_DIR="$PROJECT_ROOT/bundles/pipeline.bundle"
BUNDLE_ZIP="$PROJECT_ROOT/bundles/pipeline.bundle.zip"

# ------------------------------- CLI parsing ------------------------------ #
YES=0
SKIP_TRAIN=0
SKIP_VERIFY=0
SKIP_BUILD=0
for arg in "$@"; do
    case "$arg" in
        --yes)            YES=1 ;;
        --skip-train)     SKIP_TRAIN=1 ;;
        --skip-verify)    SKIP_VERIFY=1 ;;
        --skip-build)     SKIP_BUILD=1 ;;
        -h|--help)
            sed -n '2,18p' "$0"; exit 0 ;;
        *) echo "Unknown arg: $arg"; exit 2 ;;
    esac
done

# Helper: prompt unless --yes
confirm() {
    local prompt="$1"
    if [[ $YES -eq 1 ]]; then return 0; fi
    read -rp "$prompt [y/N] " ans
    [[ "$ans" =~ ^[Yy]$ ]]
}

step() { printf "\n\033[1;36m▶ %s\033[0m\n" "$*"; }
ok()   { printf "  \033[1;32m✓\033[0m %s\n" "$*"; }
warn() { printf "  \033[1;33m!\033[0m %s\n" "$*"; }
fail() { printf "  \033[1;31m✗\033[0m %s\n" "$*"; exit 1; }

# ------------------------------ Pre-flight -------------------------------- #
step "Pre-flight: verifying environment"

command -v python3 >/dev/null   || fail "python3 not found"
command -v ollama   >/dev/null  || fail "ollama not found — install from https://ollama.com"

if command -v nvidia-smi >/dev/null 2>&1; then
    if nvidia-smi -L | grep -qi "RTX 3050\|GTX 16\|RTX 30"; then
        ok "GPU detected:"
        nvidia-smi -L | sed 's/^/      /'
    else
        warn "nvidia-smi present but no recognised GPU; falling back to CPU"
    fi
else
    warn "nvidia-smi not present; will run on CPU only"
fi

# ------------------------------ Phase 1 ----------------------------------- #
step "Phase 1 — ensure models are pulled (online, one-time)"
if confirm "Pull '$LLM_MODEL' and '$EMBED_MODEL' if missing?"; then
    ollama list | grep -q "^${LLM_MODEL}:"     || ollama pull "$LLM_MODEL"
    ollama list | grep -q "^${EMBED_MODEL}:"   || ollama pull "$EMBED_MODEL"
    ok "Ollama models ready"
else
    ok "Skipped (assumed pre-existing)"
fi

# ------------------------------ Phase 2 ----------------------------------- #
step "Phase 2 — Python deps + sample data"
confirm "Install Python dependencies + generate sample data?" || true
python3 -m pip install -q --upgrade pip
python3 -m pip install -q -r "$PROJECT_ROOT/requirements.txt"
[[ -f "$PROJECT_ROOT/data/source_events/orders_kafka.json" ]] \
    || python3 "$PROJECT_ROOT/data/_generate_samples.py"
ok "Python deps + sample data ready"

# ------------------------------ Phase 3 ----------------------------------- #
if [[ $SKIP_BUILD -eq 0 ]]; then
    step "Phase 3 — build KB vector store"
    confirm "Run 'python main.py build'?" || true
    ( cd "$PROJECT_ROOT" && python3 main.py build )
    ok "KB built at artifacts/chroma/"
else
    warn "Skipped KB build (--skip-build)"
fi

# ------------------------------ Phase 4 ----------------------------------- #
step "Phase 4 — smoke test"
confirm "Run 'python main.py smoke'?" || true
( cd "$PROJECT_ROOT" && python3 main.py smoke )
ok "Smoke test passed"

# ------------------------------ Phase 5 ----------------------------------- #
if [[ $SKIP_TRAIN -eq 0 ]]; then
    step "Phase 5 — optional QLoRA fine-tune"
    if confirm "Train a QLoRA adapter? (Requires ~5 GB VRAM and ~30 min)"; then
        python3 -m pip install -q peft bitsandbytes transformers datasets accelerate
        # Locate HF base checkpoint
        HF_BASE="$PROJECT_ROOT/artifacts/hf_cache/models--Qwen--Qwen2.5-Coder-1.5B-Instruct"
        if [[ ! -d "$HF_BASE" ]]; then
            python3 -c "from huggingface_hub import snapshot_download; snapshot_download('Qwen/Qwen2.5-Coder-1.5B-Instruct', cache_dir='$PROJECT_ROOT/artifacts/hf_cache')"
        fi
        SNAPSHOT=$(ls -d "$HF_BASE"/snapshots/*/ | head -1)

        # Generate a small train.jsonl from gold outputs if not present
        if [[ ! -f "$PROJECT_ROOT/data/train.jsonl" ]]; then
            python3 - "$PROJECT_ROOT" <<'PYEOF'
import json, pathlib, sys
root = pathlib.Path(sys.argv[1])
with (root / "data/train.jsonl").open("w") as out:
    for gold in sorted((root / "artifacts/gold_outputs").glob("*.json")):
        cfg = json.loads(gold.read_text())
        event = json.loads((root / "data/source_events/orders_kafka.json").read_text())
        mapping_row = {
            "target_table": cfg["target"]["target_table"],
            "target_column": cfg["target"]["target_column"],
            "source_expression": cfg["target"]["source_expression"],
            "data_type": cfg["target"]["data_type"],
        }
        prompt = (
            "Generate a JobConfig JSON for:\n"
            f"EVENT: {json.dumps(event)}\n"
            f"MAPPING: {json.dumps(mapping_row)}"
        )
        out.write(json.dumps({"prompt": prompt, "completion": json.dumps(cfg)}) + "\n")
print("Wrote data/train.jsonl")
PYEOF
        fi

        ( cd "$PROJECT_ROOT" && python3 -m offline_rag.train_lora train \
            --train-jsonl data/train.jsonl \
            --base Qwen/Qwen2.5-Coder-1.5B-Instruct \
            --output-dir artifacts/lora_adapter \
            --epochs 3 --lr 2e-4 )

        # Merge + quantise to GGUF
        ( cd "$PROJECT_ROOT" && python3 -m offline_rag.train_lora merge \
            --adapter artifacts/lora_adapter \
            --base-path "$SNAPSHOT" \
            --out artifacts/model-merged.gguf \
            --quantization Q4_K_M )

        GGUF_PATH="$PROJECT_ROOT/artifacts/model-merged.gguf"
        ok "Trained + merged GGUF at $GGUF_PATH"
    else
        warn "Skipped fine-tune"
        GGUF_PATH=""
    fi
else
    warn "Skipped training phase (--skip-train)"
    GGUF_PATH=""
fi

# ------------------------------ Phase 6 ----------------------------------- #
step "Phase 6 — bundle export"
if [[ -z "${GGUF_PATH:-}" || ! -f "${GGUF_PATH}" ]]; then
    # Use the largest blob in Ollama's cache (the model weights)
    GGUF_PATH=$(ls -S "$HOME/.ollama/models/blobs/" 2>/dev/null | head -1 \
        | xargs -I{} echo "$HOME/.ollama/models/blobs/{}")
    if [[ -z "$GGUF_PATH" || ! -f "$GGUF_PATH" ]]; then
        fail "No GGUF found. Either complete Phase 5 or supply --gguf."
    fi
    ok "Using Ollama-cached GGUF: $GGUF_PATH"
fi

confirm "Export bundle directory + zip?" || true
mkdir -p "$PROJECT_ROOT/bundles" "$PROJECT_ROOT/models"
cp "$GGUF_PATH" "$PROJECT_ROOT/models/qwen2.5-coder-1.5b-q4_k_m.gguf"
( cd "$PROJECT_ROOT" && python3 main.py bundle \
    --gguf "$PROJECT_ROOT/models/qwen2.5-coder-1.5b-q4_k_m.gguf" \
    --out-dir "$BUNDLE_DIR" )
( cd "$PROJECT_ROOT" && python3 main.py bundle \
    --gguf "$PROJECT_ROOT/models/qwen2.5-coder-1.5b-q4_k_m.gguf" \
    --out-dir "$BUNDLE_DIR" --zip )
ls -lh "$BUNDLE_ZIP"
ok "Bundle ready: $BUNDLE_ZIP"

# ------------------------------ Phase 7 ----------------------------------- #
if [[ $SKIP_VERIFY -eq 0 ]]; then
    step "Phase 7 — verify bundle (uses llama-cpp, GPU or CPU)"
    confirm "Run 'python scripts/verify_bundle.py'?" || true
    python3 -m pip install -q llama-cpp-python
    ( cd "$PROJECT_ROOT" && python3 scripts/verify_bundle.py "$BUNDLE_ZIP" )
    ok "Bundle verified — ready for CPU-only deployment"
fi

step "DONE"
echo "  Single-file bundle: $BUNDLE_ZIP"
echo "  Transfer command:   scp $BUNDLE_ZIP user@cpu-box:/opt/pipeline/"
echo "  On target machine:  pip install dill pydantic chromadb llama-cpp-python"