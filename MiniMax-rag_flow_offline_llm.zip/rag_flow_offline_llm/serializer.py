"""Single-bundle export / load — the "PyTorch .pt" of the whole pipeline.

The bundle is a directory (optionally zipped for transport) containing:

    pipeline.bundle/
    ├── manifest.json          ← version + component paths
    ├── pipeline.pkl           ← dill-serialised Pipeline (just metadata + paths)
    ├── model.gguf             ← THE single model file (≈ .pth equivalent)
    ├── chroma/                ← persisted vector DB (SQLite + parquet)
    ├── schema.json            ← the output Pydantic schema, as JSON
    ├── system_prompt.txt      ← persona / system template
    └── README.md              ← how to load + run

Why this layout?

    * The GGUF is genuinely self-contained: weights + tokenizer + metadata in
      one file. Loads with `llama-cpp-python` on any platform with one wheel.
    * Chroma persists to SQLite, so the vector DB is also a single-file copy
      (the directory holds a SQLite .sqlite3 + tiny Parquet files).
    * The pickled `Pipeline` is small (paths + config); it doesn't include
      any weights — those are on disk and loaded lazily.
    * `manifest.json` carries versions so consumers can refuse incompatible
      bundles.

The export bundles Chroma **and** GGUF **and** schema into one directory.
You can zip that directory and ship it. Loading just needs `dill`,
`llama-cpp-python`, `pydantic`, and `chromadb` — four packages total.

If the user wants ONE file (literal .pt equivalent), `export_zip()` zips the
directory and returns the path. That's the "single file".
"""

from __future__ import annotations

import json
import logging
import shutil
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import dill as pickle  # `dill` handles lambdas / local classes better than pickle

from pipeline import Pipeline
from schemas import JobConfig

logger = logging.getLogger(__name__)

BUNDLE_VERSION = "1.0"


# --------------------------------------------------------------------------- #
# Manifest schema (the contract between exporter and loader)
# --------------------------------------------------------------------------- #
@dataclass
class BundleManifest:
    version: str
    created_at: str
    backend: str            # 'ollama' or 'llamacpp'
    llm_model: str          # human-readable name (e.g. 'qwen2.5-coder:3b')
    gguf_filename: str | None
    chroma_dir: str
    collection_name: str
    schema_name: str
    system_prompt_path: str
    pipeline_pkl: str
    extras: dict[str, Any]

    def to_json(self) -> str:
        return json.dumps(self.__dict__, indent=2, ensure_ascii=False)

    @classmethod
    def from_json(cls, s: str) -> "BundleManifest":
        return cls(**json.loads(s))


# --------------------------------------------------------------------------- #
# Export
# --------------------------------------------------------------------------- #
def export_bundle(
    pipeline: Pipeline,
    *,
    out_dir: Path,
    gguf_path: Path | None = None,
    include_gguf: bool = True,
) -> Path:
    """Write the bundle to `out_dir` and return that path.

    If `include_gguf` is False, the bundle references `gguf_path` by absolute
    path instead of copying it — useful when the GGUF is already shared via
    a model registry.
    """

    out_dir = Path(out_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    # 1. Copy GGUF (or just record the path).
    bundled_gguf_name = None
    if include_gguf:
        if gguf_path is None:
            raise ValueError("include_gguf=True needs gguf_path")
        gguf_src = Path(gguf_path).resolve()
        if not gguf_src.exists():
            raise FileNotFoundError(gguf_src)
        bundled_gguf_name = "model.gguf"
        shutil.copy2(gguf_src, out_dir / bundled_gguf_name)
        logger.info("Copied GGUF %s → %s", gguf_src, out_dir / bundled_gguf_name)
    else:
        bundled_gguf_name = gguf_path.name if gguf_path else None

    # 2. The Pipeline object's `gguf_path` field should now point at the
    #    bundled copy (or the user-supplied path).
    if include_gguf:
        pipeline.gguf_path = str(out_dir / "model.gguf")

    # 3. Copy Chroma (it already exists on disk in `pipeline.chroma_dir`).
    chroma_src = Path(pipeline.chroma_dir).resolve()
    if not chroma_src.exists():
        raise FileNotFoundError(f"Chroma DB not found: {chroma_src}")
    chroma_dst = out_dir / "chroma"
    if chroma_dst.exists():
        shutil.rmtree(chroma_dst)
    shutil.copytree(chroma_src, chroma_dst)
    # Update the pipeline object's reference to the in-bundle copy.
    pipeline.chroma_dir = str(chroma_dst)
    pipeline.collection_name = pipeline.collection_name  # unchanged

    # 4. Dump the schema as JSON (so external validators can read it without
    #    importing this package).
    schema_path = out_dir / "schema.json"
    schema_path.write_text(
        json.dumps(pipeline.output_schema.model_json_schema(), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    # 5. Dump the system prompt.
    system_prompt_path = out_dir / "system_prompt.txt"
    system_prompt_path.write_text(pipeline.system_template, encoding="utf-8")

    # 6. Pickle the (now path-rebound) pipeline object.
    pipeline_pkl = out_dir / "pipeline.pkl"
    with open(pipeline_pkl, "wb") as f:
        pickle.dump(pipeline.to_dict(), f)

    # 7. Write the manifest.
    manifest = BundleManifest(
        version=BUNDLE_VERSION,
        created_at=datetime.now(timezone.utc).isoformat(),
        backend=pipeline.backend,
        llm_model=pipeline.llm_model,
        gguf_filename=bundled_gguf_name,
        chroma_dir="chroma",
        collection_name=pipeline.collection_name,
        schema_name=pipeline.output_schema.__name__,
        system_prompt_path="system_prompt.txt",
        pipeline_pkl="pipeline.pkl",
        extras=pipeline.extras or {},
    )
    (out_dir / "manifest.json").write_text(manifest.to_json(), encoding="utf-8")

    # 8. Drop a tiny README so the bundle is self-explanatory.
    _write_readme(out_dir)

    logger.info("Exported bundle to %s", out_dir)
    return out_dir


def export_zip(pipeline: Pipeline, *, out_zip: Path, gguf_path: Path | None = None) -> Path:
    """Convenience: export + zip. The result IS the single .pt-equivalent file."""
    out_zip = Path(out_zip).resolve()
    tmp_dir = out_zip.parent / (out_zip.stem + ".tmp_bundle")
    try:
        export_bundle(pipeline, out_dir=tmp_dir, gguf_path=gguf_path, include_gguf=True)
        if out_zip.exists():
            out_zip.unlink()
        with zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
            for p in tmp_dir.rglob("*"):
                if p.is_file():
                    zf.write(p, p.relative_to(tmp_dir))
    finally:
        if tmp_dir.exists():
            shutil.rmtree(tmp_dir)
    logger.info("Wrote zipped bundle to %s", out_zip)
    return out_zip


# --------------------------------------------------------------------------- #
# Load
# --------------------------------------------------------------------------- #
def load_bundle(bundle_dir: Path | str) -> Pipeline:
    """Load a Pipeline from a bundle directory.

    On a fresh machine, you only need: `pip install dill pydantic chromadb llama-cpp-python`.
    That's the entire install footprint.
    """
    bundle_dir = Path(bundle_dir).resolve()
    manifest_path = bundle_dir / "manifest.json"
    if not manifest_path.exists():
        # Maybe the user pointed at a .zip
        if bundle_dir.suffix == ".zip":
            return _load_zip(bundle_dir)
        raise FileNotFoundError(manifest_path)

    manifest = BundleManifest.from_json(manifest_path.read_text(encoding="utf-8"))
    if manifest.version != BUNDLE_VERSION:
        raise ValueError(
            f"Bundle version mismatch: got {manifest.version!r}, "
            f"expected {BUNDLE_VERSION!r}. Refusing to load — please re-export."
        )

    with open(bundle_dir / manifest.pipeline_pkl, "rb") as f:
        d = pickle.load(f)

    # If the GGUF was bundled, point the pipeline at the in-bundle copy.
    if manifest.gguf_filename:
        d["gguf_path"] = str(bundle_dir / manifest.gguf_filename)
    # Same for chroma.
    d["chroma_dir"] = str(bundle_dir / manifest.chroma_dir)

    return Pipeline.from_dict(d)


def _load_zip(zip_path: Path) -> Pipeline:
    """Extract a .zip bundle to a temp dir and load it."""
    import tempfile

    with tempfile.TemporaryDirectory(prefix="rag_flow_offline_llm_bundle_") as tmp:
        with zipfile.ZipFile(zip_path) as zf:
            zf.extractall(tmp)
        return load_bundle(Path(tmp))


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def _write_readme(bundle_dir: Path) -> None:
    readme = f"""\
# Offline RAG Pipeline Bundle

Generated: {datetime.now(timezone.utc).isoformat()}
Bundle version: {BUNDLE_VERSION}

## Layout
- `manifest.json`     — version + component pointers
- `pipeline.pkl`      — pickled Pipeline metadata
- `model.gguf`        — the LLM weights (loadable by llama-cpp-python)
- `chroma/`           — persisted vector DB
- `schema.json`       — output JSON schema
- `system_prompt.txt` — persona template

## Loading

```python
from rag_flow_offline_llm.serializer import load_bundle
pipeline = load_bundle("path/to/this/directory")

cfg = pipeline.generate_config(
    event={{...}},            # source-event dict
    mapping_doc={{...}},      # mapping row dict
    target_schema={{...}},    # optional
)
print(cfg.to_json_config())
```

## Install footprint (only these four packages)

```
pip install dill pydantic chromadb llama-cpp-python
```

If using a GPU: install the CUDA build of `llama-cpp-python`.
Otherwise: install the CPU build — same code, slower first token.
"""
    (bundle_dir / "README.md").write_text(readme, encoding="utf-8")