"""Offline RAG Pipeline package.

The public surface is intentionally small:
    from offline_rag.pipeline import Pipeline
    from offline_rag.spark_udf import make_generate_udf
    from offline_rag.serializer import export_bundle, load_bundle

Imports are lazy so the package can be imported (e.g. for reading schema
metadata or dill-loaded bundles) even if LangChain isn't installed in the
target environment.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

# Schemas have no LangChain dependency — expose them eagerly.
from .schemas import ColumnMapping, JobConfig, SourceEvent, SparkClusterConfig

__all__ = [
    "Pipeline",
    "JobConfig",
    "SparkClusterConfig",
    "ColumnMapping",
    "SourceEvent",
]


if TYPE_CHECKING:
    # Type checkers get the full surface; runtime stays lazy.
    from pipeline import Pipeline as _Pipeline

    Pipeline = _Pipeline  # noqa: F811
else:
    def __getattr__(name: str):
        # PEP 562 — only resolve `Pipeline` on demand, and only if requested.
        if name == "Pipeline":
            from pipeline import Pipeline
            return Pipeline
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")