"""Top-level CLI for the offline RAG pipeline.

Subcommands:
    build       — ingest data/ → artifacts/chroma
    generate    — generate a JobConfig from one row (event, mapping)
    bundle      — export the pipeline as a single .bundle directory (or .zip)
    smoke       — quick health check: load KB, run one generation, validate
    sample      — write a sample data tree you can edit
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path

from config import (
    DATA_DIR,
    DATA_MAPPINGS,
    DATA_PROMPTS,
    DATA_SCHEMAS,
    DATA_JSON_CONFIGS,
    LLM_CFG,
    PATHS,
    RETR_CFG,
    ensure_dirs,
)
from generator import make_generator
from kb_builder import build_chroma_kb, load_kb_documents
from pipeline import Pipeline
from retriever import Retriever
from serializer import export_bundle, export_zip
from schemas import JobConfig


logger = logging.getLogger("rag_flow_offline_llm")


# --------------------------------------------------------------------------- #
# Subcommands
# --------------------------------------------------------------------------- #
def cmd_build(args: argparse.Namespace) -> None:
    """Ingest `data/` → `artifacts/chroma/`."""
    ensure_dirs()
    docs = load_kb_documents(DATA_DIR)
    if not docs:
        logger.error("No documents found under %s. Run `python main.py sample` first.", DATA_DIR)
        sys.exit(1)

    build_chroma_kb(
        docs,
        persist_dir=PATHS.chroma_dir,
        collection_name=RETR_CFG.collection_name,
        embedding_model=args.embed_model,
        backend=args.embedding_backend,
        chunk_size=RETR_CFG.chunk_size,
        chunk_overlap=RETR_CFG.chunk_overlap,
    )
    logger.info("KB built at %s", PATHS.chroma_dir)


def cmd_generate(args: argparse.Namespace) -> None:
    """Generate one JobConfig from a (mapping, event) row."""
    pipeline = _build_pipeline_for_dev()
    event = json.loads(Path(args.event).read_text(encoding="utf-8"))
    mapping = json.loads(Path(args.mapping).read_text(encoding="utf-8"))
    schema = (
        json.loads(Path(args.schema).read_text(encoding="utf-8")) if args.schema else None
    )

    cfg = pipeline.generate_config(
        event=event, mapping_doc=mapping, target_schema=schema
    )
    out = Path(args.out)
    out.write_text(cfg.to_json_config(), encoding="utf-8")
    logger.info("Wrote %s", out)


def cmd_bundle(args: argparse.Namespace) -> None:
    """Export the current pipeline as a portable bundle."""
    pipeline = _build_pipeline_for_dev()

    if args.gguf:
        gguf_path = Path(args.gguf)
    else:
        # Try to find a GGUF in models/. If absent, fall back to the Ollama
        # blob location — Ollama stores its blobs under ~/.ollama/models.
        candidates = list(PATHS.models_dir.rglob("*.gguf"))
        if candidates:
            gguf_path = candidates[0]
        else:
            gguf_path = _find_ollama_blob(pipeline.llm_model)
        if gguf_path is None:
            logger.error(
                "No GGUF found. Pass --gguf /path/to/model.gguf or place one under %s.",
                PATHS.models_dir,
            )
            sys.exit(1)
    logger.info("Using GGUF: %s", gguf_path)

    out_dir = Path(args.out_dir)
    if args.zip:
        zip_path = out_dir.with_suffix(".zip")
        export_zip(pipeline, out_zip=zip_path, gguf_path=gguf_path)
        logger.info("Single-file bundle: %s", zip_path)
    else:
        export_bundle(pipeline, out_dir=out_dir, gguf_path=gguf_path)
        logger.info("Bundle directory: %s", out_dir)


def cmd_smoke(args: argparse.Namespace) -> None:
    """Run a minimal end-to-end check, suitable for CI / first run."""
    ensure_dirs()
    if not PATHS.chroma_dir.exists() or not any(PATHS.chroma_dir.iterdir()):
        logger.info("No KB found — building from sample data…")
        cmd_build(argparse.Namespace(embed_model=LLM_CFG.ollama_embed_model,
                                     embedding_backend="ollama"))

    pipeline = _build_pipeline_for_dev()
    # Use a tiny in-line event/mapping so smoke-test has no external deps.
    event = {"event_id": "smoke-1", "event_type": "kafka_message",
             "source_system": "orders_db", "payload_schema": "orders_v1"}
    mapping = {"target_table": "orders_clean", "target_column": "order_id",
               "source_expression": "payload.order_id", "data_type": "BIGINT"}
    try:
        cfg = pipeline.generate_config(event=event, mapping_doc=mapping)
        assert isinstance(cfg, JobConfig)
        logger.info("Smoke test OK — JobConfig validated:\n%s", cfg.to_json_config())
    except Exception as e:  # noqa: BLE001
        logger.error("Smoke test FAILED: %s", e)
        sys.exit(2)


def cmd_sample(args: argparse.Namespace) -> None:
    """Drop a few example data files under data/ so the user can iterate."""
    ensure_dirs()

    DATA_JSON_CONFIGS.mkdir(parents=True, exist_ok=True)
    (DATA_JSON_CONFIGS / "orders_event.json").write_text(json.dumps({
        "event_id": "orders_kafka_v1",
        "event_type": "kafka_message",
        "source_system": "orders_db",
        "payload_schema": "orders_v1",
        "sample": {"order_id": 12345, "customer_id": "C001",
                   "amount": 99.5, "currency": "USD", "ts": "2025-06-12T10:00:00Z"},
    }, indent=2), encoding="utf-8")

    DATA_MAPPINGS.mkdir(parents=True, exist_ok=True)
    # We write a CSV (not XLSX) to avoid the openpyxl dep for the sample.
    (DATA_MAPPINGS / "orders_mapping.csv").write_text(
        "target_table,target_column,source_expression,data_type,description\n"
        "orders_clean,order_id,payload.order_id,BIGINT,Primary key\n"
        "orders_clean,customer_id,payload.customer_id,STRING,FK to customers\n"
        "orders_clean,amount,payload.amount,DECIMAL(18,4),Order total\n"
        "orders_clean,currency,payload.currency,STRING,ISO 4217 code\n"
        "orders_clean,order_ts,payload.ts,TIMESTAMP,Event time\n",
        encoding="utf-8",
    )

    DATA_SCHEMAS.mkdir(parents=True, exist_ok=True)
    (DATA_SCHEMAS / "orders_clean_schema.csv").write_text(
        "table_name,column_name,data_type,is_nullable,description\n"
        "orders_clean,order_id,BIGINT,NO,Primary key\n"
        "orders_clean,customer_id,STRING,YES,FK to customers\n"
        "orders_clean,amount,DECIMAL(18,4),YES,Order total\n"
        "orders_clean,currency,STRING,YES,ISO 4217 code\n"
        "orders_clean,order_ts,TIMESTAMP,YES,Event time\n",
        encoding="utf-8",
    )

    DATA_PROMPTS.mkdir(parents=True, exist_ok=True)
    (DATA_PROMPTS / "format_spec.md").write_text(
        "# Job-Config Output Format\n\n"
        "The pipeline must emit a `JobConfig` JSON object with:\n\n"
        "- `job_name`: short identifier used as the filename.\n"
        "- `source_event`: the source-event row this job is for.\n"
        "- `target`: a single `ColumnMapping` row.\n"
        "- `spark`: optional `SparkClusterConfig` (omit to use defaults).\n"
        "- `sql`: full Spark SQL the job executes; must reference `target_table`.\n\n"
        "Use lowercase_snake_case for identifiers. Use BIGINT/STRING/DECIMAL/TIMESTAMP types.\n",
        encoding="utf-8",
    )
    logger.info("Wrote sample data under %s", DATA_DIR)


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def _build_pipeline_for_dev() -> Pipeline:
    """Build a Pipeline pointed at the local Chroma + Ollama backend."""
    if LLM_CFG.backend != "ollama":
        raise RuntimeError(
            "This script's dev workflow uses Ollama. Set OFFLINE_RAG_BACKEND=ollama "
            "(the default) or use load_bundle() instead."
        )

    from langchain_ollama import OllamaEmbeddings  # type: ignore

    embed = OllamaEmbeddings(model=LLM_CFG.ollama_embed_model)
    retriever = Retriever.load(
        str(PATHS.chroma_dir),
        collection_name=RETR_CFG.collection_name,
        embedding=embed,
    )
    llm = make_generator(LLM_CFG)
    return Pipeline(
        llm=llm,
        retriever=retriever,
        chroma_dir=str(PATHS.chroma_dir),
        collection_name=RETR_CFG.collection_name,
        backend=LLM_CFG.backend,
        llm_model=LLM_CFG.ollama_model,
    )


def _find_ollama_blob(model_name: str) -> Path | None:
    """Locate the local GGUF blob Ollama downloaded for `model_name`."""
    blob_root = Path(os.path.expanduser("~")) / ".ollama" / "models"
    if not blob_root.exists():
        return None
    # Ollama stores blobs in blobs/ and a manifest under models/manifests/.
    # Easier: query `ollama show <model> --modelfile` is fragile; instead, we
    # match by symlink. Most setups keep blobs under
    # ~/.ollama/models/blobs/sha256-*
    blobs = list((blob_root / "blobs").glob("*")) if (blob_root / "blobs").exists() else []
    if not blobs:
        return None
    return max(blobs, key=lambda p: p.stat().st_size)


# --------------------------------------------------------------------------- #
# CLI entry
# --------------------------------------------------------------------------- #
def _main() -> None:
    ap = argparse.ArgumentParser(prog="rag_flow_offline_llm", description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)

    p_build = sub.add_parser("build", help="Ingest data/ into the KB vector store")
    p_build.add_argument("--embed-model", default=LLM_CFG.ollama_embed_model)
    p_build.add_argument("--embedding-backend", default="ollama",
                         choices=["ollama", "hf"])
    p_build.set_defaults(func=cmd_build)

    p_gen = sub.add_parser("generate", help="Generate one JobConfig from JSON files")
    p_gen.add_argument("--event", required=True, type=Path)
    p_gen.add_argument("--mapping", required=True, type=Path)
    p_gen.add_argument("--schema", type=Path)
    p_gen.add_argument("--out", required=True, type=Path)
    p_gen.set_defaults(func=cmd_generate)

    p_bun = sub.add_parser("bundle", help="Export the pipeline as a portable bundle")
    p_bun.add_argument("--gguf", type=Path, help="Path to the GGUF to embed in the bundle")
    p_bun.add_argument("--out-dir", type=Path, default=PATHS.bundles_dir / "pipeline.bundle")
    p_bun.add_argument("--zip", action="store_true", help="Zip the bundle into a single .zip")
    p_bun.set_defaults(func=cmd_bundle)

    p_smoke = sub.add_parser("smoke", help="Run a one-shot end-to-end smoke test")
    p_smoke.set_defaults(func=cmd_smoke)

    p_sample = sub.add_parser("sample", help="Write sample data files under data/")
    p_sample.set_defaults(func=cmd_sample)

    args = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    args.func(args)


if __name__ == "__main__":
    _main()