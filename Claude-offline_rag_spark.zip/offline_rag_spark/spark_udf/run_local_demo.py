"""
Local smoke-test / demo driver for spark_udf.py.

This MUST be a separate file from spark_udf.py itself. See the note at the
bottom of spark_udf.py for why: running spark_udf.py directly makes it
`__main__`, and cloudpickle then serializes the whole module by value
(including the unpicklable threading.Lock) instead of just referencing it
by import path.

Usage:
    python run_local_demo.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "rag"))

from pyspark.sql import SparkSession  # noqa: E402

import config_generator  # noqa: E402  (proper module import -- this is the fix)
from schemas import SparkJobConfig  # noqa: E402


def main():
    spark = SparkSession.builder.appName("spark-udf-demo").master("local[2]").getOrCreate()
    # Ship the local modules to worker subprocesses -- sys.path changes in
    # this driver process alone are not visible to them. On a real cluster,
    # spark-submit's --py-files flag does the same job.
    here = Path(__file__).resolve().parent
    spark.sparkContext.addPyFile(str(here / "config_generator.py"))
    spark.sparkContext.addPyFile(str(here.parent / "rag" / "schemas.py"))

    data = [(f"mapping_{i}", f"schema_{i}") for i in range(4)]
    df = spark.createDataFrame(data, ["mapping_json", "schema_json"]).repartition(4)

    generate_udf = config_generator.make_udf(model_path="MOCK", use_mock=True)
    result = df.withColumn("job_config_json", generate_udf(df.mapping_json, df.schema_json))

    rows = result.collect()
    for row in rows:
        parsed = SparkJobConfig.model_validate_json(row["job_config_json"])
        print(f"{row['mapping_json']:12s} -> {parsed.job_name:20s} sql={parsed.sql}")

    spark.stop()
    return rows


if __name__ == "__main__":
    main()
