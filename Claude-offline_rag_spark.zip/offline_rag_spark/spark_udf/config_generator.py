"""
Run the (optionally fine-tuned) offline model as a Spark UDF.

Architecture decision, spelled out: we do NOT have executors call an Ollama
HTTP server. That would mean every executor node needs its own running
Ollama daemon -- a service dependency baked into your cluster, fragile to
restarts/scaling. Instead:

  - Only the *model file path* (a string) is broadcast to executors --
    that's cheap and trivially serializable.
  - Each executor process lazily loads its own GGUF handle on first use via
    llama-cpp-python, directly in-process. No network call per row.
  - A per-process singleton (ModelRunner.get_instance) ensures the model is
    loaded once per executor, not once per row.

Install on Spark nodes: pip install llama-cpp-python pyspark
(For CUDA-accelerated executors: CMAKE_ARGS="-DGGML_CUDA=on" pip install
llama-cpp-python --no-binary llama-cpp-python)

Usage in a Spark job:
    from config_generator import make_udf
    generate_udf = make_udf(model_path="/mnt/models/model-q4_k_m.gguf")
    df.withColumn("job_config_json", generate_udf(df.mapping_json, df.schema_json))
    # then: df.withColumn("job_config", from_json("job_config_json", spark_job_config_schema))
"""
from __future__ import annotations

import hashlib
import json
import os
import threading
from typing import Optional

import pandas as pd
from pyspark.sql.functions import pandas_udf
from pyspark.sql.types import StringType

try:
    from schemas import SparkJobConfig  # when run from repo root with rag/ on path
except ImportError:
    import sys
    from pathlib import Path

    sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "rag"))
    from schemas import SparkJobConfig  # type: ignore

_lock = threading.Lock()
_instance: Optional["ModelRunner"] = None

PROMPT_TEMPLATE = """Generate a Spark job config as JSON matching the required schema.

# Mapping info
{mapping_json}

# Schema info
{schema_json}
"""


class ModelRunner:
    """One instance per executor process (lazy singleton). use_mock=True
    skips loading real weights entirely -- useful for testing the Spark
    plumbing (broadcast, per-process init, schema conformance) without
    needing GPU/weights on every node."""

    def __init__(self, model_path: str, use_mock: bool = False, n_ctx: int = 8192, n_gpu_layers: int = 0):
        self.model_path = model_path
        self.use_mock = use_mock
        self.pid = os.getpid()
        if not use_mock:
            from llama_cpp import Llama

            self._llm = Llama(
                model_path=model_path, n_ctx=n_ctx, n_gpu_layers=n_gpu_layers, verbose=False
            )
        else:
            self._llm = None

    @classmethod
    def get_instance(cls, model_path: str, use_mock: bool = False) -> "ModelRunner":
        global _instance
        with _lock:
            if _instance is None:
                _instance = cls(model_path=model_path, use_mock=use_mock)
            return _instance

    def generate_config(self, mapping_json: str, schema_json: str) -> str:
        if self.use_mock:
            return self._mock_generate(mapping_json, schema_json)

        prompt = PROMPT_TEMPLATE.format(mapping_json=mapping_json, schema_json=schema_json)
        schema = SparkJobConfig.model_json_schema()
        result = self._llm.create_chat_completion(
            messages=[{"role": "user", "content": prompt}],
            response_format={"type": "json_object", "schema": schema},
            temperature=0,
        )
        return result["choices"][0]["message"]["content"]

    def _mock_generate(self, mapping_json: str, schema_json: str) -> str:
        """Deterministic stand-in matching SparkJobConfig exactly. Same input
        always -> same output, so tests can assert on it precisely."""
        h = hashlib.sha256((mapping_json + schema_json).encode()).hexdigest()[:10]
        cfg = SparkJobConfig(
            job_name=f"job_{h}",
            description="Mock-generated config for pipeline testing",
            source_mapping_ref=h,
            cluster={
                "num_executors": 2,
                "executor_cores": 2,
                "executor_memory": "4g",
                "driver_memory": "2g",
                "spark_conf": {},
            },
            sql=[f"SELECT * FROM source_{h}"],
            pipeline_steps=[
                {"step_id": "1", "step_type": "read", "description": "read source", "depends_on": []}
            ],
            output_format="parquet",
        )
        return cfg.model_dump_json()


def make_udf(model_path: str, use_mock: bool = False):
    """Returns a pandas_udf you can apply directly to two string columns."""

    @pandas_udf(StringType())
    def generate_config_udf(mapping_col: pd.Series, schema_col: pd.Series) -> pd.Series:
        runner = ModelRunner.get_instance(model_path=model_path, use_mock=use_mock)
        return pd.Series(
            [runner.generate_config(m, s) for m, s in zip(mapping_col, schema_col)]
        )

    return generate_config_udf


# NOTE 1: deliberately no `if __name__ == "__main__":` demo in this file.
# Spark UDFs are cloudpickle closures -- if this module is ever executed
# directly (`python config_generator.py`), Python treats it as `__main__`,
# and cloudpickle then has to serialize the ENTIRE module by value,
# including module-level state like `_lock` (a threading.Lock, which is not
# picklable) -- this fails with "cannot pickle '_thread.lock' object".
# When the module is properly imported instead (`import config_generator`),
# each worker process just does a fresh `import config_generator` and
# reconstructs its own `_lock`/`_instance` locally -- nothing needs to be
# pickled at all. Always drive this from a separate script (run_local_demo.py).
#
# NOTE 2: this file is also deliberately NOT named the same as its
# containing folder (spark_udf/). A file spark_udf/spark_udf.py creates a
# namespace-package name collision: `import spark_udf` can resolve to the
# *folder* instead of the .py file inside it, which is invisible in the
# driver process (which already has the real module cached in sys.modules)
# but breaks fresh worker processes with
# "AttributeError: Can't get attribute 'X' on <module ... (namespace)>".
# Keep module filenames distinct from their parent folder name.

