"""
Serialization / deserialization tests for every artifact in this pipeline:

  1. FAISS vector store  -- save_local() -> fresh process-equivalent reload
                             -> same retrieval result
  2. SparkJobConfig       -- Pydantic model -> JSON string/file -> reparsed
                             back into an identical model
  3. Spark UDF pipeline   -- the model reference broadcasts across the
                             driver -> executor process boundary correctly,
                             and each executor lazily (de)serializes its own
                             model handle exactly once
  4. Live Ollama / llama.cpp integration -- SKIPPED unless you actually have
     Ollama running locally or a real GGUF file, since those aren't
     available in most CI / sandboxed environments. This is intentional --
     a test that silently mocks a live LLM and calls itself "passing" is
     worse than no test.

Run:
    pytest tests/test_serde.py -v
    RUN_OLLAMA_TESTS=1 OLLAMA_MODEL=qwen3:4b pytest tests/test_serde.py -v
    RUN_LLAMACPP_TESTS=1 GGUF_MODEL_PATH=/path/to/model.gguf pytest tests/test_serde.py -v
"""
import json
import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "rag"))
sys.path.insert(0, str(ROOT / "ingest"))
sys.path.insert(0, str(ROOT / "spark_udf"))

from schemas import ClusterConfig, PipelineStep, SparkJobConfig  # noqa: E402


# ---------------------------------------------------------------------------
# 1. FAISS index serialization round-trip
# ---------------------------------------------------------------------------

def test_faiss_index_roundtrip(tmp_path):
    from langchain_community.vectorstores import FAISS
    from langchain_core.documents import Document
    from langchain_core.embeddings import DeterministicFakeEmbedding

    # DeterministicFakeEmbedding needs no network/model download -- it's a
    # hash-based embedding that always returns the same vector for the same
    # text, which is exactly what we need to test the plumbing in isolation
    # from any particular embedding model choice.
    embeddings = DeterministicFakeEmbedding(size=384)

    docs = [
        Document(page_content="customer_orders table maps order_id to source ORD_ID", metadata={"table": "customer_orders"}),
        Document(page_content="payments table maps payment_id to source PMT_ID", metadata={"table": "payments"}),
        Document(page_content="shipments table maps shipment_id to source SHP_ID", metadata={"table": "shipments"}),
    ]

    store = FAISS.from_documents(docs, embeddings)
    index_dir = tmp_path / "faiss_index"
    store.save_local(str(index_dir))

    assert (index_dir / "index.faiss").exists()
    assert (index_dir / "index.pkl").exists()

    # Fresh object, fresh embeddings instance -- simulates a completely
    # separate process loading only the two files off disk.
    reloaded = FAISS.load_local(
        str(index_dir), DeterministicFakeEmbedding(size=384), allow_dangerous_deserialization=True
    )

    query = "customer_orders table maps order_id to source ORD_ID"
    results = reloaded.similarity_search(query, k=1)

    assert len(results) == 1
    assert results[0].metadata["table"] == "customer_orders"
    assert results[0].page_content == docs[0].page_content


# ---------------------------------------------------------------------------
# 2. Pydantic schema (the JSON contract) round-trip
# ---------------------------------------------------------------------------

def test_spark_job_config_json_roundtrip(tmp_path):
    original = SparkJobConfig(
        job_name="load_customer_orders",
        description="Loads and conforms customer_orders from staging",
        source_mapping_ref="mapping_v3.xlsx#customer_orders",
        cluster=ClusterConfig(
            num_executors=4,
            executor_cores=4,
            executor_memory="8g",
            driver_memory="4g",
            spark_conf={"spark.sql.shuffle.partitions": "200"},
        ),
        sql=["SELECT order_id AS ORD_ID, customer_id FROM raw.customer_orders"],
        pipeline_steps=[
            PipelineStep(step_id="1", step_type="read", description="read raw table"),
            PipelineStep(step_id="2", step_type="write", description="write conformed table", depends_on=["1"]),
        ],
        output_format="delta",
    )

    # In-memory round trip
    as_json = original.model_dump_json()
    reparsed = SparkJobConfig.model_validate_json(as_json)
    assert reparsed == original

    # File round trip (this is the artifact a real pipeline would produce)
    out_file = tmp_path / "job_config.json"
    out_file.write_text(original.model_dump_json(indent=2))
    from_file = SparkJobConfig.model_validate_json(out_file.read_text())
    assert from_file == original

    # Schema itself must be a stable, valid JSON schema -- this is what gets
    # handed to Ollama's `format` field / llama.cpp's response_format
    schema = SparkJobConfig.model_json_schema()
    assert schema["title"] == "SparkJobConfig"
    assert "job_name" in schema["properties"]


# ---------------------------------------------------------------------------
# 3. Spark UDF: model reference broadcast + per-executor lazy (de)serialization
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def spark_session():
    from pyspark.sql import SparkSession

    spark = (
        SparkSession.builder.appName("test-spark-udf-serde")
        .master("local[2]")
        .config("spark.ui.showConsoleProgress", "false")
        .getOrCreate()
    )
    # This is the real fix, not a workaround: sys.path.insert() in this
    # (driver) process has no effect on the separate Python worker
    # subprocesses Spark spawns -- they get their own interpreter with their
    # own sys.path. addPyFile() is the actual mechanism for shipping local
    # modules to every worker, in local mode and on a real cluster alike.
    spark.sparkContext.addPyFile(str(ROOT / "spark_udf" / "config_generator.py"))
    spark.sparkContext.addPyFile(str(ROOT / "rag" / "schemas.py"))
    yield spark
    spark.stop()


def test_spark_udf_broadcast_and_schema_conformance(spark_session):
    # Deliberately `import config_generator` (a real module, filename
    # distinct from its parent folder name) rather than exec'ing it as a
    # script -- this is the fix for two real failures hit while building
    # this: (1) cloudpickle "cannot pickle '_thread.lock'" when the module
    # runs as __main__, and (2) a namespace-package collision when the
    # module file shared its name with its containing folder. If either
    # regresses, this test fails loudly instead of silently.
    import config_generator

    data = [(f"mapping_{i}", f"schema_{i}") for i in range(6)]
    df = spark_session.createDataFrame(data, ["mapping_json", "schema_json"]).repartition(3)

    generate_udf = config_generator.make_udf(model_path="MOCK", use_mock=True)
    result_df = df.withColumn("job_config_json", generate_udf(df.mapping_json, df.schema_json))

    rows = result_df.collect()
    assert len(rows) == 6

    seen_job_names = set()
    for row in rows:
        # Deserialization check: every row must parse into a valid,
        # schema-conformant SparkJobConfig -- proves the JSON contract
        # survived the driver -> executor -> driver round trip intact.
        parsed = SparkJobConfig.model_validate_json(row["job_config_json"])
        assert parsed.job_name.startswith("job_")
        assert parsed.output_format == "parquet"
        seen_job_names.add(parsed.job_name)

    # Determinism check: same input must always produce the same output
    # (this matters for the real model too once schema-constrained -- it's
    # what makes the pipeline testable at all).
    assert len(seen_job_names) == 6  # 6 distinct inputs -> 6 distinct outputs

    rerun = result_df.collect()
    rerun_names = {SparkJobConfig.model_validate_json(r["job_config_json"]).job_name for r in rerun}
    assert rerun_names == seen_job_names


# ---------------------------------------------------------------------------
# 4. Optional live integration tests -- skipped unless explicitly enabled
# ---------------------------------------------------------------------------

@pytest.mark.skipif(
    os.environ.get("RUN_OLLAMA_TESTS") != "1", reason="set RUN_OLLAMA_TESTS=1 with Ollama running locally"
)
def test_ollama_structured_output_live():
    from langchain_ollama import ChatOllama

    model = os.environ.get("OLLAMA_MODEL", "qwen3:4b")
    llm = ChatOllama(model=model, temperature=0)
    structured_llm = llm.with_structured_output(SparkJobConfig)

    result = structured_llm.invoke(
        "Generate a minimal Spark job config named 'smoke_test' that reads "
        "from table raw.events and writes to parquet."
    )
    assert isinstance(result, SparkJobConfig)
    assert result.job_name


@pytest.mark.skipif(
    os.environ.get("RUN_LLAMACPP_TESTS") != "1", reason="set RUN_LLAMACPP_TESTS=1 and GGUF_MODEL_PATH"
)
def test_spark_udf_real_gguf_inference(spark_session):
    import config_generator

    model_path = os.environ["GGUF_MODEL_PATH"]
    generate_udf = config_generator.make_udf(model_path=model_path, use_mock=False)

    df = spark_session.createDataFrame(
        [("customer_orders mapping: order_id->ORD_ID", "table: customer_orders, cols: order_id, customer_id")],
        ["mapping_json", "schema_json"],
    )
    result = df.withColumn("job_config_json", generate_udf(df.mapping_json, df.schema_json)).collect()
    parsed = SparkJobConfig.model_validate_json(result[0]["job_config_json"])
    assert parsed.job_name
