"""
QLoRA fine-tune of a small instruct model on (mapping/schema context -> Spark
JSON config) examples.

IMPORTANT: run this on a cloud GPU (Colab T4/A100, or any 16GB+ box), NOT on
the RTX 3050. At 4GB VRAM, QLoRA on a 4B model is achievable only with very
short sequences and batch size 1 -- and you have essentially no room for
mapping/schema context in the training examples, which defeats the point.
Train where you have headroom, then bring only the merged/quantized result
back for local inference.

Install (on the training machine only):
    pip install transformers peft bitsandbytes trl accelerate datasets

Dataset format (--dataset, JSONL, one example per line):
    {"context": "<retrieved mapping/schema docs>", "query": "<the ask>",
     "response": "<the target SparkJobConfig as JSON text>"}

Usage:
    python finetune_qlora.py --base-model Qwen/Qwen3-4B-Instruct \\
        --dataset ./training_examples.jsonl --output-dir ./lora-out
"""
from __future__ import annotations

import argparse

from datasets import load_dataset
from peft import LoraConfig
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
from trl import SFTConfig, SFTTrainer

PROMPT_TEMPLATE = """# Context
{context}

# Request
{query}

# Response
{response}"""


def format_example(example: dict) -> dict:
    return {
        "text": PROMPT_TEMPLATE.format(
            context=example["context"], query=example["query"], response=example["response"]
        )
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-model", default="Qwen/Qwen3-4B-Instruct")
    ap.add_argument("--dataset", required=True)
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--lr", type=float, default=2e-4)
    ap.add_argument("--max-seq-len", type=int, default=4096)
    args = ap.parse_args()

    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype="bfloat16",
        bnb_4bit_use_double_quant=True,
    )

    tokenizer = AutoTokenizer.from_pretrained(args.base_model)
    model = AutoModelForCausalLM.from_pretrained(
        args.base_model, quantization_config=bnb_config, device_map="auto"
    )

    lora_config = LoraConfig(
        r=16,
        lora_alpha=32,
        lora_dropout=0.05,
        bias="none",
        task_type="CAUSAL_LM",
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    )

    dataset = load_dataset("json", data_files=args.dataset, split="train")
    dataset = dataset.map(format_example)

    sft_config = SFTConfig(
        output_dir=args.output_dir,
        num_train_epochs=args.epochs,
        per_device_train_batch_size=2,
        gradient_accumulation_steps=8,
        learning_rate=args.lr,
        max_seq_length=args.max_seq_len,
        logging_steps=10,
        save_strategy="epoch",
        bf16=True,
        report_to="none",
    )

    trainer = SFTTrainer(
        model=model,
        args=sft_config,
        train_dataset=dataset,
        peft_config=lora_config,
        tokenizer=tokenizer,
    )
    trainer.train()
    trainer.save_model(args.output_dir)
    print(f"LoRA adapter saved -> {args.output_dir}")
    print("Next: bash export_gguf.sh <output-dir> <merged-gguf-dir>")


if __name__ == "__main__":
    main()
