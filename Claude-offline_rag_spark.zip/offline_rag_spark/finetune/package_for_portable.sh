#!/usr/bin/env bash
# Bundle everything a CPU-only machine needs into one portable folder.
# Run this on the GPU box, AFTER export_gguf.sh has produced the GGUF file.
# Nothing in this script touches the GPU -- it's pure file copying + hashing.
#
# Usage:
#   bash package_for_portable.sh <gguf-dir> <faiss-index-dir> <bundle-out-dir>
#
# Example:
#   bash package_for_portable.sh ./merged-gguf ./faiss_index ./portable_bundle
set -euo pipefail

GGUF_DIR="${1:?usage: package_for_portable.sh <gguf-dir> <faiss-index-dir> <bundle-out-dir>}"
FAISS_DIR="${2:?usage: package_for_portable.sh <gguf-dir> <faiss-index-dir> <bundle-out-dir>}"
BUNDLE_DIR="${3:?usage: package_for_portable.sh <gguf-dir> <faiss-index-dir> <bundle-out-dir>}"

mkdir -p "$BUNDLE_DIR/model" "$BUNDLE_DIR/faiss_index"

echo "[1/4] Copying GGUF model + Modelfile..."
cp "$GGUF_DIR"/*.gguf "$BUNDLE_DIR/model/"
cp "$GGUF_DIR/Modelfile" "$BUNDLE_DIR/model/" 2>/dev/null || true

echo "[2/4] Copying FAISS index (index.faiss + index.pkl)..."
cp "$FAISS_DIR/index.faiss" "$FAISS_DIR/index.pkl" "$BUNDLE_DIR/faiss_index/"

echo "[3/4] Copying code (ingest, rag, spark_udf, schemas)..."
mkdir -p "$BUNDLE_DIR/code"
cp -r "$(dirname "$0")/../ingest" "$(dirname "$0")/../rag" "$(dirname "$0")/../spark_udf" "$BUNDLE_DIR/code/" 2>/dev/null || true
find "$BUNDLE_DIR/code" -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true

echo "[4/4] Writing manifest with checksums..."
MANIFEST="$BUNDLE_DIR/manifest.json"
python3 - "$BUNDLE_DIR" "$MANIFEST" << 'PY'
import hashlib
import json
import sys
from pathlib import Path
from datetime import datetime, timezone

bundle_dir, manifest_path = Path(sys.argv[1]), Path(sys.argv[2])

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    h.update(path.read_bytes())
    return h.hexdigest()

files = []
for f in sorted(bundle_dir.rglob("*")):
    if f.is_file() and f.name != "manifest.json":
        files.append({
            "path": str(f.relative_to(bundle_dir)),
            "size_bytes": f.stat().st_size,
            "sha256": sha256(f),
        })

manifest = {
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "file_count": len(files),
    "total_size_bytes": sum(f["size_bytes"] for f in files),
    "files": files,
}
manifest_path.write_text(json.dumps(manifest, indent=2))
print(f"Manifest written -> {manifest_path} ({len(files)} files, "
      f"{manifest['total_size_bytes'] / 1e6:.1f} MB total)")
PY

echo ""
echo "Bundle ready at: $BUNDLE_DIR"
echo "Copy this whole folder to the CPU-only machine (USB / scp / whatever your"
echo "offline-transfer policy allows), then run verify_cpu_only.py there to confirm"
echo "nothing was corrupted or missed in transit."
