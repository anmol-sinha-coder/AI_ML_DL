#!/usr/bin/env bash
# Merge a LoRA adapter into its base model, convert to GGUF, quantize, and
# register with Ollama -- producing the single-file offline artifact you
# actually run on the RTX 3050.
#
# Usage: bash export_gguf.sh <lora-adapter-dir> <output-dir> [base-model]
set -euo pipefail

LORA_DIR="${1:?usage: export_gguf.sh <lora-adapter-dir> <output-dir> [base-model]}"
OUT_DIR="${2:?usage: export_gguf.sh <lora-adapter-dir> <output-dir> [base-model]}"
BASE_MODEL="${3:-Qwen/Qwen3-4B-Instruct}"

mkdir -p "$OUT_DIR"

echo "[1/4] Merging LoRA adapter into base model..."
python - <<PY
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer

base = AutoModelForCausalLM.from_pretrained("$BASE_MODEL", torch_dtype="bfloat16")
merged = PeftModel.from_pretrained(base, "$LORA_DIR").merge_and_unload()
merged.save_pretrained("$OUT_DIR/merged")
AutoTokenizer.from_pretrained("$BASE_MODEL").save_pretrained("$OUT_DIR/merged")
PY

echo "[2/4] Cloning llama.cpp for GGUF conversion (one-time)..."
if [ ! -d "llama.cpp" ]; then
  git clone --depth 1 https://github.com/ggml-org/llama.cpp
fi
pip install -r llama.cpp/requirements.txt -q

echo "[3/4] Converting to GGUF (f16) then quantizing to Q4_K_M..."
python llama.cpp/convert_hf_to_gguf.py "$OUT_DIR/merged" \
    --outfile "$OUT_DIR/model-f16.gguf" --outtype f16

cmake -S llama.cpp -B llama.cpp/build -DCMAKE_BUILD_TYPE=Release -DGGML_CUDA=OFF
cmake --build llama.cpp/build --target llama-quantize -j"$(nproc)"
llama.cpp/build/bin/llama-quantize "$OUT_DIR/model-f16.gguf" \
    "$OUT_DIR/model-q4_k_m.gguf" Q4_K_M

echo "[4/4] Writing Ollama Modelfile..."
cat > "$OUT_DIR/Modelfile" <<MODELFILE
FROM ./model-q4_k_m.gguf
PARAMETER temperature 0
PARAMETER num_ctx 8192
MODELFILE

echo "Done. Register it with:"
echo "  cd $OUT_DIR && ollama create spark-config-model -f Modelfile"
echo "Then run fully offline with:"
echo "  ollama run spark-config-model"
