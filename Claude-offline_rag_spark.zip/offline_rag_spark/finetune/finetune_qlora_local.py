"""
QLoRA fine-tune that actually fits on a 4GB card (RTX 3050), using Unsloth.

Read this before running it:

  - Real memory budget on 4GB: ~2.2GB for a 3B model's 4-bit weights + ~0.5GB
    CUDA overhead leaves roughly 1-1.3GB for activations/gradients. That's
    why --max-seq-length defaults to 768 here, not the 4096 used in the
    cloud-GPU version. Your training EXAMPLES need to be short --
    condensed mapping/schema snippets, not full retrieved context blocks.
  - This is a real trade-off, not a formality: the model learns the JSON
    generation PATTERN from short examples. At actual inference time
    (rag_chain.py), it will still see full retrieved context in the
    prompt -- that's fine, since inference doesn't carry the training-time
    memory cost. But if your training examples never show the model
    long/messy real context, its behavior on long real context is less
    predictable than if you'd trained on realistic-length examples (the
    cloud-GPU path in finetune_qlora.py can do that).
  - If this still OOMs on your card: drop --max-seq-length further (512,
    then 384), drop --lora-r to 4, or switch --base-model to something
    smaller than 3B (e.g. unsloth/Qwen2.5-1.5B-Instruct-bnb-4bit).

Install (on the RTX 3050 box itself, this one is fine locally):
    pip install unsloth bitsandbytes trl peft accelerate datasets

Usage:
    python finetune_qlora_local.py --dataset ./training_examples.jsonl \\
        --output-dir ./lora-out-local
"""
from __future__ import annotations

import argparse

PROMPT_TEMPLATE = """# Context
{context}

# Request
{query}

# Response
{response}"""


def format_example(example: dict) -> dict:
    return {
        "text": PROMPT_TEMPLATE.format(
            context=example["context"], query=example["query"], response=example["response"]
        )
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--base-model",
        default="unsloth/Qwen2.5-3B-Instruct-bnb-4bit",
        help="An unsloth pre-quantized checkpoint -- smaller download, and "
        "guaranteed compatible with Unsloth's fast kernels.",
    )
    ap.add_argument("--dataset", required=True)
    ap.add_argument("--output-dir", required=True)
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--lr", type=float, default=2e-4)
    ap.add_argument(
        "--max-seq-length",
        type=int,
        default=768,
        help="Keep this short on 4GB. Each +256 tokens costs real VRAM you don't have.",
    )
    ap.add_argument("--lora-r", type=int, default=8, help="Lower than the cloud version's 16 -- fewer trainable params, less optimizer-state memory.")
    args = ap.parse_args()

    from datasets import load_dataset
    from trl import SFTConfig, SFTTrainer
    from unsloth import FastLanguageModel

    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name=args.base_model,
        max_seq_length=args.max_seq_length,
        load_in_4bit=True,
        dtype=None,  # let Unsloth pick the right dtype for your GPU
    )

    model = FastLanguageModel.get_peft_model(
        model,
        r=args.lora_r,
        lora_alpha=args.lora_r * 2,
        lora_dropout=0.0,  # 0 is required for Unsloth's fused kernels
        bias="none",
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
        use_gradient_checkpointing="unsloth",  # this is the memory-saving part
        random_state=42,
    )

    dataset = load_dataset("json", data_files=args.dataset, split="train")
    dataset = dataset.map(format_example)

    import torch

    sft_config = SFTConfig(
        output_dir=args.output_dir,
        num_train_epochs=args.epochs,
        per_device_train_batch_size=1,       # batch size 1 -- non-negotiable at 4GB
        gradient_accumulation_steps=16,       # recover effective batch size here instead
        learning_rate=args.lr,
        max_seq_length=args.max_seq_length,
        logging_steps=5,
        save_strategy="epoch",
        optim="paged_adamw_8bit",             # pages optimizer states to system RAM under pressure
        fp16=not torch.cuda.is_bf16_supported(),
        bf16=torch.cuda.is_bf16_supported(),
        report_to="none",
    )

    trainer = SFTTrainer(
        model=model,
        args=sft_config,
        train_dataset=dataset,
        tokenizer=tokenizer,
    )
    trainer.train()

    model.save_pretrained(args.output_dir)
    tokenizer.save_pretrained(args.output_dir)
    print(f"LoRA adapter saved -> {args.output_dir}")
    print("Next: bash export_gguf.sh <output-dir> <merged-gguf-dir>")


if __name__ == "__main__":
    main()
