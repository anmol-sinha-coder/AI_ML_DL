"""
Run this ON THE CPU-ONLY MACHINE after copying the portable bundle over.
Confirms: (1) nothing got corrupted in transit, (2) the GGUF model loads and
runs with n_gpu_layers=0, (3) the FAISS index loads with no GPU/network
involved, (4) one real end-to-end generation produces schema-valid JSON.

Usage:
    python verify_cpu_only.py --bundle-dir ./portable_bundle
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path


def verify_manifest(bundle_dir: Path) -> None:
    manifest = json.loads((bundle_dir / "manifest.json").read_text())
    print(f"Manifest: {manifest['file_count']} files, "
          f"{manifest['total_size_bytes'] / 1e6:.1f} MB expected")

    for entry in manifest["files"]:
        path = bundle_dir / entry["path"]
        if not path.exists():
            raise SystemExit(f"MISSING FILE: {entry['path']}")
        actual_hash = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual_hash != entry["sha256"]:
            raise SystemExit(
                f"CHECKSUM MISMATCH: {entry['path']} -- transfer corrupted this file, re-copy it"
            )
    print(f"All {len(manifest['files'])} files present and checksums match. Transfer was clean.")


def verify_gguf_loads(bundle_dir: Path) -> str:
    from llama_cpp import Llama

    gguf_files = list((bundle_dir / "model").glob("*.gguf"))
    if not gguf_files:
        raise SystemExit(f"No .gguf file found in {bundle_dir / 'model'}")
    model_path = str(gguf_files[0])

    print(f"Loading {gguf_files[0].name} with n_gpu_layers=0 (CPU only)...")
    t0 = time.time()
    llm = Llama(model_path=model_path, n_ctx=4096, n_gpu_layers=0, verbose=False)
    print(f"Loaded in {time.time() - t0:.1f}s")
    return model_path


def verify_faiss_loads(bundle_dir: Path):
    from langchain_community.vectorstores import FAISS
    from langchain_core.embeddings import DeterministicFakeEmbedding

    # Swap DeterministicFakeEmbedding for the real embedding model you used
    # at ingest time, e.g.:
    #   from langchain_huggingface import HuggingFaceEmbeddings
    #   embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    embeddings = DeterministicFakeEmbedding(size=384)
    store = FAISS.load_local(
        str(bundle_dir / "faiss_index"), embeddings, allow_dangerous_deserialization=True
    )
    print(f"FAISS index loaded, {store.index.ntotal} vectors")
    return store


def verify_end_to_end(model_path: str, bundle_dir: Path) -> None:
    sys.path.insert(0, str(bundle_dir / "code" / "rag"))
    from schemas import SparkJobConfig
    from llama_cpp import Llama

    llm = Llama(model_path=model_path, n_ctx=4096, n_gpu_layers=0, verbose=False)
    schema = SparkJobConfig.model_json_schema()

    prompt = (
        "Generate a minimal Spark job config named 'cpu_smoke_test' that reads "
        "from table raw.events and writes to parquet."
    )
    t0 = time.time()
    result = llm.create_chat_completion(
        messages=[{"role": "user", "content": prompt}],
        response_format={"type": "json_object", "schema": schema},
        temperature=0,
    )
    elapsed = time.time() - t0

    content = result["choices"][0]["message"]["content"]
    parsed = SparkJobConfig.model_validate_json(content)  # raises if schema-invalid
    print(f"Generation succeeded in {elapsed:.1f}s (CPU) -- job_name={parsed.job_name!r}")
    print("This confirms the model produces schema-valid output on CPU alone, "
          "no GPU or network involved.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--bundle-dir", required=True, type=Path)
    ap.add_argument(
        "--skip-generation", action="store_true",
        help="Only check file integrity + that the model/index load, skip the slow full generation"
    )
    args = ap.parse_args()

    verify_manifest(args.bundle_dir)
    model_path = verify_gguf_loads(args.bundle_dir)
    verify_faiss_loads(args.bundle_dir)

    if not args.skip_generation:
        verify_end_to_end(model_path, args.bundle_dir)

    print("\nAll checks passed. This machine can run the pipeline fully offline.")


if __name__ == "__main__":
    main()
