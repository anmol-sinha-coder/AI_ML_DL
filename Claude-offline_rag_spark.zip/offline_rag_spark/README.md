# Offline RAG -> Spark JSON config generator

A fully local pipeline: ingest JSON/Excel/CSV/Parquet/Markdown source docs into a
portable FAISS index, retrieve relevant context, and use a local Ollama LLM
(schema-constrained) to generate Spark job config JSON. Designed to run with
no network access after initial setup.

## Reality check before you build this

1. **Nothing runs with zero installed software.** A GGUF model file is a single
   portable artifact (like a `.pt` file), but it still needs a runtime present
   on the machine: `ollama`, or `llama-cpp-python`, or the raw `llama.cpp`
   binary. Plan for "one weights file + one small static runtime", not
   "one file, nothing else."
2. **4GB VRAM is an inference budget, not a training budget.** Fine-tune on a
   free/cheap cloud GPU (Colab T4, 16GB+), then bring the merged, quantized
   GGUF back to your RTX 3050 for inference only. `finetune/finetune_qlora.py`
   is written assuming it runs elsewhere, not on your local box.
3. **FAISS over pgVector** for the "single portable artifact" requirement --
   pgVector needs a live Postgres server; a FAISS index is just two files you
   can copy anywhere.
4. **JSON reliability comes from schema constraints, not prompting.** Ollama
   supports passing a JSON schema via the `format` field, enforced at decode
   time. We use this everywhere instead of hoping the model "writes valid
   JSON" from instructions alone.

## What's actually verified vs. what you still need to test

Everything below was **executed for real** in a sandboxed environment (Java 21,
Python 3.12, no GPU, no Ollama, no Hugging Face access):

| Test | What it proves | Status |
|---|---|---|
| `test_faiss_index_roundtrip` | `save_local()` -> fresh reload -> identical retrieval | Passed |
| `test_spark_job_config_json_roundtrip` | Pydantic model -> JSON string/file -> reparsed identically | Passed |
| `test_spark_udf_broadcast_and_schema_conformance` | Model reference broadcasts to Spark workers; each worker independently loads its own model handle; every output is schema-valid | Passed |
| `ingest.py` on 4 sample files (json/xlsx/csv/md) | Full ingestion -> 10 chunks -> FAISS build -> save -> reload -> retrieve | Ran successfully, see `sample_sources/` |
| `test_ollama_structured_output_live` | Real Ollama call with schema-constrained output | Skipped (needs Ollama running -- run it yourself with `RUN_OLLAMA_TESTS=1`) |
| `test_spark_udf_real_gguf_inference` | Real llama-cpp-python GGUF inference inside a Spark executor | Skipped (needs actual model weights and GPU -- run with `RUN_LLAMACPP_TESTS=1 GGUF_MODEL_PATH=...`) |

**Three real bugs got caught and fixed by actually running this**, which is
exactly the value of testing serialization instead of assuming it works:

1. A module-level `threading.Lock()` broke cloudpickle when the UDF module
   was run as `__main__` ("cannot pickle '_thread.lock' object"). Fixed by
   never executing the UDF-defining module directly -- always import it
   from a separate driver script (`run_local_demo.py`).
2. Naming the module file the same as its containing folder
   (`spark_udf/spark_udf.py`) created a namespace-package collision --
   `import spark_udf` silently resolved to the folder instead of the file
   in a fresh worker process, throwing `AttributeError: Can't get attribute
   'ModelRunner'`. Fixed by renaming to `spark_udf/config_generator.py`.
3. `sys.path.insert()` in the driver process is invisible to Spark's worker
   subprocesses -- they have a fresh interpreter and fresh `sys.path`.
   Fixed with `sparkContext.addPyFile()`, which is the actual correct way
   to ship local modules to workers (and what `spark-submit --py-files`
   does on a real cluster).

None of this is hypothetical -- you'll hit the same three issues if you skip
straight to writing your own UDF module without this pattern.

## Folder layout

```
offline_rag_spark/
  ingest/ingest.py          # builds the portable FAISS index from your 4 input types
  rag/schemas.py            # Pydantic schema for the Spark JSON config you want generated
  rag/rag_chain.py          # LangChain + Ollama retrieval + schema-constrained generation
  finetune/finetune_qlora.py       # QLoRA fine-tune, cloud GPU (16GB+)
  finetune/finetune_qlora_local.py # QLoRA fine-tune, genuinely runs on the RTX 3050 (4GB)
  finetune/export_gguf.sh          # merge LoRA -> convert to GGUF -> quantize -> import to Ollama
  spark_udf/config_generator.py    # in-executor inference UDF using llama-cpp-python directly
  spark_udf/run_local_demo.py      # standalone Spark demo/smoke-test (mock model, no GPU needed)
  requirements.txt
```

## Setup (Windows + WSL2)

```bash
# 1. Install Ollama inside WSL2 (it will auto-detect your RTX 3050 via CUDA)
curl -fsSL https://ollama.com/install.sh | sh

# 2. Pull a base model to develop against
ollama pull qwen3:4b

# 3. Python env
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

## Day-to-day flow

```bash
# Build/refresh the vector index from your source docs
python ingest/ingest.py --input-dir ./sources --index-dir ./faiss_index

# Ask it to generate a Spark job config from a mapping doc + schema context
python rag/rag_chain.py --index-dir ./faiss_index \
    --query "Generate the Spark job config for the customer_orders mapping"
```

The `faiss_index/` folder (two files: `index.faiss`, `index.pkl`) is your
single portable knowledge base artifact -- copy it anywhere the same
embedding model is available.

## Fine-tuning: local (RTX 3050) vs. cloud, and why both exist

`finetune/finetune_qlora.py` assumes a 16GB+ GPU and uses long training
examples (full retrieved context, like the model sees at real inference
time). `finetune/finetune_qlora_local.py` genuinely runs on 4GB via Unsloth
+ a smaller model + short training examples (~768 tokens) + `paged_adamw_8bit`.

The trade-off is real, not artificial: your RTX 3050 has ~2.2GB left over
after loading a 3B model's 4-bit weights and CUDA overhead, and
activation/gradient memory scales with sequence length. Training examples
have to be compressed to fit -- the model learns the JSON-generation
pattern from short examples rather than from realistic-length context.
Inference (rag_chain.py) is unaffected by this and can still use full
retrieved context, since inference doesn't carry training's memory cost.

If "cloud" is a hard no for privacy/policy reasons (plausible, given this
touches internal mapping docs and schema), the local path is the answer.
If it's more about convenience, note that Colab and Kaggle's free tiers
(T4/P100, no cost, just a Google/Kaggle account) aren't really "cloud
infrastructure you have to provision" -- they're free notebooks, and
they'd let you train on realistic-length examples instead of compressed
ones.

```bash
pip install unsloth bitsandbytes trl peft accelerate datasets
python finetune/finetune_qlora_local.py --dataset ./training_examples.jsonl \
    --output-dir ./lora-out-local
bash finetune/export_gguf.sh ./lora-out-local ./merged-gguf
```

## Fine-tuning path (optional, cloud GPU)

```bash
# On Colab / any 16GB+ GPU box:
python finetune/finetune_qlora.py --base-model Qwen/Qwen3-4B-Instruct \
    --dataset ./training_examples.jsonl --output-dir ./lora-out

# Then, still on that machine or after copying artifacts down:
bash finetune/export_gguf.sh ./lora-out ./merged-gguf
ollama create spark-config-qwen3 -f ./merged-gguf/Modelfile
```

Now `ollama run spark-config-qwen3` works fully offline on your RTX 3050,
carrying your fine-tuning, with the same JSON-schema-constrained decoding.

## Using it as a Spark UDF

`spark_udf/config_generator.py` deliberately does **not** call an Ollama HTTP server
from executors -- that would mean every executor node needs a running Ollama
server, which is fragile in a cluster. Instead it loads the GGUF file
directly in-process via `llama-cpp-python`, once per executor (lazy
singleton), and exposes a `pandas_udf` that takes mapping/schema struct
columns and returns a JSON string column you can parse with `from_json` or
store as `to_json` struct output.
