"""
Retrieve relevant mapping/schema/event context from the FAISS index and ask a
local Ollama model to generate a schema-conformant SparkJobConfig.

Reliability note: we don't rely on prompt instructions ("please output valid
JSON") -- .with_structured_output() passes the Pydantic JSON schema straight
to Ollama's `format` field, which constrains decoding so the model literally
cannot emit a token that breaks the schema. That's the difference between
"usually valid JSON" and "always valid JSON".

Usage:
    python rag_chain.py --index-dir ./faiss_index \\
        --query "Generate the Spark job config for the customer_orders mapping" \\
        --model qwen3:4b
"""
from __future__ import annotations

import argparse
from pathlib import Path

from langchain_community.vectorstores import FAISS
from langchain_ollama import ChatOllama

from schemas import SparkJobConfig

try:
    from ingest.ingest import get_embeddings  # when run from repo root
except ImportError:
    import sys

    sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "ingest"))
    from ingest import get_embeddings  # type: ignore


PROMPT_TEMPLATE = """You are generating a Spark job configuration for an offline data
platform. Use ONLY the context below -- do not invent table or column names
that aren't present in it. If the context is insufficient to fill a field
confidently, leave it empty or use a sensible conservative default rather
than guessing.

# Context (retrieved mapping/schema/event/prompt documents)
{context}

# Request
{query}
"""


def build_chain(index_dir: str, model: str, embeddings_name: str, k: int = 6):
    embeddings = get_embeddings(embeddings_name)
    store = FAISS.load_local(index_dir, embeddings, allow_dangerous_deserialization=True)
    retriever = store.as_retriever(search_kwargs={"k": k})

    llm = ChatOllama(model=model, temperature=0)
    structured_llm = llm.with_structured_output(SparkJobConfig)

    def run(query: str) -> SparkJobConfig:
        docs = retriever.invoke(query)
        context = "\n\n---\n\n".join(
            f"[{d.metadata.get('type', 'unknown')} | {d.metadata.get('source', '?')}]\n{d.page_content}"
            for d in docs
        )
        prompt = PROMPT_TEMPLATE.format(context=context, query=query)
        return structured_llm.invoke(prompt)

    return run


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--index-dir", required=True)
    ap.add_argument("--query", required=True)
    ap.add_argument("--model", default="qwen3:4b")
    ap.add_argument("--embeddings", default="sentence-transformers/all-MiniLM-L6-v2")
    ap.add_argument("--k", type=int, default=6)
    ap.add_argument("--out", default=None, help="Optional path to write the generated JSON")
    args = ap.parse_args()

    run = build_chain(args.index_dir, args.model, args.embeddings, args.k)
    config = run(args.query)

    output = config.model_dump_json(indent=2)
    print(output)
    if args.out:
        Path(args.out).write_text(output)
        print(f"\nWritten -> {args.out}")


if __name__ == "__main__":
    main()
