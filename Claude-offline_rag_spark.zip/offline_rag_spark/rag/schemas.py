"""
Target schema for generated Spark job configs.

This is the single source of truth for what "valid output" means. It is used
in three places, and all three must stay in sync automatically (not by hand):
  1. rag/rag_chain.py        -> passed to ChatOllama.with_structured_output()
  2. spark_udf/spark_udf.py  -> passed as the JSON schema to llama-cpp's
                                 grammar-constrained decoding
  3. tests/test_serde.py     -> used to validate every generated row

Because both consumers just call `SparkJobConfig.model_json_schema()`, you
only ever edit this file when the config shape changes.
"""
from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field


class ClusterConfig(BaseModel):
    """Spark execution cluster sizing. Optional because not every generated
    config needs to specify a cluster (e.g. configs meant to run on an
    already-provisioned shared cluster)."""

    num_executors: int = Field(ge=1, description="Number of executor instances")
    executor_cores: int = Field(ge=1, description="Cores per executor")
    executor_memory: str = Field(description="e.g. '4g', '8g'")
    driver_memory: str = Field(description="e.g. '2g'")
    spark_conf: dict[str, str] = Field(
        default_factory=dict,
        description="Extra spark.* conf key-value overrides, e.g. "
        "{'spark.sql.shuffle.partitions': '200'}",
    )


class PipelineStep(BaseModel):
    step_id: str
    step_type: Literal["read", "transform", "write", "validate"]
    description: str
    sql_statement: Optional[str] = Field(
        default=None, description="SQL for this step, if applicable"
    )
    depends_on: list[str] = Field(
        default_factory=list, description="step_ids this step depends on"
    )


class SparkJobConfig(BaseModel):
    """The full generated artifact: one Spark job definition."""

    job_name: str
    description: str
    source_mapping_ref: str = Field(
        description="Identifier of the mapping/schema doc this config was derived from"
    )
    cluster: Optional[ClusterConfig] = None
    sql: list[str] = Field(
        default_factory=list, description="SQL statements used by this job, in order"
    )
    pipeline_steps: list[PipelineStep] = Field(default_factory=list)
    output_format: Literal["parquet", "delta", "json", "csv", "avro"] = "parquet"
    notes: Optional[str] = None
