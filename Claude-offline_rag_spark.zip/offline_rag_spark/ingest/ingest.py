"""
Build a portable FAISS knowledge base from:
  - *.json               source event / process execution files
  - *.xlsx / *.xls       table/project column mapping documents
  - *.csv / *.parquet    information-schema-style table structure dumps
  - *.md                 prompt / format explanation docs

Output is two files (index.faiss, index.pkl) in --index-dir. That folder is
your single portable knowledge-base artifact -- copy it anywhere the same
embedding model is available. It has no server dependency (unlike pgVector).

Usage:
    python ingest.py --input-dir ./sources --index-dir ./faiss_index --verify
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings


def get_embeddings(name: str) -> Embeddings:
    """
    'fake'  -> deterministic, no network, no model download. Use this to test
               the ingestion/retrieval plumbing itself.
    anything else -> treated as a HuggingFace sentence-transformers model id,
               e.g. 'sentence-transformers/all-MiniLM-L6-v2' or
               'BAAI/bge-small-en-v1.5'. Downloads once, then runs fully
               offline. Requires: pip install langchain-huggingface sentence-transformers
    """
    if name == "fake":
        from langchain_core.embeddings import DeterministicFakeEmbedding

        return DeterministicFakeEmbedding(size=384)
    from langchain_huggingface import HuggingFaceEmbeddings

    return HuggingFaceEmbeddings(model_name=name)


# ---------------------------------------------------------------------------
# Loaders -- one per input format. Each returns a list of Documents with
# metadata that lets you trace every retrieved chunk back to its source.
# ---------------------------------------------------------------------------

def load_json_events(path: Path) -> list[Document]:
    """Source event / process execution JSON. Handles either a single JSON
    object or a top-level list of records."""
    raw = json.loads(path.read_text())
    records = raw if isinstance(raw, list) else [raw]
    docs = []
    for i, rec in enumerate(records):
        # Flatten into a readable description rather than dumping raw JSON --
        # embeddings work far better on natural language than on nested braces.
        lines = [f"{k}: {v}" for k, v in _flatten(rec).items()]
        content = f"Source event record from {path.name}:\n" + "\n".join(lines)
        docs.append(
            Document(
                page_content=content,
                metadata={"source": str(path), "type": "event_json", "record_index": i},
            )
        )
    return docs


def load_mapping_excel(path: Path) -> list[Document]:
    """Column mapping documents. One Document per row so retrieval can pull
    exactly the mapping rows relevant to a given table/column."""
    docs = []
    sheets = pd.read_excel(path, sheet_name=None)
    for sheet_name, df in sheets.items():
        df = df.fillna("")
        for i, row in df.iterrows():
            lines = [f"{col}: {row[col]}" for col in df.columns]
            content = (
                f"Column mapping entry from '{path.name}' sheet '{sheet_name}':\n"
                + "\n".join(lines)
            )
            docs.append(
                Document(
                    page_content=content,
                    metadata={
                        "source": str(path),
                        "type": "mapping_excel",
                        "sheet": sheet_name,
                        "row_index": int(i),
                    },
                )
            )
    return docs


def load_schema_table(path: Path) -> list[Document]:
    """Information-schema-style table structure dumps (CSV or Parquet).
    Groups by table name if a 'table_name' column exists, so one Document
    describes one whole table's columns rather than one row per column --
    that reads much better for retrieval."""
    df = pd.read_parquet(path) if path.suffix == ".parquet" else pd.read_csv(path)
    df = df.fillna("")
    docs = []
    if "table_name" in df.columns:
        for table_name, group in df.groupby("table_name"):
            col_lines = [
                " | ".join(f"{c}={row[c]}" for c in df.columns if c != "table_name")
                for _, row in group.iterrows()
            ]
            content = (
                f"Table structure for '{table_name}' (from {path.name}):\n"
                + "\n".join(col_lines)
            )
            docs.append(
                Document(
                    page_content=content,
                    metadata={"source": str(path), "type": "schema_table", "table_name": str(table_name)},
                )
            )
    else:
        # No grouping column -- fall back to one Document per row.
        for i, row in df.iterrows():
            content = f"Schema row from {path.name}:\n" + " | ".join(
                f"{c}={row[c]}" for c in df.columns
            )
            docs.append(
                Document(
                    page_content=content,
                    metadata={"source": str(path), "type": "schema_table", "row_index": int(i)},
                )
            )
    return docs


def load_markdown(path: Path) -> list[Document]:
    """Prompt/format explanation docs, split on markdown headers so each
    chunk stays topically coherent."""
    from langchain_text_splitters import MarkdownHeaderTextSplitter

    text = path.read_text()
    splitter = MarkdownHeaderTextSplitter(
        headers_to_split_on=[("#", "h1"), ("##", "h2"), ("###", "h3")]
    )
    chunks = splitter.split_text(text)
    docs = []
    for i, chunk in enumerate(chunks):
        chunk.metadata.update({"source": str(path), "type": "prompt_markdown", "chunk_index": i})
        docs.append(chunk)
    return docs


def _flatten(d: dict, prefix: str = "") -> dict:
    out = {}
    for k, v in d.items():
        key = f"{prefix}{k}"
        if isinstance(v, dict):
            out.update(_flatten(v, prefix=f"{key}."))
        else:
            out[key] = v
    return out


LOADERS = {
    ".json": load_json_events,
    ".xlsx": load_mapping_excel,
    ".xls": load_mapping_excel,
    ".csv": load_schema_table,
    ".parquet": load_schema_table,
    ".md": load_markdown,
}


def ingest_directory(input_dir: Path) -> list[Document]:
    docs: list[Document] = []
    for path in sorted(input_dir.rglob("*")):
        if path.is_file() and path.suffix in LOADERS:
            docs.extend(LOADERS[path.suffix](path))
    return docs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input-dir", required=True, type=Path)
    ap.add_argument("--index-dir", required=True, type=Path)
    ap.add_argument(
        "--embeddings",
        default="sentence-transformers/all-MiniLM-L6-v2",
        help="'fake' for no-network testing, or a HF sentence-transformers model id",
    )
    ap.add_argument("--verify", action="store_true", help="Reload the saved index and run a test query")
    args = ap.parse_args()

    docs = ingest_directory(args.input_dir)
    if not docs:
        raise SystemExit(f"No supported files found under {args.input_dir}")
    print(f"Loaded {len(docs)} chunks from {args.input_dir}")

    embeddings = get_embeddings(args.embeddings)
    store = FAISS.from_documents(docs, embeddings)
    args.index_dir.mkdir(parents=True, exist_ok=True)
    store.save_local(str(args.index_dir))
    print(f"Saved FAISS index -> {args.index_dir} (index.faiss + index.pkl)")

    if args.verify:
        # Fresh load, separate object -- proves the on-disk artifact is
        # actually self-sufficient and not relying on in-memory state.
        reloaded = FAISS.load_local(
            str(args.index_dir), embeddings, allow_dangerous_deserialization=True
        )
        sample_query = docs[0].page_content[:60]
        results = reloaded.similarity_search(sample_query, k=1)
        print("Verify OK -- reloaded index top match:")
        print(results[0].page_content[:200])


if __name__ == "__main__":
    main()
