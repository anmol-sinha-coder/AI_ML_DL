# Input format guide

## Event JSON
Each record describes one pipeline execution: event_id, process, status, duration_sec, source_system.

## Mapping Excel
One row per column mapping: source_column, target_column, transform rule.

## Schema CSV
information_schema-style dump: table_name, column_name, data_type, nullable.
